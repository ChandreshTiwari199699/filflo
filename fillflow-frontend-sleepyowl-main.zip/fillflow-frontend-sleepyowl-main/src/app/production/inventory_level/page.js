'use client';
import React, { useState, useEffect } from 'react';
import { skuServices } from '@/app/services/skuServices';
import { useDispatch, useSelector } from 'react-redux';
import {
  getAllSKURequest,
  getAllSKUSuccess,
  getAllSKUFailure,
} from '../../Actions/skuActions';
import ProductionInventoryLevelTable from '@/app/components/ProductionInventoryLevelTable/ProductionInventoryLevelTable';
import NavigationBar from '@/app/components/NavigationBar/NavigationBar';
import { items } from '@/app/utils/sidebarItems';
import StatusBar from "@/app/components/StatusBar/StatusBar";
import TitleBar from "@/app/components/TitleBar/TitleBar";
import { PrimaryButton } from '@/app/components/ButtonComponent/ButtonComponent';
import RightSidebar from '@/app/components/RightSidebar/RightSidebar';
import CreateProductionPO from '@/app/components/CreateProductionPO/CreateProductionPO';

const page = () => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [sidebarContent, setSidebarContent] = useState(null);
    const dispatch = useDispatch();

  const getAllSKUs = async () => {
    try {
      dispatch(getAllSKURequest());
      const response = await skuServices.getAllSKUs();
      if (response.success === true) {
        dispatch(getAllSKUSuccess(response.data));
      }
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    getAllSKUs();
  }, []);

  const { allSKUs } = useSelector((state) => state.sku);

  
  const calculateStatusBarData = (allSKUs) => {
    let rawMaterials = 0;
    let finishedGoods = 0;
    let totalSKUs = 0;
    let underStockCount = 0;
    let overStockCount = 0;


    allSKUs.forEach((sku) => {
      const { current_production_count, lower_threshold_storage, upper_threshold_storage } = sku;
      const category = sku?.sku_category?.category_name;
      if (current_production_count < lower_threshold_storage) underStockCount++;
      if (current_production_count > upper_threshold_storage) overStockCount++;
      if (category === "Raw Material") rawMaterials++;
      if (category === "Finished Goods") finishedGoods++;
      totalSKUs++;
    });

    return [
      { value: totalSKUs, heading: "Total SKUs" },
      { value: underStockCount, heading: "Under Stock" },
      { value: overStockCount, heading: "Over Stock" },
      { value: rawMaterials, heading: "Raw Materials" },
      { value: finishedGoods, heading: "Finished Goods" },
    ];
  };

  const statusBarData = calculateStatusBarData(allSKUs);

  const handleSidebarContent = (actionType) => {
    switch (actionType) {
      case "raisePO":
        setSidebarContent(
          <CreateProductionPO onCancel={() => setIsSidebarOpen(false)} />
        );
        setIsSidebarOpen(true);
        break;


      default:
        setIsSidebarOpen(false);
    }
    // Open the sidebar
  };

  const generateNavItems = () => {
    
    const storageTeam = items.find(item => item.label === "Production");
  
    if (storageTeam && storageTeam.subItems) {
      return storageTeam.subItems.map(subItem => ({
        name: subItem.label,
        path: subItem.path,
        icon: subItem.iconKey,
      }));
    }
  
    return [];
  };

   const buttons = [
        <PrimaryButton
        title="Raise Production PO"
        onClick={() => {
          setIsSidebarOpen(true);
          handleSidebarContent("raisePO");
        }}
        size="medium"
      >
      </PrimaryButton>,
  
    
      ];

  const navItems = generateNavItems();

  return (
    <div className="relative w-full h-full overflow-scroll scrollbar-none bg-[#f9fafc]">
    <div className="relative z-10 flex flex-col items-center overflow-scroll scrollbar-none px-4 py-2">
      <div className="w-full max-w-full mb-4">
        <TitleBar title="Production"  buttons={buttons} />
      </div>

      <div className="w-full max-w-full mb-5">
        <StatusBar data={statusBarData} />
      </div>

      <div className='w-full max-w-full mb-5'>
      <NavigationBar navItems={navItems} />
      </div>

      <div className="flex w-full max-w-full mb-6 scrollbar-none">
        <div className="flex-1 rounded-lg  bg-gray-1 overflow-y-auto scrollbar-none">
          <ProductionInventoryLevelTable />
        </div>
      </div>
    </div>
    <RightSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)} // Close the sidebar
      >
        {sidebarContent}
      </RightSidebar>
  </div>
  );
};

export default page;
