'use client';
import React, { useState, useEffect } from 'react';
import Sidebar from '../../components/Sidebar/Sidebar';
import { useDispatch, useSelector } from 'react-redux';
import {
  getAllProductRequest,
  getAllProductSuccess,
  getAllProductFailure,
} from '../../Actions/productActions';
import { items } from '@/app/utils/sidebarItems';
import ProductMaster from '@/app/components/ProductMaster/ProductMaster';
import { productServices } from '@/app/services/productService';
import TitleBar from '@/app/components/TitleBar/TitleBar';
import StatusBar from '@/app/components/StatusBar/StatusBar';
import NavigationBar from  '@/app/components/NavigationBar/NavigationBar';
import {
  PrimaryButton,
  SecondaryButton,
} from "@/app/components/ButtonComponent/ButtonComponent";
import RightSidebar from '@/app/components/RightSidebar/RightSidebar';
import BulkInwardProductsByCSV from '@/app/components/BulkInwardProductsByCSV/BulkInwardProductsByCSV';



const page = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarContent, setSidebarContent] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const dispatch = useDispatch();


  const getAllProducts = async () => {
    try {
      dispatch(getAllProductRequest());
      const response = await productServices.getAllProducts();
      if (response.success === true) {
        dispatch(getAllProductSuccess(response.data));
      }
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    getAllProducts();
  }, [getAllProducts]); 



 const generateNavItems = () => {
       
       const masterTeam = items.find(item => item.label === "Master Data");
     
       if (masterTeam && masterTeam.subItems) {
         return masterTeam.subItems.map(subItem => ({
           name: subItem.label,
           path: subItem.path,
           icon: subItem.iconKey,
         }));
       }
     
       return [];
     };
     
     const navItems = generateNavItems();

    const handleSidebarContent = (actionType) => {
      switch (actionType) {
        case "bulkInwardProducts":
          setSidebarContent(
            <BulkInwardProductsByCSV onCancel={() => setIsSidebarOpen(false)} />
          );
          setIsSidebarOpen(true);
          break;

  
        default:
          setIsSidebarOpen(false);
      }
      // Open the sidebar
    };


    const buttons = [
          <PrimaryButton
          title="Bulk Inward Products"
          onClick={() => {
            setIsSidebarOpen(true);
            handleSidebarContent("bulkInwardProducts");
          }}
          size="medium"
        >
        </PrimaryButton>

  
    ];

  return (
    <div className="relative w-full h-full overflow-scroll scrollbar-none bg-[#f9fafc]">
      <div className="relative z-10 flex flex-col items-center overflow-scroll scrollbar-none px-4 py-2">
        <div className="w-full max-w-full mb-4">
          <TitleBar title="Master Data"  buttons={buttons} />
        </div>

      
        <div className='w-full max-w-full mb-5'>
        <NavigationBar navItems={navItems} />
        </div>

        <div className="flex w-full max-w-full mb-6 scrollbar-none">
          <div className="flex-1 rounded-lg  bg-gray-1 overflow-y-auto scrollbar-none">
            <ProductMaster />
          </div>
        </div>
      </div>
      <RightSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)} // Close the sidebar
      >
        {sidebarContent}
      </RightSidebar>
    </div>
  );
};

export default page;
