import { BASE_URL, axiosInstance } from '../utils/assets';

export const supplierService = {
  createSupplier: async (data) => {
    try {
      const token = localStorage.getItem('x-access-token');
      if (token) {
        axiosInstance.defaults.headers.common['x-access-token'] = token;
        const response = await axiosInstance.post(`${BASE_URL}/createSupplier`, data);
        return response.data;
      }
    } catch (error) {
      return error.response?.data || { message: 'Error creating supplier' };
    }
  },

  getAllSuppliers: async () => {
    try {
      const token = localStorage.getItem('x-access-token');
      if (token) {
        axiosInstance.defaults.headers.common['x-access-token'] = token;
        const response = await axiosInstance.get(`${BASE_URL}/getAllSuppliers`);
        return response.data;
      } else {
        throw new Error('Token not available');
      }
    } catch (error) {
      return error.response?.data || { message: 'Error fetching suppliers' };
    }
  },

  getSupplierDetailsById: async (supplierId) => {
    try {
      const token = localStorage.getItem('x-access-token');
      if (token) {
        axiosInstance.defaults.headers.common['x-access-token'] = token;
        const response = await axiosInstance.get(`${BASE_URL}/getSupplierDetails/${supplierId}`);
        return response.data;
      } else {
        throw new Error('Token not available');
      }
    } catch (error) {
      return error.response?.data || { message: 'Error fetching supplier details' };
    }
  },
};
