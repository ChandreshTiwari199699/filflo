import axios from "axios";
import { BASE_URL } from "../utils/assets";
import { axiosInstance } from "../utils/assets";

export const creditNoteService = {
    createCreditNote: async (data) => {
        try {
            const token = localStorage.getItem('x-access-token');
            if (!token) {
                throw new Error('Token not available');
            }

            // Validate required fields
            const { originalInvoiceId, customerID, listOfProducts, reason } = data;
            if (!originalInvoiceId || !customerID || !listOfProducts || listOfProducts.length === 0) {
                throw new Error('Missing required fields');
            }

            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.post(
                `${BASE_URL}/creditNote`,
                data
            );
            return response.data;
        } catch (error) {
            console.error('Error in createCreditNote:', error);
            return {
                success: false,
                message: error.response?.data?.message || error.message,
                error: error.response?.data?.error || error.message
            };
        }
    },

    getAllCreditNotes: async ({
        page = 1,
        limit = 10,
        searchText = '',
        filter = 'all',
        startDate = '',
        endDate = ''
    }) => {
        try {
            const token = localStorage.getItem('x-access-token');
            if (!token) {
                throw new Error('Token not available');
            }

            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.get(`${BASE_URL}/creditNote`, {
                params: {
                    page,
                    limit,
                    searchText,
                    filter,
                    ...(startDate && { startDate }),
                    ...(endDate && { endDate })
                }
            });

            return response.data;
        } catch (error) {
            console.error('Error in getAllCreditNotes:', error);
            throw error;
        }
    }
}; 