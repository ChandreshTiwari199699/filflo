import { axiosInstance } from '../utils/assets';
import { BASE_URL } from '../utils/assets';

export const pricingStrategyService = {
  // Create a new pricing strategy
  createPricingStrategy: async (data) => {
    try {
      const token = localStorage.getItem('x-access-token');
      if (token) {
        axiosInstance.defaults.headers.common['x-access-token'] = token;
        const response = await axiosInstance.post(
          `${BASE_URL}/createPricingStrategy`,
          data
        );
        return response.data;
      } else {
        throw new Error('Token not available');
      }
    } catch (error) {
      throw { message: error.response?.data || "Something went wrong" };
    }
  },

  // Get all pricing strategies
  getAllPricingStrategies: async () => {
    try {
      const token = localStorage.getItem('x-access-token');
      if (token) {
        axiosInstance.defaults.headers.common['x-access-token'] = token;
        const response = await axiosInstance.get(`${BASE_URL}/getAllPricingStrategies`);
        return response.data;
      } else {
        throw new Error('Token not available');
      }
    } catch (error) {
      throw { message: error.response?.data || "Something went wrong" };
    }
  },
  assignPricingStrategyToCustomers: async (data) => {
    try {
      const token = localStorage.getItem('x-access-token');
      if (token) {
        axiosInstance.defaults.headers.common['x-access-token'] = token;
        const response = await axiosInstance.post(
          `${BASE_URL}/assignPricingStrategyToCustomers`,
          data
        );
        return response.data;
      } else {
        throw new Error('Token not available');
      }
    } catch (error) {
      throw { message: error.response?.data || "Something went wrong" };
    }
  },
  inwardRateCardByCSV: async (formData) => {
 
    try {
      const token = localStorage.getItem('x-access-token');
      if (token) {
        const config = {
          headers: {
            'content-type': 'multipart/form-data',
            'x-access-token': token,
          },
        };

        
        const response = await axiosInstance.post(
          `${BASE_URL}/inwardRateCardByCSV`,
          formData,
          config
        );
        return response.data;
      }
    } catch (error) {
      return error.response.data;
    }
  },
  assignRateCardToB2BCustomerByCSV: async (formData) => {
 
    try {
      const token = localStorage.getItem('x-access-token');
      if (token) {
        const config = {
          headers: {
            'content-type': 'multipart/form-data',
            'x-access-token': token,
          },
        };

        
        const response = await axiosInstance.post(
          `${BASE_URL}/assignRateCardToB2BCustomerByCSV`,
          formData,
          config
        );
        return response.data;
      }
    } catch (error) {
      return error.response.data;
    }
  },
};
