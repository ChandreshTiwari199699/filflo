import axios from "axios";
import { BASE_URL } from "../utils/assets";
import { axiosInstance } from "../utils/assets";

export const b2bInventoryPOService = {
    getAllB2BInventoryPO: async ({
        page = 1,
        limit = 50,
        searchText = '',
        filter = 'all',
        dayFilter = 'all',
        startDate = '',
        endDate = ''
    }) => {
        try {
            const token = localStorage.getItem('x-access-token');
            if (!token) {
                throw new Error('Token not available');
            }

            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.get(`${BASE_URL}/getAllB2BInventoryPO`, {
                params: {
                    page,
                    limit,
                    searchText,
                    filter,
                    dayFilter,
                    ...(startDate && { startDate }),
                    ...(endDate && { endDate })
                }
            });

            return response.data;
        } catch (error) {
            console.error('Error in getAllB2BInventoryPO:', error);
            throw error;
        }
    },

    getAllB2BInventoryPOForDownload: async ({
        searchText = '',
        filter = 'all',
        dayFilter = 'all',
        startDate = '',
        endDate = ''
    }) => {
        try {
            const token = localStorage.getItem('x-access-token');
            if (!token) {
                throw new Error('Token not available');
            }

            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.get(`${BASE_URL}/getAllB2BInventoryPOForDownload`, {
                params: {
                    searchText,
                    filter,
                    dayFilter,
                    ...(startDate && { startDate }),
                    ...(endDate && { endDate })
                }
            });

            return response.data;
        } catch (error) {
            console.error('Error in getAllB2BInventoryPOForDownload:', error);
            throw error;
        }
    },

    getB2BInventoryPOStatusCounts: async ({
        searchText = '',
        filter = 'all',
        dayFilter = 'all',
        startDate = '',
        endDate = ''
    }) => {
        try {
            const token = localStorage.getItem('x-access-token');
            if (!token) {
                throw new Error('Token not available');
            }

            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.get(`${BASE_URL}/getB2BInventoryPOStatusCounts`, {
                params: {
                    searchText,
                    filter,
                    dayFilter,
                    ...(startDate && { startDate }),
                    ...(endDate && { endDate })
                }
            });

            return response.data;
        } catch (error) {
            console.error('Error in getB2BInventoryPOStatusCounts:', error);
            return {
                success: false,
                data: {
                    total: 0,
                    pending: 0,
                    fulfilled: 0,
                    deprecated: 0
                }
            };
        }
    },

    updateB2BInventoryPO: async (data) => {
        try {
            const token = localStorage.getItem('x-access-token');
            if (token) {
                axiosInstance.defaults.headers.common['x-access-token'] = token;
                const response = await axiosInstance.post(
                    `${BASE_URL}/updateB2BInventoryPO`,
                    data
                );
                return response.data;
            } else {
                throw new Error('Token not available');
            }
        } catch (error) {
            return {
                success: false,
                message: error.response ? error.response.data : error.message,
            };
        }
    },

    processB2BInventoryPOs: async (data) => {
        try {
            const token = localStorage.getItem('x-access-token');
            if (token) {
                axiosInstance.defaults.headers.common['x-access-token'] = token;
                const response = await axiosInstance.post(
                    `${BASE_URL}/processB2BInventoryPOs`,
                    data
                );
                return response.data;
            } else {
                throw new Error('Token not available');
            }
        } catch (error) {
            return {
                success: false,
                message: error.response ? error.response.data : error.message,
            };
        }
    },

    getPendingB2BInventoryPO: async () => {
        try {
            const token = localStorage.getItem('x-access-token');
            if (token) {
                axiosInstance.defaults.headers.common['x-access-token'] = token;
                const response = await axiosInstance.get(`${BASE_URL}/getPendingB2BInventoryPO`);
                return response.data;
            } else {
                throw new Error('Token not available');
            }
        } catch (error) {
            return error.response?.data || { success: false, message: error.message };
        }
    },

    updateB2BInventoryPOQuantity: async (quantities) => {
        try {
            const token = localStorage.getItem('x-access-token');
            if (token) {
                axiosInstance.defaults.headers.common['x-access-token'] = token;
                const response = await axiosInstance.post(`${BASE_URL}/updateB2BInventoryPOQuantity`, quantities);
                return response.data;
            } else {
                throw new Error('Token not available');
            }
        } catch (error) {
            return {
                success: false,
                message: error.response ? error.response.data : error.message,
            };
        }
    },

    getUniquePendingB2BInventoryPOIds: async () => {
        try {
            const token = localStorage.getItem('x-access-token');
            if (token) {
                axiosInstance.defaults.headers.common['x-access-token'] = token;
                const response = await axiosInstance.get(`${BASE_URL}/getUniquePendingB2BInventoryPOIds`);
                return response.data;
            } else {
                throw new Error('Token not available');
            }
        } catch (error) {
            return error.response?.data || { success: false, message: error.message };
        }
    },
};