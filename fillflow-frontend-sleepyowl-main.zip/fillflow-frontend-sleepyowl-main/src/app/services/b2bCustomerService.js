import axios from 'axios';
import { BASE_URL } from '../utils/assets';
import { axiosInstance } from '../utils/assets';


export const b2bCustomerService = {
    createB2BCustomer: async (data) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.post(
              `${BASE_URL}/createB2BCustomer`,
              data
            );
            return response.data;
          }
        } catch (error) {
          return error.response.data;
        }
      },
      updateB2BCustomerById: async (data) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.put(
              `${BASE_URL}/updateB2BCustomerById`,
              data
            );
            return response.data;
          }
        } catch (error) {
          return error.response.data;
        }
      },
      getAllB2BCustomers: async () => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.get(`${BASE_URL}/getAllB2BCustomers`);
            return response.data;
          } else {
            throw new Error('Token not available');
          }
        } catch (error) {
          return error.response.data;
        }
      },
      getB2BCustomerDetailsById: async (customerId) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.get(
              `${BASE_URL}/getB2BCustomerDetails/${customerId}`
            );
            return response.data;
          } else {
            throw new Error('Token not available');
          }
        } catch (error) {
          return error.response ? error.response.data : { message: 'Error occurred' };
        }
      },
      bulkInwardB2BCustomersByCSV: async (formData) => {
   
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            const config = {
              headers: {
                'content-type': 'multipart/form-data',
                'x-access-token': token,
              },
            };
    
            
            const response = await axiosInstance.post(
              `${BASE_URL}/bulkInwardB2BCustomersByCSV`,
              formData,
              config
            );
            return response.data;
          }
        } catch (error) {
          return error.response.data;
        }
      },
}