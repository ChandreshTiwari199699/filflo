import axios from "axios";
import { BASE_URL } from "../utils/assets";
import { axiosInstance } from "../utils/assets";

export const b2bOrderService = {
    createB2BOrder: async (data) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.post(
              `${BASE_URL}/createB2BOrder`,
              data
            );
            return response.data;
          }
        } catch (error) {
          return error.response.data;
        }
      },
      getAllB2BOrders: async ({
        page = 1,
        limit = 10,
        searchText = '',
        filter = 'allOrders',
        dayFilter = 'all',
        startDate = '',
        endDate = ''
      }) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (!token) {
            throw new Error('Token not available');
          }

          axiosInstance.defaults.headers.common['x-access-token'] = token;
          const response = await axiosInstance.get(`${BASE_URL}/getAllB2BOrders`, {
            params: {
              page,
              limit,
              searchText,
              filter,
              dayFilter,
              ...(startDate && { startDate }),
              ...(endDate && { endDate })
            }
          });

          return response.data;
        } catch (error) {
          console.error('Error in getAllB2BOrders:', error);
          throw error;
        }
      },
        getAllB2BOrdersForDownload: async ({
    searchText = '',
    filter = 'allOrders',
    dayFilter = 'all',
    startDate = '',
    endDate = ''
  }) => {
    try {
      const token = localStorage.getItem('x-access-token');
      if (!token) {
        throw new Error('Token not available');
      }

      axiosInstance.defaults.headers.common['x-access-token'] = token;
      const response = await axiosInstance.get(`${BASE_URL}/getAllB2BOrdersForDownload`, {
        params: {
          searchText,
          filter,
          dayFilter,
          ...(startDate && { startDate }),
          ...(endDate && { endDate })
        }
      });

      return response.data;
    } catch (error) {
      console.error('Error in getAllB2BOrdersForDownload:', error);
      throw error;
    }
  },
  getAllB2BOrdersForDownload: async ({
    searchText = '',
    filter = 'allOrders',
    dayFilter = 'all',
    startDate = '',
    endDate = ''
  }) => {
    try {
      const token = localStorage.getItem('x-access-token');
      if (!token) {
        throw new Error('Token not available');
      }

      axiosInstance.defaults.headers.common['x-access-token'] = token;
      const response = await axiosInstance.get(`${BASE_URL}/getAllB2BOrdersForDownload`, {
        params: {
          searchText,
          filter,
          dayFilter,
          ...(startDate && { startDate }),
          ...(endDate && { endDate })
        }
      });

      return response.data;
    } catch (error) {
      console.error('Error in getAllB2BOrdersForDownload:', error);
      throw error;
    }
  },
      getAllB2BOrderInvoices: async ({
        page = 1,
        limit = 50,
        searchText = '',
        filter = 'allOrders',
        dayFilter = 'all',
        startDate = '',
        endDate = ''
      }) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (!token) {
            throw new Error('Token not available');
          }

          axiosInstance.defaults.headers.common['x-access-token'] = token;
          const response = await axiosInstance.get(`${BASE_URL}/getAllB2BOrderInvoices`, {
            params: {
              page,
              limit,
              searchText,
              filter,
              dayFilter,
              ...(startDate && { startDate }),
              ...(endDate && { endDate })
            }
          });

          return response.data;
        } catch (error) {
          console.error('Error in getAllB2BOrderInvoices:', error);
          throw error;
        }
      },

      getAllB2BOrderInvoicesForDownload: async ({
        searchText = '',
        filter = 'allOrders',
        dayFilter = 'all',
        startDate = '',
        endDate = ''
      }) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (!token) {
            throw new Error('Token not available');
          }
    
          axiosInstance.defaults.headers.common['x-access-token'] = token;
          const response = await axiosInstance.get(`${BASE_URL}/getAllB2BOrderInvoicesForDownload`, {
            params: {
              searchText,
              filter,
              dayFilter,
              ...(startDate && { startDate }),
              ...(endDate && { endDate })
            }
          });
    
          return response.data;
        } catch (error) {
          console.error('Error in getAllB2BOrdersForDownload:', error);
          throw error;
        }
      },

      getAllB2BOrderByB2BCustomerId: async (customerId) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
            const response = await axiosInstance.get(`${BASE_URL}/getAllB2BOrderByB2BCustomerId`,
              { params: { customerId } } 
            );
            return response.data;
          } else {
            throw new Error('Token not available');
          }
        } catch (error) {
          console.log('errro===', error);
        }
      },

      editB2BOrderByOrderInternalId: async (data) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
      
            const response = await axiosInstance.patch(
              `${BASE_URL}/editB2BOrderByInternalId`, 
              data 
            );
            return response.data;
          } else {
            throw new Error('Token not available');
          }
        } catch (error) {
          console.error('Error in editOrderByOrderInternalId:', error); 
          return { success: false, error: error.message, message: error.response.data.message|| 'An error occurred' }; 
        }
      },
      deleteB2BOrderByOrderId: async (orderInternalId) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
      
            const response = await axiosInstance.patch(
              `${BASE_URL}/deleteB2BOrderById/`,
              { orderInternalId } // Correct payload format
            );
      
            return response.data;
          } else {
            throw new Error('Token not available');
          }
        } catch (error) {
          console.error('Error in deleteOrderByOrderId:', error);
          return error.response ? error.response.data : { success: false, error: 'Network or unexpected error occurred' };
        }
      },
      getB2BOrderByOrderId: async (id) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
      
            const response = await axiosInstance.get(
              `${BASE_URL}/getB2BOrderByOrderId`, {
                params: { id }
              }
            );
            return response.data;
          } else {
            throw new Error('Token not available');
          }
        } catch (error) {
          return error.response.data;
        }
      },
      fulfillB2BOrderByOrderId: async (values, orderId) => { // Accept orderId as a parameter
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
      
            const response = await axiosInstance.patch(
              `${BASE_URL}/fulfillB2BOrderByOrderId/${orderId}`, // Include orderId in the URL
              values
            );
            return response.data;
          } else {
            throw new Error('Token not available');
          }
        } catch (error) {
          console.error('Error in fulfillOrderByOrderId:', error); // Log the error for debugging
          return { success: false, error: error.message || 'An error occurred' }; // Ensure to return a structured response
        }
      },
      createB2BOrderByZeptoCSV: async (formData) => {
 
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            const config = {
              headers: {
                'content-type': 'multipart/form-data',
                'x-access-token': token,
              },
            };

            
            const response = await axiosInstance.post(
              `${BASE_URL}/createB2BOrderByZeptoCSV`,
              formData,
              config
            );
            return response.data;
          }
        } catch (error) {
          return error.response.data;
        }
      },
      createB2BOrderBySwiggyCSV: async (formData) => {
 
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            const config = {
              headers: {
                'content-type': 'multipart/form-data',
                'x-access-token': token,
              },
            };

            
            const response = await axiosInstance.post(
              `${BASE_URL}/createB2BOrderBySwiggyCSV`,
              formData,
              config
            );
            return response.data;
          }
        } catch (error) {
          return error.response.data;
        }
      },
      createB2BOrderByBlinkitCSV: async (formData) => {
 
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            const config = {
              headers: {
                'content-type': 'multipart/form-data',
                'x-access-token': token,
              },
            };

            
            const response = await axiosInstance.post(
              `${BASE_URL}/createB2BOrderByBlinkitCSV`,
              formData,
              config
            );
            return response.data;
          }
        } catch (error) {
          return error.response.data;
        }
      },

      createB2BOrderByCustomCSV: async (formData) => {
 
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            const config = {
              headers: {
                'content-type': 'multipart/form-data',
                'x-access-token': token,
              },
            };

            
            const response = await axiosInstance.post(
              `${BASE_URL}/createB2BOrderByCustomCSV`,
              formData,
              config
            );
            return response.data;
          }
        } catch (error) {
          return error.response.data;
        }
      },


      transformOrderToEinvoice: async (data) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (token) {
            axiosInstance.defaults.headers.common['x-access-token'] = token;
      
            const response = await axiosInstance.get(
              `${BASE_URL}/transformOrderToEinvoice`, 
              data 
            );
            return response.data;
          } else {
            throw new Error('Token not available');
          }
        } catch (error) {
          console.error('Error in editOrderByOrderInternalId:', error); 
          return { success: false, error: error.message || 'An error occurred' }; 
        }
      },

      getB2BOrderStatusCounts: async ({
        searchText = '',
        filter = 'allOrders',
        dayFilter = 'all',
        startDate = '',
        endDate = ''
      }) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (!token) {
            throw new Error('Token not available');
          }

          axiosInstance.defaults.headers.common['x-access-token'] = token;
          const response = await axiosInstance.get(`${BASE_URL}/getB2BOrderStatusCounts`, {
            params: {
              searchText,
              filter,
              dayFilter,
              ...(startDate && { startDate }),
              ...(endDate && { endDate })
            }
          });

          return response.data;
        } catch (error) {
          console.error('Error in getB2BOrderStatusCounts:', error);
          return {
            success: false,
            data: {
              total: 0,
              open: 0,
              approved: 0,
              picked: 0,
              in_transit: 0,
              delivered: 0,
              rto: 0
            }
          };
        }
      },

      cancelInvoice: async (data) => {
        try {
          const token = localStorage.getItem('x-access-token');
          if (!token) {
            throw new Error('Token not available');
          }

          axiosInstance.defaults.headers.common['x-access-token'] = token;
          const response = await axiosInstance.post(`${BASE_URL}/cancelInvoice`, data);
          return response.data;
        } catch (error) {
          console.error('Error in cancelInvoice:', error);
          return {
            success: false,
            error: error.response?.data?.message || error.message || 'Failed to cancel invoice'
          };
        }
      },

};     