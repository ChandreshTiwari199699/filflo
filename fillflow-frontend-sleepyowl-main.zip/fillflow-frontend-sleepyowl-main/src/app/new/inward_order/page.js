"use client";
import React, { useState } from "react";
import { items } from '@/app/utils/sidebarItems';
import InwardProductsToInventory from "@/app/components/InwardProductsToInventory/InwardProductsToInventory"
import TitleBar from "@/app/components/TitleBar/TitleBar";
import NavigationBar from "@/app/components/NavigationBar/NavigationBar";
import RightSidebar from '@/app/components/RightSidebar/RightSidebar';
import GenerateQrCodeComponent from "@/app/components/GenerateQrCodeComponent/GenerateQrCodeComponent";
import {
  PrimaryButton,
  SecondaryButton,
} from "@/app/components/ButtonComponent/ButtonComponent";


const Page = () => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [sidebarContent, setSidebarContent] = useState(null);
  const [numberOfTextFields, setNumberOfTextFields] = useState(0);
  const [inputValue, setInputValue] = useState("");

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleButtonClick = (e) => {
    e.preventDefault()
    console.log("clicked");
    // setNumberOfTextFields(parseInt(inputValue, 10) || 0);
    setNumberOfTextFields(5)
  };
   const generateNavItems = () => {
        
        const inventoryTeam = items.find(item => item.label === "Inventory");
      
        if (inventoryTeam && inventoryTeam.subItems) {
          return inventoryTeam.subItems.map(subItem => ({
            name: subItem.label,
            path: subItem.path,
            icon: subItem.iconKey,
          }));
        }
      
        return [];
      };
      
      const navItems = generateNavItems();

      const handleSidebarContent = (actionType) => {
        switch (actionType) {
          case "generateQr":
            setSidebarContent(
              <GenerateQrCodeComponent onCancel={() => setIsSidebarOpen(false)} />
            );
            setIsSidebarOpen(true);
            break;
    
          default:
            setIsSidebarOpen(false);
        }
        // Open the sidebar
      };
  
  
      const buttons = [
        <SecondaryButton
          title="Generate QR"
          onClick={() => {
            setIsSidebarOpen(true);
            handleSidebarContent("generateQr");
          }}
          size="medium"
        >
        </SecondaryButton>,
    
      ];



return (
  <div className="relative w-full h-full overflow-scroll scrollbar-none bg-[#f9fafc]">
    <div className="relative z-10 flex flex-col items-center overflow-scroll scrollbar-none px-4 py-2">
      <div className="w-full max-w-full mb-4">
        <TitleBar title="Inward Products To Inventory"   />
      </div>


      <div className='w-full max-w-full mb-5'>
      <NavigationBar navItems={navItems} />
      </div>

      <div className="flex w-full max-w-full mb-6 scrollbar-none">
        <div className="flex-1 rounded-lg  bg-gray-1 overflow-y-auto scrollbar-none">
        < InwardProductsToInventory />
        </div>
      </div>
    </div>
    <RightSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)} // Close the sidebar
      >
        {sidebarContent}
      </RightSidebar>
  </div>
);
};

export default Page;
