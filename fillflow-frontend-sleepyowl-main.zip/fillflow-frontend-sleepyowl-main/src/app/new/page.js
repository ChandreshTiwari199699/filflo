import React from 'react';

const NewPage = () => {
    return (
        <div>
            <h1>Welcome to the New Page</h1>
            <p>This is a basic React page.</p>
        </div>
    );
};

export default NewPage;