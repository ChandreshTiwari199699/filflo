'use client';
import React, { useState, useEffect } from 'react';
import { items } from '@/app/utils/sidebarItems';
import OutwardProductionPOFromStorage from '@/app/components/OutwardProductionPOFromStorage/OutwardProductionPOFromStorage';
import { productionPOServices } from '@/app/services/productionPOService';
import TitleBar from '@/app/components/TitleBar/TitleBar';
import StatusBar from '@/app/components/StatusBar/StatusBar';
import NavigationBar from  '@/app/components/NavigationBar/NavigationBar';

const page = () => {
  const [productionPO, setproductionPO] = useState([]);
  const getAllProductionPO = async () => {
    try {
      const response = await productionPOServices.getAllProductionPO();
      if (response.success === true) {
        setproductionPO(response.data);
      }
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    getAllProductionPO();
  }, []);


  const calculateStatusBarData = (poData) => {
    let pendingPOCount = 0;
    let fulfilledPOCount = 0;

    poData.forEach((po) => {
      const { status } = po;
      if (status === "pending") pendingPOCount++;
      if (status === "fulfilled") fulfilledPOCount++;
    });

    return [
      { value: pendingPOCount, heading: "Pending POs" },
      { value: fulfilledPOCount, heading: "Fulfilled POs" },
    ];
  };

  const statusBarData = calculateStatusBarData(productionPO);

  const generateNavItems = () => {
      
      const inventoryTeam = items.find(item => item.label === "Storage");
    
      if (inventoryTeam && inventoryTeam.subItems) {
        return inventoryTeam.subItems.map(subItem => ({
          name: subItem.label,
          path: subItem.path,
          icon: subItem.iconKey,
        }));
      }
    
      return [];
    };
    
    const navItems = generateNavItems();



  return (
    <div className="relative w-full h-full overflow-scroll scrollbar-none bg-[#f9fafc]">
      <div className="relative z-10 flex flex-col items-center overflow-scroll scrollbar-none px-4 py-2">
        <div className="w-full max-w-full mb-4">
          <TitleBar title="Storage" />
        </div>

        <div className="w-full max-w-full mb-5">
          <StatusBar data={statusBarData} />
        </div>

        <div className='w-full max-w-full mb-5'>
        <NavigationBar navItems={navItems} />
        </div>

        <div className="flex w-full max-w-full mb-6 scrollbar-none">
          <div className="flex-1 rounded-lg  bg-gray-1 overflow-y-auto scrollbar-none">
            <OutwardProductionPOFromStorage />
          </div>
        </div>
      </div>
    </div>
  );
};

export default page;
