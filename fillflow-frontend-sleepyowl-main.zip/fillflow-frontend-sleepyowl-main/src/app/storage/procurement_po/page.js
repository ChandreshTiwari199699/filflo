'use client';
import React, { useState, useEffect } from 'react';
import { procurementPOServices } from '@/app/services/procurementPOService';
import { useDispatch, useSelector } from 'react-redux';
import {
    getAllProcurementPOFailure,
    getAllProcurementPORequest,
    getAllProcurementPOSuccess
} from '../../Actions/procurementPOActions';
import ProcurementPOTable from '@/app/components/ProcurementPOTable/ProcurementPOTable';
import NavigationBar from '@/app/components/NavigationBar/NavigationBar';
import { items } from '@/app/utils/sidebarItems';
import StatusBar from "@/app/components/StatusBar/StatusBar";
import TitleBar from "@/app/components/TitleBar/TitleBar";
import CreateProcurementPO from '@/app/components/CreateProcurementPO/CreateProcurementPO';
import RightSidebar from '@/app/components/RightSidebar/RightSidebar';
import { PrimaryButton } from '@/app/components/ButtonComponent/ButtonComponent';

const page = () => {
      const [isSidebarOpen, setIsSidebarOpen] = useState(false);
      const [sidebarContent, setSidebarContent] = useState(null);
  const dispatch = useDispatch();

  const getAllProcurementPOs = async () => {
    try {
      dispatch(getAllProcurementPORequest());
      const response = await procurementPOServices.getAllProcurementPOs();
      if (response.success === true) {
        dispatch(getAllProcurementPOSuccess(response.data));
      }
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    getAllProcurementPOs();
  }, []);

  const { allPOs } = useSelector((state) => state.procurementPO);

     const buttons = [
          <PrimaryButton
          title="Raise Procurement PO"
          onClick={() => {
            setIsSidebarOpen(true);
            handleSidebarContent("raisePO");
          }}
          size="medium"
        >
        </PrimaryButton>,
    
      
        ];


          const handleSidebarContent = (actionType) => {
            switch (actionType) {
              case "raisePO":
                setSidebarContent(
                  <CreateProcurementPO onCancel={() => setIsSidebarOpen(false)} />
                );
                setIsSidebarOpen(true);
                break;
        
        
              default:
                setIsSidebarOpen(false);
            }
            // Open the sidebar
          };

  
          const calculateStatusBarData = (allPOs) => {
            let pendingCount = 0;
            let partialCount = 0;
            let fulfilledCount = 0;
            let cancelledCount = 0;
          
            allPOs.forEach((po) => {
              switch (po.status) {
                case "pending":
                  pendingCount++;
                  break;
                case "partially_fulfilled":
                  partialCount++;
                  break;
                case "fulfilled":
                  fulfilledCount++;
                  break;
                case "cancelled":
                  cancelledCount++;
                  break;
                default:
                  break;
              }
            });
          
            return [
              { value: allPOs.length, heading: "Total POs" },
              { value: pendingCount, heading: "Pending" },
              { value: partialCount, heading: "Partially Fulfilled" },
              { value: fulfilledCount, heading: "Fulfilled" },
              { value: cancelledCount, heading: "Cancelled" },
            ];
          };
          

  const statusBarData = calculateStatusBarData(allPOs);

  const generateNavItems = () => {
    
    const storageTeam = items.find(item => item.label === "Storage");
  
    if (storageTeam && storageTeam.subItems) {
      return storageTeam.subItems.map(subItem => ({
        name: subItem.label,
        path: subItem.path,
        icon: subItem.iconKey,
      }));
    }
  
    return [];
  };

  const navItems = generateNavItems();

  return (
    <div className="relative w-full h-full overflow-scroll scrollbar-none bg-[#f9fafc]">
    <div className="relative z-10 flex flex-col items-center overflow-scroll scrollbar-none px-4 py-2">
      <div className="w-full max-w-full mb-4">
        <TitleBar title="Storage"  buttons={buttons} />
      </div>

      <div className="w-full max-w-full mb-5">
        <StatusBar data={statusBarData} />
      </div>

      <div className='w-full max-w-full mb-5'>
      <NavigationBar navItems={navItems} />
      </div>

      <div className="flex w-full max-w-full mb-6 scrollbar-none">
        <div className="flex-1 rounded-lg  bg-gray-1 overflow-y-auto scrollbar-none">
          <ProcurementPOTable />
        </div>
      </div>
    </div>
    <RightSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)} // Close the sidebar
      >
        {sidebarContent}
      </RightSidebar>
  </div>
  );
};

export default page;
