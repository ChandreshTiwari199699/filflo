"use client";
import React, { useEffect, useState } from 'react';
import { b2bOrderService } from '@/app/services/b2bOrderService';
import TitleBar from "@/app/components/TitleBar/TitleBar";
import CreateB2BOrderForm from '@/app/components/CreateB2BOrderForm/CreateB2BOrderForm';
import InwardB2BOrderCSV from '@/app/components/InwardB2BOrderCSV/InwardB2BOrderCSV';
import POTypeDropdown from '@/app/components/POTypeDropdown/POTypeDropdown';
import StatusBarOrder from '@/app/components/StatusBarOrder/StatusBarOrder';
import RightSidebar from '@/app/components/RightSidebar/RightSidebar';
import B2BOrdersTables from '@/app/components/B2BOrdersTables/B2BOrdersTables';
import RaiseCreditNoteForm from '@/app/components/RaiseCreditNoteForm/RaiseCreditNoteForm';

const page = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarContent, setSidebarContent] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState("Raise B2B Order PO");
  const [statusCounts, setStatusCounts] = useState({
    total: 0,
    open: 0,
    approved: 0,
    picked: 0,
    in_transit: 0,
    delivered: 0,
    rto: 0
  });
  const [filters, setFilters] = useState({
    searchText: '',
    filter: 'allOrders',
    dayFilter: 'all',
    startDate: '',
    endDate: ''
  });

  const fetchStatusCounts = async () => {
    try {
      const response = await b2bOrderService.getB2BOrderStatusCounts({
        searchText: filters.searchText,
        filter: filters.filter,
        dayFilter: filters.dayFilter,
        startDate: filters.startDate,
        endDate: filters.endDate
      });
      if (response.success) {
        setStatusCounts(response.data);
      }
    } catch (error) {
      console.error('Error fetching status counts:', error);
    }
  };

  useEffect(() => {
    fetchStatusCounts();
  }, [filters]);

  const handleSidebarContent = (actionType) => {
    switch (actionType) {
      case "customOrder":
        setSidebarContent(
          <CreateB2BOrderForm onCancel={() => setIsSidebarOpen(false)} />
        );
        setIsSidebarOpen(true);
        break;
      case "inwardByCSV":
        setSidebarContent(
          <InwardB2BOrderCSV onCancel={() => setIsSidebarOpen(false)} />
        );
        setIsSidebarOpen(true);
        break;
      case "raiseCreditNote":
        setSidebarContent(
          <RaiseCreditNoteForm onCancel={() => setIsSidebarOpen(false)} />
        );
        setIsSidebarOpen(true);
        break;
      default:
        setIsSidebarOpen(false);
    }
  };

  const allOptions = [
    { value: "raiseB2BOrderPO", label: "Raise B2B Order PO" },
    { value: "customOrder", label: "Create Custom Order" },
    { value: "inwardByCSV", label: "Inward By CSV" }
  ];

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleOptionSelect = (option) => {
    if (option.value !== "raiseB2BOrderPO") {
      handleSidebarContent(option.value);
    }
    setIsOpen(false);
  };

  const visibleOptions = isOpen
    ? allOptions.filter((option) => option.value !== "raiseB2BOrderPO")
    : allOptions;

  const buttons = [
    <div key="buttonGroup" className="flex gap-2">
          <button
        onClick={() => handleSidebarContent("raiseCreditNote")}
        className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        Raise Credit Note
      </button>
      <POTypeDropdown
        key="poTypeDropdown"
        options={allOptions}
        selectedOption={selectedOption}
        onOptionSelect={handleOptionSelect}
        onToggle={handleToggle}
        isOpen={isOpen}
        visibleOptions={visibleOptions}
      />
  
    </div>
  ];

  const handleFilterChange = (newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  return (
    <div className="relative w-full h-full overflow-scroll scrollbar-none bg-[#f9fafc]">
      <div className="relative z-10 flex flex-col items-center overflow-scroll scrollbar-none px-4 py-2">
        <div className="w-full max-w-full mb-4">
          <TitleBar title="B2B Orders" buttons={buttons} />
        </div>

        <div className="w-full max-w-full mb-5">
          <StatusBarOrder
            pending={statusCounts.open}
            approved={statusCounts.approved}
            picked={statusCounts.picked}
            dispatched={statusCounts.in_transit}
            delivered={statusCounts.delivered}
            rto={statusCounts.rto}
          />
        </div>

        <div className="flex w-full max-w-full mb-6 scrollbar-none">
          <div className="flex-1 rounded-lg bg-gray-1 overflow-y-auto scrollbar-none">
            <B2BOrdersTables onFilterChange={handleFilterChange} />
          </div>
        </div>
      </div>
      
      <RightSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      >
        {sidebarContent}
      </RightSidebar>
    </div>
  );
};

export default page;