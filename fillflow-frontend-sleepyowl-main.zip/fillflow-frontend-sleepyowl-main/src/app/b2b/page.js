import React from 'react';

function Page() {
    return (
        <div>
            <h1>Hello, World!</h1>
            <p>This is a basic React page.</p>
        </div>
    );
}

export default Page;