import {
    GET_ALL_B2B_ORDERS_FAILURE,
    GET_ALL_B2B_ORDERS_REQUEST,
    GET_ALL_B2B_ORDERS_SUCCESS,
    GET_B2BORDERBY_ORDERID_FAILURE,
    GET_B2BORDERBY_ORDERID_REQUEST,
    GET_B2BORDERBY_ORDERID_SUCCESS,
   } from '../constants/b2bOrderConstant';


const initialState = {
    loading: false,
    allB2BOrders: [],
    orderDetail: null,
    error: null,
  };
  
  export const b2bOrderReducer = (state = initialState, action) => {
    switch (action.type) {
      case GET_ALL_B2B_ORDERS_REQUEST:
        return { ...state, loading: true, error: null, message: action.payload };
  
      case GET_ALL_B2B_ORDERS_SUCCESS:
        return {
          ...state,
          loading: false,
          message: action.payload,
          allB2BOrders: action.payload,
          error: null,
        };
  
      case GET_ALL_B2B_ORDERS_FAILURE:
        return { ...state, loading: false, error: action.payload, message: null };

      case GET_B2BORDERBY_ORDERID_REQUEST:
          return { ...state, loading: true, error: null, message: action.payload };
      
      case GET_B2BORDERBY_ORDERID_SUCCESS:
        return {
          ...state,
          loading: false,
          message: action.payload,
          orderDetail: action.payload,
          error: null,
        };

      case GET_B2BORDERBY_ORDERID_FAILURE:
        return { ...state, loading: false, error: action.payload, message: null };
      default:
        return state;
    }

   
  };