import {
    GET_ALL_SKU_REQUEST,
    GET_ALL_SKU_SUCCESS,
    GET_ALL_SKU_FAILURE,
    GET_SKU_BY_CATEGORY_REQUEST,
    GET_SKU_BY_CATEGORY_SUCCESS,
    GET_SKU_BY_CATEGORY_FAILURE,
    CREATE_SKU_REQUEST,
    CREATE_SKU_SUCCESS,
    CREATE_SKU_FAILURE,
  } from "../constants/skuConstants";
  
  const initialState = {
    loading: false,
    allSKUs: [],
    skusByCategory: [],
    createdSKU: null,
    error: null,
  };
  
  export const skuReducer = (state = initialState, action) => {
    switch (action.type) {
      case GET_ALL_SKU_REQUEST:
        return { ...state, loading: true, error: null };
  
      case GET_ALL_SKU_SUCCESS:
        return { ...state, loading: false, allSKUs: action.payload, error: null };
  
      case GET_ALL_SKU_FAILURE:
        return { ...state, loading: false, error: action.payload };
  
      case GET_SKU_BY_CATEGORY_REQUEST:
        return { ...state, loading: true, error: null };
  
      case GET_SKU_BY_CATEGORY_SUCCESS:
        return {
          ...state,
          loading: false,
          skusByCategory: action.payload,
          error: null,
        };
  
      case GET_SKU_BY_CATEGORY_FAILURE:
        return { ...state, loading: false, error: action.payload };
  
      case CREATE_SKU_REQUEST:
        return { ...state, loading: true, error: null };
  
      case CREATE_SKU_SUCCESS:
        return { ...state, loading: false, createdSKU: action.payload, error: null };
  
      case CREATE_SKU_FAILURE:
        return { ...state, loading: false, error: action.payload };
  
      default:
        return state;
    }
  };
  