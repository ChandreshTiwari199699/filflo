import {
      GET_ALL_PRODUCT_LOGS_FAILURE,
      GET_ALL_PRODUCT_LOGS_REQUEST,
      GET_ALL_PRODUCT_LOGS_SUCCESS,
  } from '../constants/productActivityLoggerConstants';

const initialState = {
    loading: false,
    productLogs: [],
    error: '',
    };

export const productActivityLoggerReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_ALL_PRODUCT_LOGS_REQUEST:
            return { ...state, loading: true, error: '' };
        case GET_ALL_PRODUCT_LOGS_SUCCESS:
            return { ...state, loading: false, productLogs: action.payload, error: '' };
        case GET_ALL_PRODUCT_LOGS_FAILURE:
            return { ...state, loading: false, productLogs: [], error: action.payload };
        default:
            return state;
    }
};

