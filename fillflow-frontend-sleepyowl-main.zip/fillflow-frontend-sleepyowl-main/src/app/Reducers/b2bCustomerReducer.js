import {
    GET_ALL_B2B_CUSTOMER_FAILURE,
    GET_ALL_B2B_CUSTOMER_REQUEST,
    GET_ALL_B2B_CUSTOMER_SUCCESS,
} from "../constants/b2bCustomerConstants";


const initialState = {
    loading: false,
    b2bCustomers: [],
    error: null,
};


export const b2bCustomerReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_ALL_B2B_CUSTOMER_REQUEST:
            return { ...state, loading: true, error: null, message: action.payload };

        case GET_ALL_B2B_CUSTOMER_SUCCESS:
            return {
                ...state,
                loading: false,
                message: action.payload,
                b2bCustomers: action.payload,
                error: null,
            };

        case GET_ALL_B2B_CUSTOMER_FAILURE:
            return { ...state, loading: false, error: action.payload, message: null };

        default:
            return state;
    }
};