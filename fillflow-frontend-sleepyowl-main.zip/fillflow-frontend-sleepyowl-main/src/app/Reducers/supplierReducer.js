import {
    GET_ALL_SUPPLIERS_REQUEST,
    GET_ALL_SUPPLIERS_SUCCESS,
    GET_ALL_SUPPLIERS_FAILURE,
  } from '../constants/supplierConstants';
  
  const initialState = {
    loading: false,
    suppliers: [],
    error: null,
    message: null,
  };
  
  export const supplierReducer = (state = initialState, action) => {
    switch (action.type) {
      case GET_ALL_SUPPLIERS_REQUEST:
        return { ...state, loading: true, error: null, message: null };
  
      case GET_ALL_SUPPLIERS_SUCCESS:
        return {
          ...state,
          loading: false,
          suppliers: action.payload,
          message: 'Suppliers fetched successfully',
          error: null,
        };
  
      case GET_ALL_SUPPLIERS_FAILURE:
        return {
          ...state,
          loading: false,
          error: action.payload,
          message: null,
        };
  
      default:
        return state;
    }
  };
  