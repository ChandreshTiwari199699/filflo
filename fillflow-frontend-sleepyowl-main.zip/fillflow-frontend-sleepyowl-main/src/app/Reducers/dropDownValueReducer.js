import {
  GET_CATEGORY_VALUE,
  GET_MATERIAL_VALUE,
  GET_MATERIAL_NAME,
  GET_VENDOR_VALUE,
  GET_PRODUCT_VALUE,
  GET_BATCH_NUMBER,
  GET_PRODUCT_NAME,
  GET_B2B_CUSTOMER_NAME,
  GET_B2B_CUSTOMER_VALUE,
  GET_SKU_NAME,
  GET_SKU_VALUE,
  GET_PRICING_STRATEGY_NAME,  
  GET_PRICING_STRATEGY_VALUE,
  GET_SUPPLIER_NAME,      
  GET_SUPPLIER_VALUE
} from "../constants/dropDownValuesConstants";

const initialState = {
  dropDownCatValue: "",
  dropDownMatValue: "",
  dropDownMatName: "",
  dropDownVendorValue: "",
  dropDownProductValue: "",
  dropDownBatchNumber: "",
  dropdownProductName: "",
  dropDownB2BCustomerValue: "",
  dropDownB2BCustomerName: "",
  dropDownSKUName: "",
  dropDownSKUValue: "",
  dropDownPricingStrategyValue: "", 
  dropDownPricingStrategyName: "", 
  dropDownSupplierValue: "",
  dropDownSupplierName: "",
};

export const dropValueReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_CATEGORY_VALUE:
      return {
        ...state,
        dropDownCatValue: action.payload,
      };

    case GET_MATERIAL_VALUE:
      return {
        ...state,
        dropDownMatValue: action.payload,
      };


      case GET_MATERIAL_NAME:
      return {
        ...state,
        dropDownMatName: action.payload,
        };
  
    case GET_VENDOR_VALUE:
      return {
        ...state,
        dropDownVendorValue: action.payload,
      };

    case GET_PRODUCT_VALUE:
      return {
        ...state,
        dropDownProductValue: action.payload,
      };

      case GET_PRODUCT_NAME:
        return {
          ...state,
          dropdownProductName: action.payload,
        };

      
    case GET_SKU_VALUE:
      return {
        ...state,
        dropDownSKUValue: action.payload,
      };

    case GET_SKU_NAME:
      return {
        ...state,
        dropDownSKUName: action.payload,
      };
    
    case GET_BATCH_NUMBER:
      return {
        ...state,
        dropDownBatchNumber: action.payload,
      };

    case GET_B2B_CUSTOMER_VALUE:
      return {
        ...state,
        dropDownB2BCustomerValue: action.payload,
      };
    
    case GET_B2B_CUSTOMER_NAME:
      return {
        ...state,
        dropDownB2BCustomerName: action.payload,
      };
      
      case GET_PRICING_STRATEGY_VALUE:
        return {
          ...state,
          dropDownPricingStrategyValue: action.payload,
        };
  
      case GET_PRICING_STRATEGY_NAME:
        return {
          ...state,
          dropDownPricingStrategyName: action.payload,
        };
  
        case GET_SUPPLIER_VALUE:
  return {
    ...state,
    dropDownSupplierValue: action.payload,
  };

case GET_SUPPLIER_NAME:
  return {
    ...state,
    dropDownSupplierName: action.payload,
  };


    default:
      return state;
    
  }
};
