"use client";
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { items } from '@/app/utils/sidebarItems';
import TitleBar from "@/app/components/TitleBar/TitleBar";
import NavigationBar from '@/app/components/NavigationBar/NavigationBar';
import InvoiceTable from '@/app/components/InvoiceTable/InvoiceTable';
import {
  getAllB2BOrdersFailure,
  getAllB2BOrdersRequest,
  getAllB2BOrdersSuccess,
} from '../../Actions/b2bOrderActions';
import { b2bOrderService } from '@/app/services/b2bOrderService';


const page = () => {

  const dispatch = useDispatch ();



  const generateNavItems = () => {
    const b2bOrderTeam = items.find((item) => item.label === "Report");

    if (b2bOrderTeam && b2bOrderTeam.subItems) {
      return b2bOrderTeam.subItems.map((subItem) => ({
        name: subItem.label,
        path: subItem.path,
        icon: subItem.iconKey,
      }));
    }

    return [];
  };

  const navItems = generateNavItems();



  

  return (
    <div className="relative w-full h-full overflow-scroll scrollbar-none bg-[#f9fafc]">
    <div className="relative z-10 flex flex-col items-center overflow-scroll scrollbar-none px-4 py-2">
      <div className="w-full max-w-full mb-4">
        <TitleBar title="Reports"/>
      </div>


      <div className="w-full max-w-full mb-5">
        <NavigationBar navItems={navItems} />
      </div>

      <div className="flex w-full max-w-full mb-6 scrollbar-none">
        <div className="flex-1 rounded-lg  bg-gray-1 overflow-y-auto scrollbar-none">
          <InvoiceTable/>
        </div>
      </div>
    </div>
  </div>
 
  );
};

export default page;