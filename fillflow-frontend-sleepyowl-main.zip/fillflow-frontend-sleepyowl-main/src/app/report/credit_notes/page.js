"use client";
import React, {  useState } from 'react';
import { items } from '@/app/utils/sidebarItems';
import TitleBar from "@/app/components/TitleBar/TitleBar";
import NavigationBar from '@/app/components/NavigationBar/NavigationBar';
import CreditNotesTable from '@/app/components/CreditNotesTable/CreditNotesTable';
import RightSidebar from '@/app/components/RightSidebar/RightSidebar';
import RaiseCreditNoteForm from '@/app/components/RaiseCreditNoteForm/RaiseCreditNoteForm';


const page = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarContent, setSidebarContent] = useState(null);

  const handleSidebarContent = (actionType) => {
    if (actionType === "raiseCreditNote") {
      setSidebarContent(
        <RaiseCreditNoteForm onCancel={() => setIsSidebarOpen(false)} />
      );
      setIsSidebarOpen(true);
    }
  };

  const buttons = [
    <button
      key="raiseCreditNote"
      onClick={() => handleSidebarContent("raiseCreditNote")}
      className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
    >
      Raise Credit Note
    </button>
  ];

  const generateNavItems = () => {
    const b2bOrderTeam = items.find((item) => item.label === "Report");

    if (b2bOrderTeam && b2bOrderTeam.subItems) {
      return b2bOrderTeam.subItems.map((subItem) => ({
        name: subItem.label,
        path: subItem.path,
        icon: subItem.iconKey,
      }));
    }

    return [];
  };

  const navItems = generateNavItems();



  

  return (
    <div className="relative w-full h-full overflow-scroll scrollbar-none bg-[#f9fafc]">
    <div className="relative z-10 flex flex-col items-center overflow-scroll scrollbar-none px-4 py-2">
      <div className="w-full max-w-full mb-4">
        <TitleBar title="Reports" buttons={buttons} />
      </div>


      <div className="w-full max-w-full mb-5">
        <NavigationBar navItems={navItems} />
      </div>

      <div className="flex w-full max-w-full mb-6 scrollbar-none">
        <div className="flex-1 rounded-lg  bg-gray-1 overflow-y-auto scrollbar-none">
          <CreditNotesTable/>
        </div>
      </div>
    </div>
    
    <RightSidebar
      isOpen={isSidebarOpen}
      onClose={() => setIsSidebarOpen(false)}
    >
      {sidebarContent}
    </RightSidebar>
  </div>
 
  );
};

export default page;