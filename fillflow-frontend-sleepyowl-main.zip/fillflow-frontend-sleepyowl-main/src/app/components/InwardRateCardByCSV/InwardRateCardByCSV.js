'use client';
import React, { useState } from "react";
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; 
import { pricingStrategyService } from '@/app/services/pricingStratergyService';
import {
    PrimaryButton,
    SecondaryButton,
} from "@/app/components/ButtonComponent/ButtonComponent";


const InwardRateCardByCSV = ({ onCancel }) => {
    const [rateCardName, setRateCardName] = useState("");
    const [uploadedFile, setUploadedFile] = useState(null);
    const [errorMessage, setErrorMessage] = useState("");
    const [loading, setLoading] = useState(false);

    const handleRateCardNameChange = (event) => {
        setRateCardName(event.target.value);
        setErrorMessage("");
    };

    const handleFileUpload = (event) => {
        const file = event.target.files[0];
        
        if (file) {
            if (file.type === "text/csv") {
                setUploadedFile(file);
                setErrorMessage("");
            } else {
                setErrorMessage("Please upload a valid CSV file.");
                setUploadedFile(null);
            }
        }
    };

    const handleDownloadTemplate = () => {
        const link = document.createElement("a");
        link.href = "/static/Rate_Card_Tempelate.csv";
        link.download = "Rate_Card_Template.csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleSubmit = async () => {
        if (!rateCardName) {
            setErrorMessage("Please enter a rate card name before uploading.");
            return;
        }

        if (!uploadedFile) {
            setErrorMessage("Please upload a CSV file.");
            return;
        }

        setErrorMessage("");
        setLoading(true);

        try {
            const formData = new FormData();
            formData.append('rateCardName', rateCardName);
            formData.append('file', uploadedFile);

            const response = await pricingStrategyService.inwardRateCardByCSV(formData);

            if (response && response.success) {
                toast.success(`Rate Card '${rateCardName}' created successfully!`, {
                    autoClose: 2000,
                    onClose: () => {
                        setRateCardName("");
                        setUploadedFile(null);
                        window.location.reload();
                    }
                });
            } else {
                toast.error("Failed to create Rate Card: " + (response?.message || 'Unknown error'));
            }
        } catch (err) {
            console.error('Error occurred:', err);
            setUploadedFile(null);
            toast.error('An error occurred: ' + (err.message || 'Unknown error'));
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
            <ToastContainer position="bottom-center" />
            <h2 className="text-base font-semibold text-[#111928] mb-1">Create Rate Card</h2>
            <p className="text-sm font-normal text-[#4B5563] mb-6">
                Create Rate Card by entering details and submitting a filled CSV in the format provided.
            </p>
            <div className="flex flex-col mb-6">
                <label className="block text-[#111928] text-sm font-medium mb-1">
                    Enter Rate Card Name<span className="text-[#9CA3AF] ml-[2px]">*</span>
                </label>
                <input
                    type="text"
                    value={rateCardName}
                    onChange={handleRateCardNameChange}
                    className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-sm font-medium"
                    placeholder="Enter Rate Card Name"
                />
            </div>
            <div className="flex flex-col mb-6">
                <label className="block text-[#111928] text-sm font-medium mb-1">
                    Upload CSV File<span className="text-[#9CA3AF] ml-[2px]">*</span>
                </label>
                <input
                    type="file"
                    accept=".csv"
                    onChange={handleFileUpload}
                    className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-sm font-medium"
                />
                <b className="text-[#9CA3AF] text-xs mt-1">
                    Make sure you are uploading the correct CSV file.
                </b>
                {errorMessage && <p className="text-xs mt-1 ml-1 text-red-500">{errorMessage}</p>}
            </div>

            <button
                onClick={handleDownloadTemplate}
                className="text-blue-600 text-sm underline cursor-pointer mb-6"
            >
                Download Rate Card Template
            </button>
            
            <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
                <div className="flex gap-x-2">
                    <SecondaryButton title="Cancel" size='full' onClick={onCancel} />
                    <PrimaryButton title="Submit File" onClick={handleSubmit} disabled={loading} size='full' bgColor="bg-primary" />
                </div>
            </div>
        </div>
    );
};

export default InwardRateCardByCSV;
