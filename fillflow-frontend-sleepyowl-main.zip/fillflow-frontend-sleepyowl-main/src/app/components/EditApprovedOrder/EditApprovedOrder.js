"use client";
import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { PrimaryButton, SecondaryButton, PendingRed } from "@/app/components/ButtonComponent/ButtonComponent";
import Input from "@/app/components/Input/Input";
import { b2bOrderService } from "@/app/services/b2bOrderService";

const EditApprovedOrder = ({ selectedOrder, handleCancel }) => {
  const [editOrderData, setEditOrderData] = useState({
    orderInternalId: selectedOrder._id,
    orderId: selectedOrder.orderId,
    remarks: selectedOrder.remarks,
    listOfProducts: selectedOrder.listOfProducts.map((product) => ({
      ...product,
      approvedQuantity: product.approvedQuantity ,
      escalationReason: "",
    })),
  });

  const [errors, setErrors] = useState({});

  // Handle input changes
  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditOrderData((prev) => ({ ...prev, [name]: value }));
  };

  const handleApprovedQuantityChange = (e, productIndex) => {
    const newApprovedQuantity = e.target.value;
    setEditOrderData((prevState) => {
      const updatedListOfProducts = [...prevState.listOfProducts];
      updatedListOfProducts[productIndex] = {
        ...updatedListOfProducts[productIndex],
        approvedQuantity: newApprovedQuantity,
        escalationReason: newApprovedQuantity != updatedListOfProducts[productIndex].quantity ? "escalation" : "",
      };
      return { ...prevState, listOfProducts: updatedListOfProducts };
    });
  };

  const handleSaveChanges = async () => {
    const newErrors = {};

    editOrderData.listOfProducts.forEach((product, index) => {
      if (!product.approvedQuantity || product.approvedQuantity < 0) {
        newErrors[`product_${index}`] = `Approved quantity required for SKU ${product.skuCode}.`;
      } else if (product.approvedQuantity > product.quantity) {
        newErrors[`product_${index}`] = `Approved quantity cannot exceed ${product.quantity}.`;
      }
      if (product.approvedQuantity != product.quantity && !product.escalationReason.trim()) {
        newErrors[`escalation_${index}`] = `Reason required for SKU ${product.skuCode}.`;
      }
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
  
      return;
    }

    const updatedData = {
      orderInternalId: editOrderData.orderInternalId,
      orderId: editOrderData.orderId,
      remarks: editOrderData.remarks,
      updatedApprovedProducts: editOrderData.listOfProducts.map((product) => ({
        skuCode: product.skuCode,
        approvedQuantity: product.approvedQuantity,
        approvedQuantityChangeReason:
          product.approvedQuantity !== product.quantity ? product.escalationReason : null,
      })),
    };


    try {
        const result = await b2bOrderService.editB2BOrderByOrderInternalId(updatedData);
      
        if (result.success) {
          toast.success("B2B Order updated successfully!", {
            autoClose: 1500,
            onClose: () => window.location.reload(),
          });
        } else {
          // Show backend-sent message if available
          toast.error(`Failed to update order: ${result.message || result.error || "Unknown error."}`

          );
        }
      } catch (error) {
        console.error("Unexpected error in handleSaveChanges:", error);
        
        // Try to extract error message from server response
        const messageFromServer = error?.response?.data?.message || error?.message || "An unexpected error occurred.";
        toast.error(messageFromServer);
      }
      
  };

  const handleDeleteOrder = async (orderId) => {
    if (window.confirm('Are you sure you want to delete this order?')) {
      try {
        const result = await b2bOrderService.deleteB2BOrderByOrderId(orderId);
        if (result.success) {
          toast.success("Order deleted successfully!", { autoClose: 1500, onClose: () => window.location.reload() });
        } else {
          toast.error(`Failed to delete order: ${result.message}`);
        }
      } catch (error) {
        toast.error("An unexpected error occurred while deleting the order.");
      }
    }
  };

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <ToastContainer position="bottom-center" />
        <h2 className="text-base font-semibold text-[#111928] mb-1">Edit Order</h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          Modify order details, update quantities, or delete the order.
        </p>

        {/* Order ID */}
        <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">Order ID</label>
          <Input name="orderId" value={editOrderData.orderId} onChange={handleEditChange} placeholder="Edit Order ID" />
        </div>

        {/* Remarks */}
        <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">Remarks</label>
          <Input name="remarks" value={editOrderData.remarks} onChange={handleEditChange} placeholder="Edit Remarks" />
        </div>

        {/* Product Table */}
        <table className="min-w-full text-sm text-[#111928] font-medium border border-gray-300 rounded-lg">
          <thead className="text-xs text-[#111928] uppercase bg-gray-200">
            <tr>
              <th className="px-4 py-2 text-left w-1/4">SKU Code</th>
              <th className="px-4 py-2 text-left w-1/4">Desired Units</th>
              <th className="px-4 py-2 text-left w-1/4">Approved Units</th>
              <th className="px-4 py-2 text-left w-1/4">Reason</th>
            </tr>
          </thead>
          <tbody>
            {editOrderData.listOfProducts.map((product, index) => (
              <tr key={index} className="border-b">
                <td className="px-4 py-2">{product.skuCode}</td>
                <td className="px-4 py-2">{product.quantity}</td>
                <td className="px-4 py-2">
                  <input
                    type="number"
                    value={product.approvedQuantity !== null && product.approvedQuantity !== undefined ? product.approvedQuantity : ""}
                    className={`w-20 border rounded p-1 ${errors[`product_${index}`] ? "border-red-500" : ""}`}
                    onChange={(e) => handleApprovedQuantityChange(e, index)}
                  />
                  {errors[`product_${index}`] && <div className="text-red-500 text-xs mt-1">{errors[`product_${index}`]}</div>}
                </td>
                <td className="px-4 py-2">
                  <input
                    type="text"
                    value={product.escalationReason}
                    onChange={(e) => {
                      const newReason = e.target.value;
                      setEditOrderData((prevState) => {
                        const updatedListOfProducts = [...prevState.listOfProducts];
                        updatedListOfProducts[index].escalationReason = newReason;
                        return { ...prevState, listOfProducts: updatedListOfProducts };
                      });
                    }}
                    className={`w-full border rounded p-1 ${errors[`escalation_${index}`] ? "border-red-500" : ""}`}
                    disabled={product.approvedQuantity == product.quantity}
                  />
                  {errors[`escalation_${index}`] && <div className="text-red-500 text-xs mt-1">{errors[`escalation_${index}`]}</div>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Action Buttons */}
      <div className="absolute bottom-0 left-0 w-full border-t bg-white p-2 flex gap-x-3">
        <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
        <PrimaryButton title="Save Changes" onClick={handleSaveChanges} size="full" />
        <PendingRed title="Delete Order" onClick={() => handleDeleteOrder(editOrderData.orderInternalId)} size="full" />
      </div>
    </>
  );
};

export default EditApprovedOrder;


