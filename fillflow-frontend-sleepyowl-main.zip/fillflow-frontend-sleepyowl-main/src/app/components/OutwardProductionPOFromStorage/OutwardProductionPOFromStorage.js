"use client";
import React, { useState, useEffect } from "react";
import moment from "moment";
import * as Yup from "yup";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { productionPOServices } from "@/app/services/productionPOService";
import StatusComponent from "../StatusComponent/StatusComponent";
import DynamicTableWithoutAction from "@/app/components/DynamicTableWithoutAction/DynamicTableWithoutAction";
import TableFilterBar from "../TableFilterBar/TableFilterBar";
import RightSidebar from "../RightSidebar/RightSidebar";
import { SecondaryButton, PrimaryButton } from "../ButtonComponent/ButtonComponent";
import { filterByDate } from "@/app/components/DateFilter/DateFilter";
import searchNested from "@/app/utils/searchUtils";
import {
    stickyActionColumnClassname,
    stickyActionRowClassname,
  } from "@/app/utils/stickyActionClassname";

const OutwardProductionPOFromStorage = () => {
  const [productionPO, setProductionPO] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [selectedPO, setSelectedPO] = useState([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [dayFilter, setDayFilter] = useState("all");

  // Fetch Production POs
  useEffect(() => {
    const fetchProductionPOs = async () => {
      try {
        const response = await productionPOServices.getAllProductionPO();
        if (response.success) {
          setProductionPO(response.data);
        }
          console.log("🚀 ~ fetchProductionPOs ~ response.data:", response.data)
      } catch (error) {
        console.error("Error fetching production POs:", error);
      }
    };
    fetchProductionPOs();
  }, []);

  // Sort and filter data
  useEffect(() => {
    let sortedPOs = productionPO.sort(
      (a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)
    );

    sortedPOs = filterByDate(sortedPOs, dayFilter);

    if (searchText) {
      sortedPOs = sortedPOs.filter((item) =>
        searchKeys.some((key) =>
          searchNested(item[key], searchText.toLowerCase(), key)
        )
      );
    }

    setFilteredData(sortedPOs);
  }, [productionPO, searchText, dayFilter]);

  // Prevent selection of fulfilled POs
  const handleCheckboxChange = (poId) => {
    const po = filteredData.find((item) => item._id === poId);

    if (po && po.status === "fulfilled") {
      toast.error("You cannot select a fulfilled PO.", { autoClose: 2000 });
      return;
    }

    setSelectedPO((prevSelected) =>
      prevSelected.includes(poId)
        ? prevSelected.filter((id) => id !== poId)
        : [...prevSelected, poId]
    );
  };

  // Handle Outward to Storage action
  const handleOutwardPO = () => {
    if (selectedPO.length === 0) {
      toast.error("Please select at least one PO.", { autoClose: 2000 });
      return;
    }
    setIsSidebarOpen(true);
  };

  // CSV Export Function
  const convertToCSV = (data) => {
    const headers = ["PO ID", "SKU Code", "SKU Name", "Quantity", "Status"];
    const rows = data.map((po) => [
      po._id || "N/A",
      po.sku_id?.sku_code || "N/A",
      po.sku_id?.sku_name || "N/A",
      po.quantity || "N/A",
      po.status || "N/A",
    ]);

    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers.join(","), ...rows.map((row) => row.join(","))].join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Production_PO_${moment().format("DD-MMM-YYYY")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Table Configuration
  const headings = {
    checkbox: {
      label: "Select",
      isCheckbox: true,
      onChange: (row) => handleCheckboxChange(row._id),
      isSticky: false,
    },
    skuCode: {
      label: "SKU Code",
      renderCell: (row) => row.sku_id?.sku_code || "N/A",
      isSticky: false,
    },
    skuName: {
      label: "SKU Name",
      renderCell: (row) => row.sku_id?.sku_name || "N/A",
      isSticky: false,
    },
    quantity: {
      label: "Quantity",
      renderCell: (row) => row.quantity || "N/A",
      isSticky: false,
    },
   
    createdBy: {
        label: "Created By",
        renderCell: (row) => row.createdBy?.firstName || "N/A",
        isSticky: false,
        },

        fulfilledBy: {
            label: "Fulfilled By",
            renderCell: (row) => row.fulfilledBy?.firstName || "N/A",
            isSticky: false,
            },
    status: {
      label: "Status",
      renderCell: (row) => <StatusComponent status={row.status} /> || "N/A",
      isSticky: true,
      stickyClassHeader: stickyActionColumnClassname,
            stickyClassRow: stickyActionRowClassname,
    },
  };

  const searchKeys = [ "sku_id", "quantity", "status"];

  const handleSubmit = async () => {
    if (selectedPO.length === 0) {
      toast.error("No POs selected for processing.", { autoClose: 2000 });
      return;
    }
  
    try {
      // Call API to update production POs
      const response = await productionPOServices.updateProductionPO(selectedPO);
  
      if (response.success) {
        toast.success("Production POs updated successfully!", {
          autoClose: 2000,
          onClose: () => {
            setIsSidebarOpen(false);
            window.location.reload(); // Refresh the data after updating
          },
        });
      } else {
        toast.error(response.message || "Failed to update POs.", { autoClose: 2000 });
      }
    } catch (error) {
      console.error("Error updating Production POs:", error);
      toast.error(error.message || "An error occurred.", { autoClose: 2000 });
    }
  };
  
  return (
    <>
      <div className="flex gap-x-2">
        <ToastContainer />
        <div className="flex-1">
          <TableFilterBar
            convertToCSV={convertToCSV}
            allPO={productionPO}
            searchText={searchText}
            setSearchText={setSearchText}
            dayFilter={dayFilter}
            handleDayFilterChange={(e) => setDayFilter(e.target.value)}
          />
        </div>
        <PrimaryButton title="Outward to Storage" onClick={handleOutwardPO} size="medium" />
      </div>
      <DynamicTableWithoutAction headings={headings} rows={filteredData} />
      
      <RightSidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)}>
  <div className="relative h-full flex flex-col text-black">
    <ToastContainer position="bottom-center" />

    {/* Sidebar Header */}
    <div className="p-4 border-b border-gray-200">
      <h2 className="text-lg font-semibold text-[#111928]">Confirm Outward POs</h2>
      <p className="text-sm text-[#4B5563]">Confirm selected Production POs to process them.</p>
    </div>

    {/* Scrollable Content */}
    <div className="flex-1 overflow-y-auto p-4 scrollbar-none">
      {selectedPO.map((poId) => {
        const po = filteredData.find((item) => item._id === poId);
        return (
          <div key={poId} className="border p-2 mb-2 rounded-md">
            <p><strong>SKU Code:</strong> {po?.sku_id?.sku_code || "N/A"}</p>
            <p><strong>SKU Name:</strong> {po?.sku_id?.sku_name || "N/A"}</p>
            <p><strong>Quantity:</strong> {po?.quantity || "N/A"}</p>
          </div>
        );
      })}
    </div>

    {/* Footer Buttons */}
    <div className="border-t border-gray-200 bg-white p-4">
      <div className="flex gap-x-2">
        <div className="flex-1">
          <SecondaryButton title="Cancel" width="w-full" onClick={() => setIsSidebarOpen(false)} />
        </div>
        <div className="flex-1">
          <PrimaryButton title="Outward PO" width="w-full" onClick={handleSubmit} />
        </div>
      </div>
    </div>
  </div>
</RightSidebar>

    </>
  );
};

export default OutwardProductionPOFromStorage;
