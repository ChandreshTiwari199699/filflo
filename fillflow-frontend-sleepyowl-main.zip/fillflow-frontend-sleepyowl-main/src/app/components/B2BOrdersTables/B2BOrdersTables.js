'use client';
import React, { useState, useEffect } from 'react';
import moment from "moment-timezone";
import { b2bOrderService } from '@/app/services/b2bOrderService';
import searchNested from '@/app/utils/searchUtils';
import { filterByDate } from "../DateFilter/DateFilter";
import TableFilterBarWithDatePicker from '../TableFilterBarWithDatePicker/TableFilterBarWithDatePicker';
import StatusComponent from "../StatusComponent/StatusComponent";
import DynamicTableWithoutAction from '../DynamicTableWithoutAction/DynamicTableWithoutAction';
import RightSidebar from '../RightSidebar/RightSidebar';
import BigRightSidebar from '../BigRightSidebar/BigRightSidebar';
import {
  stickyActionColumnClassname,
  stickyActionRowClassname,
} from "@/app/utils/stickyActionClassname";
import ActionDropdown from '../ActionDropdown/ActionDropdown';
import ViewOrderParticular from '../ViewOrderParticular/ViewOrderParticular';
import EditOrder from '../EditOrder/EditOrder';
import EditApprovedOrder from '../EditApprovedOrder/EditApprovedOrder';
import ApproveOrderComponent from '../ApproveOrderComponent/ApproveOrderComponent';
import ReadyToShipOrderComponent from '../ReadyToShipOrderComponent/ReadyToShipOrderComponent';
import InvoiceInfoOrderComponent from '../InvoiceInfoOrderComponent/InvoiceInfoOrderComponent';
import DispatchInfoOrderComponent from '../DispatchInfoOrderComponent/DispatchInfoOrderComponent';
import DeliveryInfoOrderComponent from '../DeliveryInfoOrderComponent/DeliveryInfoOrderComponent';
import GRNInfoOrderComponent from '../GRNInfoOrderComponent/GRNInfoOrderComponent';
import CancelInvoiceComponent from '../CancelInvoiceComponent/CancelInvoiceComponent';

const B2BOrdersTables = ({ onFilterChange = () => {} }) => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState({
    total: 0,
    page: 1,
    limit: 50,
    totalPages: 0
  });
  const [filter, setFilter] = useState("allOrders");
  const [searchText, setSearchText] = useState("");
  const [dayFilter, setDayFilter] = useState("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarType, setSidebarType] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [selectedOrders, setSelectedOrders] = useState([]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const response = await b2bOrderService.getAllB2BOrders({
        page: pagination.page,
        limit: pagination.limit,
        searchText,
        filter,
        dayFilter,
        startDate,
        endDate
      });

      if (response.success) {
        setOrders(response.data);
        setPagination(prev => ({
          ...prev,
          total: response.pagination.total,
          totalPages: response.pagination.totalPages
        }));
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    // Only call onFilterChange if it exists
    if (onFilterChange) {
      onFilterChange({
        searchText,
        filter,
        dayFilter,
        startDate,
        endDate
      });
    }
  }, [pagination.page, pagination.limit, filter, searchText, dayFilter, startDate, endDate]);

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleSearchChange = (newSearchText) => {
    setSearchText(newSearchText);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleDayFilterChange = (event) => {
    setDayFilter(event.target.value);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const currentDateAndFileName = `Custom_Order_${moment().format('DD-MMM-YYYY')}`;

  const convertToCSV = (data, selectedOrders) => {
    const headers = [
      'WH', 'PO Date', 'Appointment Date','PO Expiry Date', 'Punch Date','Invoice date', 'Dispatch Date', 'Delivery Date',
      'Voucher Type', 'PO Number/Order No', 'Order Status',  'Order Remarks', 'Platform/Order Type', 'Invoice Number', 'Total Invoice Value', 'Customer', 'Customer GST','Channel',
      'State/Zone', 'City', 'Account Managers', 'Distinct Sku - Ordered', 'Qty ordered (case units)',
      'Qty ordered (in units)', 'Distinct Sku - Approved', 'Qty Approved (case units)',
      'Qty Approved (in units)', 'Distinct Sku - Fulfilled/ Dispatched', 'Qty Fulfilled / Dispatched (case units)',
      'Qty Fulfilled / Dispatched (in units)', 'Distinct Sku - GRN',
      'Qty GRN (in units)',
      
      
       
    'Short Fulfilled Quantity (SKU)', 'Short Fulfilled Quantity (Units)',
    'Short GRN Quantity (SKU)', 'Short GRN Quantity (Units)',
    
      'Ordered vs Approved % (SKU)', 'Ordered vs Approved % (Qty)',
      'Approved vs Fulfilled % (SKU)', 'Approved vs Fulfilled % (Qty)',
      'Ordered vs Fulfilled % (SKU)', 'Ordered vs Fulfilled % (Qty)',
      'Fulfilled vs GRN % (SKU)', 'Fulfilled vs GRN % (Qty)',
      'Ordered vs GRN % (SKU)', 'Ordered vs GRN % (Qty)',

      'Approval Remarks', 'WH/Fulfillment Remarks', 'GRN Remarks', 
     'Dispatch Mode', 'EDD Date', 'Carrier*', 'Tracking number', 'Box Count',
      'Tracking Link',
    ];
  
    const escapeCSVValue = (value) => {
      if (value === undefined || value === null) return '';
      const stringValue = String(value);
      return `"${stringValue.replace(/"/g, '""')}"`;
    };
  
    const formatDateTime = (dateString) => {
      if (!dateString) return '';

        // If it's an Excel serial date (numeric string or number)
        const excelSerial = parseFloat(dateString);
        if (!isNaN(excelSerial) && excelSerial > 25569) {
          const utcDays = Math.floor(excelSerial - 25569);
          const utcValue = utcDays * 86400; // seconds since Unix epoch
          const dateInfo = new Date(utcValue * 1000);

          const fractionalDay = excelSerial % 1;
          const totalSeconds = Math.round(fractionalDay * 86400);
          dateInfo.setSeconds(dateInfo.getSeconds() + totalSeconds);

          return moment(dateInfo).format("DD MMM YYYY HH:mm:ss");
        }

      const parsedDate = moment(dateString, [
        "M/D/YY H:mm",
        "DD/MM/YY",
        "DD/MM/YYYY",
        "DD/MM/YYYY HH:mm:ss", 
        "DD-MM-YYYY",          
        "D-M-YYYY",
        "YYYY-MM-DD", 
        "YYYY/MM/DD", 
        "MM/DD/YYYY", 
        "M/D/YYYY H:mm", 
        "M/D/YYYY h:mm A", "x", "X", moment.ISO_8601
      ]);
      return parsedDate.isValid() ? parsedDate.format("DD MMM YYYY HH:mm:ss") : 'Invalid Date';
    };
  
    const filteredData = selectedOrders.length > 0
      ? data.filter((order) => selectedOrders.includes(order._id))
      : data;
  
    const rows = filteredData.map((order) => {
      let totalQty = 0, approvedQty = 0, fulfilledQty = 0, grnQty = 0;
      let totalQtyUnits = 0, approvedQtyUnits = 0, fulfilledQtyUnits = 0, grnQtyUnits = 0;
      let skuOrdered = 0, skuApproved = 0, skuFulfilled = 0, skuGRN = 0;
      let approvedReasons = new Set();
      let fulfilledReasons = new Set();
      let grnReasons = new Set ();
      (order?.listOfProducts || []).forEach(product => {
        const caseSize = product?._id?.case_size || 1;
  
        // Basic counts
        skuOrdered++;
        if (product?.approvedQuantity) skuApproved++;
        if (product?.fulfilledQuantity) skuFulfilled++;
        if (product?.grnQuantity) skuGRN++;
  
        // Totals
        const qty = product?.quantity || 0;
        const approved = product?.approvedQuantity || 0;
        const fulfilled = product?.fulfilledQuantity || 0;
        const grn = product?.grnQuantity || 0;
  
        totalQty += qty;
        approvedQty += approved;
        fulfilledQty += fulfilled;
        grnQty += grn;
  
        totalQtyUnits += qty * caseSize;
        approvedQtyUnits += approved * caseSize;
        fulfilledQtyUnits += fulfilled * caseSize;

            // Collect unique reasons
            if (product?.approvedQuantityChangeReason) {
              approvedReasons.add(product.approvedQuantityChangeReason);
            }
            if (product?.fulfilledQuantityChangeReason) {
              fulfilledReasons.add(product.fulfilledQuantityChangeReason);
            }
            if (product?.grnQuantityChangeReason) {
              grnReasons.add(product.grnQuantityChangeReason);
            }

      });
  
      const percent = (num, denom) => denom > 0 ? ((num / denom) * 100).toFixed(2) + '%' : 'N/A';
  
      return [
        '', // WH
        escapeCSVValue(formatDateTime(order?.orderReceivedDate)),
        escapeCSVValue(formatDateTime(order?.appointmentDate)),
        escapeCSVValue(formatDateTime(order?.poExpiryDate)),
        escapeCSVValue(formatDateTime(order?.createdAt)),
        escapeCSVValue(formatDateTime(order?.invoiceDate)),
        escapeCSVValue(formatDateTime(order?.actualDispatchDate)),
        escapeCSVValue(formatDateTime(order?.deliveryDate)),
        escapeCSVValue(order?.documentType === 'delivery-note' ? 'Delivery Note' : 'Tax Invoice'),
        escapeCSVValue(order?.orderId),
        escapeCSVValue(order?.status),
        escapeCSVValue(order?.remarks),
        escapeCSVValue(order?.orderType),
        escapeCSVValue(order?.invoiceId),
        escapeCSVValue(order?.irnDetails?.irnRequestBody?.ValDtls?.TotInvVal),
        escapeCSVValue(order?.customerID?.name),
        escapeCSVValue(order?.customerID?.gstNumber),
        '',
        '',
        '',
        '',
        escapeCSVValue(skuOrdered),
        escapeCSVValue(totalQty),
        escapeCSVValue(totalQtyUnits),
        escapeCSVValue(skuApproved),
        escapeCSVValue(approvedQty),
        escapeCSVValue(approvedQtyUnits),
        escapeCSVValue(skuFulfilled),
        escapeCSVValue(fulfilledQty),
        escapeCSVValue(fulfilledQtyUnits),
        escapeCSVValue(skuGRN),
        escapeCSVValue(grnQty),
  
      escapeCSVValue(skuApproved - skuFulfilled), escapeCSVValue(approvedQtyUnits - fulfilledQtyUnits),
      escapeCSVValue(skuFulfilled - skuGRN), escapeCSVValue(fulfilledQtyUnits - grnQty),
      
      percent(skuApproved, skuOrdered), percent(approvedQtyUnits, totalQtyUnits),
      percent(skuFulfilled, skuApproved), percent(fulfilledQtyUnits, approvedQtyUnits),
      percent(skuFulfilled, skuOrdered), percent(fulfilledQtyUnits, totalQtyUnits),
      percent(skuGRN, skuFulfilled), percent(grnQty, fulfilledQtyUnits),
      percent(skuGRN, skuOrdered), percent(grnQty, totalQtyUnits),

  
      escapeCSVValue(Array.from(approvedReasons).join(', ')), 
      escapeCSVValue(Array.from(fulfilledReasons).join(', ')),
      escapeCSVValue(Array.from(grnReasons).join(', ')), // WH / GRN Remarks
      
        escapeCSVValue(formatDateTime(order?.deliveryDate)),
        escapeCSVValue(order?.modeOfTransport),
        escapeCSVValue(order?.shippingPartner),
        escapeCSVValue(order?.awbNumber),
        '', '', 
      ].join(',');
    });
  
    const csvString = [headers.join(','), ...rows].join('\n');
  
    // ✅ Blob method for proper encoding & large data support
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'Order-wise.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };
  
  const convertToCSVSkuWise = (data, selectedOrders) => {
    const headers = [
      'WH', 'PO Date', 'PO Expiry Date', 'Punch Date', 'Invoice date', 'Dispatch Date', 'Delivery Date',
      'Voucher Type', 'PO Number', 'Invoice Number', 'Taxable Invoice Value', 'Total Invoice Amount With Tax',
      'Customer', 'Customer GST', 'Shipping Address', 'Mode of Transport', 'AWB Number', 'Order ID', 
      'Order Type', 'Order Status', 'SKU Code', 'SKU Description', 'Order Qty (Case Units)', 
      'Approved Qty (Case Units)', 'Fulfilled/Dispatched Qty (Case Units)', 'Order Qty (in Units)', 
      'Approved Qty (in Units)', 'Fulfilled/Dispatched Qty (in Units)', 'GRN Qty (in Units)', 
      'Approval Remarks', 'WH/Fulfillment Remarks', 'GRN Remarks'
    ];

    const escapeCSVValue = (value) => {
      if (value === undefined || value === null) return '';
      const stringValue = String(value);
      return `"${stringValue.replace(/"/g, '""')}"`;
    };

  
    const formatDateTime = (dateString) => {
      if (!dateString) return '';

        // If it's an Excel serial date (numeric string or number)
        const excelSerial = parseFloat(dateString);
        if (!isNaN(excelSerial) && excelSerial > 25569) {
          const utcDays = Math.floor(excelSerial - 25569);
          const utcValue = utcDays * 86400; // seconds since Unix epoch
          const dateInfo = new Date(utcValue * 1000);

          const fractionalDay = excelSerial % 1;
          const totalSeconds = Math.round(fractionalDay * 86400);
          dateInfo.setSeconds(dateInfo.getSeconds() + totalSeconds);

          return moment(dateInfo).format("DD MMM YYYY HH:mm:ss");
        }

      const parsedDate = moment(dateString, [
        "M/D/YY H:mm",
        "DD/MM/YY",
        "DD/MM/YYYY",
        "DD/MM/YYYY HH:mm:ss", 
        "DD-MM-YYYY",          
        "D-M-YYYY",
        "YYYY-MM-DD", 
        "YYYY/MM/DD", 
        "MM/DD/YYYY", 
        "M/D/YYYY H:mm", 
        "M/D/YYYY h:mm A", "x", "X", moment.ISO_8601
      ]);
      return parsedDate.isValid() ? parsedDate.format("DD MMM YYYY HH:mm:ss") : 'Invalid Date';
    };

    const rows = [];
    const filteredData = selectedOrders.length > 0
      ? data.filter((order) => selectedOrders.includes(order._id))
      : data;

    filteredData.forEach(order => {
      (order?.listOfProducts || []).forEach(product => {
        const caseSize = product?._id?.case_size || 1;
        const row = [
          '', // WH
          formatDateTime(order?.orderReceivedDate),
          formatDateTime(order?.poExpiryDate),
          formatDateTime(order?.createdAt),
          formatDateTime(order?.invoiceDate),
          formatDateTime(order?.actualDispatchDate),
          formatDateTime(order?.deliveryDate),
          escapeCSVValue(order?.documentType === 'delivery-note' ? 'Delivery Note' : 'Tax Invoice'),
          escapeCSVValue(order?.orderId),
          escapeCSVValue(order?.invoiceId),
          escapeCSVValue(order?.irnDetails?.irnRequestBody?.ValDtls?.AssVal),
          escapeCSVValue(order?.irnDetails?.irnRequestBody?.ValDtls?.TotInvVal),
          escapeCSVValue(order?.customerID?.name),
          escapeCSVValue(order?.customerID?.gstNumber),
          escapeCSVValue(order?.shippingAddress),
          escapeCSVValue(order?.modeOfTransport),
          escapeCSVValue(order?.awbNumber),
          escapeCSVValue(order?.orderId),
          escapeCSVValue(order?.orderType),
          escapeCSVValue(order?.status),
          escapeCSVValue(product?.skuCode),
          escapeCSVValue(product?._id?.product_name),
          escapeCSVValue(product?.quantity),
          escapeCSVValue(product?.approvedQuantity),
          escapeCSVValue(product?.fulfilledQuantity),
          escapeCSVValue((product?.quantity || 0) * caseSize),
          escapeCSVValue((product?.approvedQuantity || 0) * caseSize),
          escapeCSVValue((product?.fulfilledQuantity || 0) * caseSize),
          escapeCSVValue(product?.grnQuantity),
          escapeCSVValue(product?.approvedQuantityChangeReason),
          escapeCSVValue(product?.fulfilledQuantityChangeReason),
          escapeCSVValue(product?.grnQuantityChangeReason)
        ];
        rows.push(row.join(','));
      });
    });

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `SKU-Wise.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };
  

  const headings = {
    checkbox: {
      label: "Select",
      isCheckbox: true,
      onChange: (row) => handleCheckboxChange(row._id),
      isSticky: false,
    },
    orderId: {
      label: "Order ID",
      renderCell: (row) => row?.orderId || "N/A",
      isSticky: false,
    },
    customerName: {
      label: "Customer Name",
      renderCell: (row) => row?.customerID?.name || "N/A",
      isSticky: false,
    },
    status: {
      label: "Status",
      renderCell: (row) => <StatusComponent status={row?.status} /> || "N/A",
      isSticky: false,
    },
    orderType: {
      label: "Order Type",
      renderCell: (row) => row?.orderType || "N/A",
      isSticky: false,
    },
    shippingAddress: {
      label: "Shipping Address",
      renderCell: (row) =>
        (row?.shippingAddress || row?.customerID?.shipping_address)?.slice(0, 25) + "..." || "N/A",
      isSticky: false,
    },
    distinctProducts: {
      label: "Distinct Products",
      renderCell: (row) => row?.listOfProducts?.length || "N/A",
      isSticky: false,
    },
    fulfilledProducts : {
      label: "Fulfilled Products",
      renderCell: (row) =>
        row?.listOfProducts?.reduce(
          (acc, product) => 
            (product.fulfilledQuantity !== undefined && product.fulfilledQuantity >= 1) ? acc + 1 : acc,
          0
        ) || "N/A",
      isSticky: false,
    },
    remarks: {
      label: "Remarks",
      renderCell: (row) => row?.remarks || "N/A",
      isSticky: false,
    },
    action: {
      label: "Action",
      renderCell: (row) => (
        <ActionDropdown order={row} actions={generateOrderActions(row)} />
      ),
      isSticky: true,
      stickyClassHeader: stickyActionColumnClassname,
      stickyClassRow: stickyActionRowClassname,
    },
  };


  const generateOrderActions = (order) => {
    return [
      {
        label: "View Order Particulars",
        condition: () => true,
        action: () => openSidebar("viewOrderParticular", order),
      },
      {
        label: "Edit Order",
        condition: () => order.status === "open" || order.status === "approved" ,
        action: () => openSidebar ("editOrder", order),
      },
      // {
      //   label: "Edit Approved Order",
      //   condition: () => order.status === "approved" ,
      //   action: () => openSidebar ("editApprovedOrder", order),
      // },
      {
        label: "Approve Order",
        condition: () => order.status === "open",
        action: () => openSidebar ("approveOrder", order),
      },
      // {
      //   label: "Enter Shipping Details",
      //   condition: () => order.status === "picked",
      //   action: () => openSidebar ("enterShippingDetails", order),
      // },
      {
        label: "Enter Invoice Info",
        condition: () => order.status === "picked",
        action: () => openSidebar ("enterInvoiceInfo", order),
      },
      {
        label: "Enter Dispatch Info",
        condition: () => order.status === "invoiced",
        action: () => openSidebar ("enterDispatchInfo", order),
      },
      {
        label: "Enter Delivery Info",
        condition: () => order.status === "in_transit",
        action: () => openSidebar ("enterDeliveryInfo", order),
      },
      {
        label: "Enter GRN Info",
        condition: () => order.status === "delivered",
        action: () => openSidebar ("enterGRNInfo", order),
      },

      {
        label: "Cancel Invoice",
        condition: () => {
          if (!order.invoiceDate) return false;
          // Parse the invoice date as IST (India Standard Time)
          const invoiceDate = moment.tz(order.invoiceDate, "DD/MM/YYYY HH:mm:ss", "Asia/Kolkata");
          if (!invoiceDate.isValid()) return false;
          // Get current time in IST
          const now = moment.tz("Asia/Kolkata");
          const duration = moment.duration(now.diff(invoiceDate));
          const hoursSinceInvoicing = duration.asHours();
          return hoursSinceInvoicing <= 24;
        },
        action: () => openSidebar("cancelInvoice", order),
      }
      

    ];
  };

  const openSidebar = (type, order) => {
    setSidebarType(type);
    setSelectedOrder(order);
    setIsSidebarOpen(true);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
    setSidebarType(null);
    setSelectedOrder(null);
  };
  

  const filterOptions = [
    { value: "allOrders", label: "All Orders" },
    { value: "open", label: "Pending Orders" },
    { value: "approved", label: "Approved Orders" },
    { value: "picked", label: "Picked Orders" },
    { value: "in_transit", label: "Dispatched Orders" },
    { value: "delivered", label: "Delivered Orders" },
    { value: "rto", label: "RTO Orders" },
    { value: "delivery-note", label: "Delivery-Notes" },
    { value: "Blinkit", label: "Blinkit Orders" },
    { value: "Zepto", label: "Zepto Orders" },
    { value: "Swiggy", label: "Swiggy Orders" },
    { value: "aboutToExpire", label: "About to Expire Orders" }
  ];

  const handleCheckboxChange = (orderInternalId) => {
    // Toggle the orderID in the selected Orders list
    setSelectedOrders((prevSelectedOrders) =>
      prevSelectedOrders.includes(orderInternalId)
        ? prevSelectedOrders.filter((id) => id !== orderInternalId)
        : [...prevSelectedOrders, orderInternalId]
    );
    console.log ("Checking ", selectedOrders);
  };

  const handleDownload = async () => {
    try {
      setLoading(true);
      console.log('Starting download with params:', { searchText, filter, dayFilter, startDate, endDate });
      
      const response = await b2bOrderService.getAllB2BOrdersForDownload({
        searchText,
        filter,
        dayFilter,
        startDate,
        endDate
      });

      console.log('Download response:', response);

      if (response.success) {
        const dataToDownload = selectedOrders.length > 0
          ? response.data.filter(order => selectedOrders.includes(order._id))
          : response.data;
        
        console.log('Processing download for', dataToDownload.length, 'orders');
        convertToCSV(dataToDownload, selectedOrders);
      } else {
        console.error('Download failed:', response);
        alert('Failed to download orders. Please try again.');
      }
    } catch (error) {
      console.error('Error downloading orders:', error);
      alert('An error occurred while downloading orders. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadSkuWise = async () => {
    try {
      setLoading(true);
      console.log('Starting SKU-wise download with params:', { searchText, filter, dayFilter, startDate, endDate });
      
      const response = await b2bOrderService.getAllB2BOrdersForDownload({
        searchText,
        filter,
        dayFilter,
        startDate,
        endDate
      });

      console.log('SKU-wise download response:', response);

      if (response.success) {
        const dataToDownload = selectedOrders.length > 0
          ? response.data.filter(order => selectedOrders.includes(order._id))
          : response.data;
        
        console.log('Processing SKU-wise download for', dataToDownload.length, 'orders');
        convertToCSVSkuWise(dataToDownload, selectedOrders);
      } else {
        console.error('SKU-wise download failed:', response);
        alert('Failed to download SKU-wise data. Please try again.');
      }
    } catch (error) {
      console.error('Error downloading SKU-wise orders:', error);
      alert('An error occurred while downloading SKU-wise orders. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <TableFilterBarWithDatePicker
        filter={filter}
        setFilter={handleFilterChange}
        searchText={searchText}
        setSearchText={handleSearchChange}
        convertToCSV={handleDownload}
        convertToCSVSkuWise={handleDownloadSkuWise}
        allPO={orders}
        selectedRows={selectedOrders}
        filterOptions={filterOptions}
        dayFilter={dayFilter}
        handleDayFilterChange={handleDayFilterChange}
        startDate={startDate}
        setStartDate={(date) => {
          setStartDate(date);
          setPagination(prev => ({ ...prev, page: 1 }));
        }}
        endDate={endDate}
        setEndDate={(date) => {
          setEndDate(date);
          setPagination(prev => ({ ...prev, page: 1 }));
        }}
        isLoading={loading}
      />

      {loading ? (
        <div className="flex justify-center items-center p-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
        </div>
      ) : (
        <DynamicTableWithoutAction 
          headings={headings} 
          rows={orders}
          pagination={{
            ...pagination,
            onPageChange: (newPage) => setPagination(prev => ({ ...prev, page: newPage })),
            onLimitChange: (newLimit) => setPagination(prev => ({ ...prev, limit: newLimit, page: 1 }))
          }}
        />
      )}

      {sidebarType === "viewOrderParticular" ? (
        <BigRightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
          <ViewOrderParticular
            selectedOrder={selectedOrder}
            handleCancel={closeSidebar}
          />
        </BigRightSidebar>
      ) : (
        <RightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
          {sidebarType === "editOrder" && (
            <EditOrder selectedOrder={selectedOrder} handleCancel={closeSidebar} />
          )}
           {sidebarType === "editApprovedOrder" && (
            <EditApprovedOrder selectedOrder={selectedOrder} handleCancel={closeSidebar} />
          )}
          {sidebarType === "approveOrder" && (
            <ApproveOrderComponent
              selectedOrderOriginal={selectedOrder}
              handleCancel={closeSidebar}
            />
          )}
          {/* {sidebarType === "enterShippingDetails" && (
            <ReadyToShipOrderComponent
              selectedOrder={selectedOrder}
              handleCancel={closeSidebar}
            />
          )} */}
          {sidebarType === "enterInvoiceInfo" && (
            <InvoiceInfoOrderComponent
              selectedOrder={selectedOrder}
              handleCancel={closeSidebar}
            />
          )}
          {sidebarType === "enterDispatchInfo" && (
            <DispatchInfoOrderComponent
              selectedOrder={selectedOrder}
              handleCancel={closeSidebar}
            />
          )}
          {sidebarType === "enterDeliveryInfo" && (
            <DeliveryInfoOrderComponent
              selectedOrder={selectedOrder}
              handleCancel={closeSidebar}
            />
          )}
          {sidebarType === "enterGRNInfo" && (
            <GRNInfoOrderComponent
              selectedOrderOriginal={selectedOrder}
              handleCancel={closeSidebar}
            />
          )}
          {sidebarType === "cancelInvoice" && (
            <CancelInvoiceComponent
              selectedOrder={selectedOrder}
              handleCancel={closeSidebar}
            />
          )}
        </RightSidebar>
      )}
    </>
  );
};

export default B2BOrdersTables;

