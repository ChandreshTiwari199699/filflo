"use client";
import React, { useState, useEffect } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { b2bInventoryPOService } from "@/app/services/b2bInventoryPOService";
import DynamicTableWithCheckbox from "../DynamicTableWithCheckbox/DynamicTableWithCheckbox";
import TableFilterBar from "../TableFilterBar/TableFilterBar";
import { PrimaryButton } from "../ButtonComponent/ButtonComponent";
import searchNested from "@/app/utils/searchUtils";
import moment from "moment";
import { jsPDF } from "jspdf";

const CreatePickListOrderWise = () => {
  const [pendingB2BPOs, setPendingB2BPOs] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [selectedOrders, setSelectedOrders] = useState([]);
  const [searchText, setSearchText] = useState("");

  useEffect(() => {
    getPendingB2BPOs();
  }, []);

  const getPendingB2BPOs = async () => {
    try {
      const response = await b2bInventoryPOService.getPendingB2BInventoryPO();
      if (response.success) {
        setPendingB2BPOs(response.data);
        setFilteredData(response.data);
      } else {
        toast.error("No pending B2B Inventory POs found", { autoClose: 2000 });
      }
    } catch (error) {
      console.error("Error fetching pending POs:", error);
      toast.error("Error fetching data", { autoClose: 2000 });
    }
  };

  const applyFilters = () => {
    let data = pendingB2BPOs;
    data = data.filter((item) =>
      searchKeys.some((key) => searchNested(item[key], searchText.toLowerCase(), key))
    );
    setFilteredData(data);
  };

  const searchKeys = ["orderId", "products"];

  useEffect(() => {
    applyFilters();
  }, [searchText, pendingB2BPOs]);

  const handleCheckboxChange = (orderId) => {
    setSelectedOrders((prev) =>
      prev.includes(orderId) ? prev.filter((id) => id !== orderId) : [...prev, orderId]
    );
  };
  

  const handleSelectAllPending = () => {
    const allPendingOrderIds = filteredData.map((po) => po.orderId);
  
    setSelectedOrders((prev) => {
      const allSelected = allPendingOrderIds.every((id) => prev.includes(id));
      return allSelected
        ? prev.filter((id) => !allPendingOrderIds.includes(id)) // Unselect only visible ones
        : [...new Set([...prev, ...allPendingOrderIds])]; // Add new ones without duplication
    });
  };
  

  const generateSummaryAndDownload = () => {
    if (selectedOrders.length === 0) {
      toast.error("Please select at least one order", { autoClose: 2000 });
      return;
    }
  
    const selectedData = pendingB2BPOs.filter((po) => selectedOrders.includes(po.orderId));
    const doc = new jsPDF();
    doc.setFont("helvetica");
    
    // Define table columns and their widths
    const columns = [
      { header: 'SKU Code', width: 45, align: 'left' },
      { header: 'Product Name', width: 95, align: 'left' },
      { header: 'Quantity', width: 30, align: 'center' }
    ];
    
    const startX = 20;
    const cellPadding = 3;
    const lineHeight = 7;
    const maxLineWidth = columns.reduce((sum, col) => sum + col.width, 0);

    // Function to safely truncate and wrap text
    const wrapText = (text, maxWidth, fontSize) => {
      doc.setFontSize(fontSize);
      const words = text.toString().split(/(?<=[-\s])/); // Split on spaces and after hyphens
      const lines = [];
      let currentLine = words[0];

      for(let i = 1; i < words.length; i++) {
        const word = words[i];
        const width = doc.getStringUnitWidth(currentLine + word) * fontSize / doc.internal.scaleFactor;
        
        if(width < maxWidth) {
          currentLine += word;
        } else {
          lines.push(currentLine.trim());
          currentLine = word;
        }
      }
      lines.push(currentLine.trim());
      return lines;
    };
    
    selectedData.forEach((order, index) => {
      let yPos = 20;
      
      if (index > 0) {
        doc.addPage();
      }
      
      // Add order header with background
      doc.setFillColor(240, 240, 240);
      doc.rect(startX, yPos - 5, maxLineWidth, 10, 'F');
      doc.setFont("helvetica", 'bold');
      doc.setFontSize(12);
      doc.text(`Order ID/PO Number: ${order.orderId}`, startX + 2, yPos);
      yPos += 15;
      
      // Draw table header with background
      doc.setFillColor(230, 230, 230);
      doc.rect(startX, yPos - 5, maxLineWidth, 10, 'F');
      
      // Add table headers
      let xPos = startX;
      doc.setFont("helvetica", 'bold');
      columns.forEach(col => {
        const textWidth = doc.getStringUnitWidth(col.header) * 12 / doc.internal.scaleFactor;
        const xOffset = col.align === 'center' ? (col.width - textWidth) / 2 : cellPadding;
        doc.text(col.header, xPos + xOffset, yPos);
        xPos += col.width;
      });
      yPos += 10;
      
      // Draw header borders
      xPos = startX;
      doc.line(xPos, yPos - 15, xPos, yPos);
      columns.forEach(col => {
        xPos += col.width;
        doc.line(xPos, yPos - 15, xPos, yPos);
      });
      doc.line(startX, yPos - 15, startX + maxLineWidth, yPos - 15);
      doc.line(startX, yPos, startX + maxLineWidth, yPos);
      
      // Add products
      doc.setFont("helvetica", 'normal');
      doc.setFontSize(10);
      
      order.products.forEach((product, productIndex) => {
        // Calculate row height based on wrapped text for both SKU and product name
        const skuLines = wrapText(product.sku_code, columns[0].width - (2 * cellPadding), 10);
        const productNameLines = wrapText(product.product_name, columns[1].width - (2 * cellPadding), 10);
        const rowHeight = Math.max(
          skuLines.length * lineHeight,
          productNameLines.length * lineHeight,
          lineHeight
        );
        
        // Check if we need a new page
        if (yPos + rowHeight > 280) {
          doc.addPage();
          yPos = 20;
          
          // Repeat the header on new page
          doc.setFillColor(240, 240, 240);
          doc.rect(startX, yPos - 5, maxLineWidth, 10, 'F');
          doc.setFont("helvetica", 'bold');
          doc.setFontSize(12);
          doc.text(`Order ID/PO Number: ${order.orderId} (continued)`, startX + 2, yPos);
          yPos += 15;
          
          // Repeat table headers
          doc.setFillColor(230, 230, 230);
          doc.rect(startX, yPos - 5, maxLineWidth, 10, 'F');
          
          xPos = startX;
          columns.forEach(col => {
            const textWidth = doc.getStringUnitWidth(col.header) * 12 / doc.internal.scaleFactor;
            const xOffset = col.align === 'center' ? (col.width - textWidth) / 2 : cellPadding;
            doc.text(col.header, xPos + xOffset, yPos);
            xPos += col.width;
          });
          yPos += 10;
          
          // Draw header borders
          xPos = startX;
          doc.line(xPos, yPos - 15, xPos, yPos);
          columns.forEach(col => {
            xPos += col.width;
            doc.line(xPos, yPos - 15, xPos, yPos);
          });
          doc.line(startX, yPos - 15, startX + maxLineWidth, yPos - 15);
          doc.line(startX, yPos, startX + maxLineWidth, yPos);
          
          doc.setFont("helvetica", 'normal');
          doc.setFontSize(10);
        }
        
        // Draw alternating row backgrounds
        if (productIndex % 2 === 0) {
          doc.setFillColor(250, 250, 250);
          doc.rect(startX, yPos, maxLineWidth, rowHeight, 'F');
        }
        
        // Draw cell contents
        xPos = startX;
        let currentY = yPos + lineHeight - 1;
        
        // SKU Code (left aligned with wrapping)
        let skuY = currentY;
        skuLines.forEach(line => {
          doc.text(line, xPos + cellPadding, skuY);
          skuY += lineHeight;
        });
        
        // Product Name (left aligned with wrapping)
        xPos += columns[0].width;
        let productY = currentY;
        productNameLines.forEach(line => {
          doc.text(line, xPos + cellPadding, productY);
          productY += lineHeight;
        });
        
        // Quantity (center aligned)
        xPos += columns[1].width;
        const quantityWidth = doc.getStringUnitWidth(product.quantity.toString()) * 10 / doc.internal.scaleFactor;
        const quantityX = xPos + (columns[2].width - quantityWidth) / 2;
        doc.text(product.quantity.toString(), quantityX, yPos + lineHeight - 1);
        
        // Draw cell borders
        xPos = startX;
        doc.line(xPos, yPos, xPos, yPos + rowHeight);
        columns.forEach(col => {
          xPos += col.width;
          doc.line(xPos, yPos, xPos, yPos + rowHeight);
        });
        doc.line(startX, yPos, startX + maxLineWidth, yPos);
        doc.line(startX, yPos + rowHeight, startX + maxLineWidth, yPos + rowHeight);
        
        yPos += rowHeight;
      });
    });
    
    // Generate filename and save
    const orderIds = selectedData.map(order => order.orderId).join(", ");
    const safeOrderIds = orderIds.replace(/[^a-zA-Z0-9, ]/g, "");
    const fileName = `Picklist for Order IDs - ${safeOrderIds} - ${moment().format("DD-MMM-YYYY")}.pdf`;
    
    doc.save(fileName);
  };
  
  const headings = {
    checkbox: {
      label: "Select",
      isCheckbox: true,
      onChange: (row) => handleCheckboxChange(row.orderId),
      isChecked: (row) => selectedOrders.includes(row.orderId),
      isSticky: false,
    },
    orderID: {
      label: "Order ID",
      renderCell: (row) => row.orderId || "N/A",
      isSticky: false,
    },
    products: {
      label: "Products",
      renderCell: (row) => (
        <ul>
          {row.products.map((product, index) => (
            <li key={index}>
              {product.product_name} (SKU: {product.sku_code}) - Qty: {product.quantity}
            </li>
          ))}
        </ul>
      ),
      isSticky: false,
    },
  };


  const convertToCSV = (orders) => {
    if (!orders || orders.length === 0) {
      return "";
    }
  
    const headers = ["Order ID", "SKU Code", "Product Name", "Quantity"];
    const rows = [];
  
    orders.forEach((order) => {
      order.products.forEach((product) => {
        const row = [
          `"${order.orderId}"`,
          `"${product.sku_code}"`,
          `"${product.product_name.replace(/"/g, '""')}"`,
          `"${product.quantity}"`
        ];
        rows.push(row.join(","));
      });
    });
  
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    const fileName = `Pending_B2B_Orders_${moment().format("DD-MMM-YYYY")}.csv`;
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <>
      <div className="flex gap-x-2">
        <ToastContainer />
        <div className="flex-1">
          <TableFilterBar
            searchText={searchText}
            setSearchText={setSearchText}
            convertToCSV={convertToCSV}
            allPO={filteredData}
          />
        </div>
        <PrimaryButton title="Create Picklist" onClick={generateSummaryAndDownload} size="medium" />
      </div>

      {/* Select All Pending Orders Checkbox */}
      <div className="flex items-center gap-x-4 bg-white p-3 rounded-lg shadow-sm border mb-3">
        <input
          type="checkbox"
          id="selectAllPending"
          checked={selectedOrders.length === filteredData.length && filteredData.length > 0}
          onChange={handleSelectAllPending}
          className="w-5 h-5 accent-blue-500 cursor-pointer"
        />
        <label htmlFor="selectAllPending" className="text-base font-medium text-gray-700 cursor-pointer">
          Select All Pending Orders
        </label>
      </div>

      <DynamicTableWithCheckbox headings={headings} rows={filteredData} />
    </>
  );
};

export default CreatePickListOrderWise;
