import React from 'react';

const DynamicTableWithoutAction = ({ 
  headings, 
  rows,
  pagination
}) => {
  const { 
    total, 
    page, 
    limit, 
    totalPages,
    onPageChange, 
    onLimitChange 
  } = pagination || {};

  return (
    <div>
      <div className="relative overflow-x-auto rounded-2xl border-[1.2px] border-stroke scrollbar-none">
        <table className="w-full text-sm text-dark table-auto">
          <thead className="text-sm text-dark-4 bg-gray-2 border-b border-gray-200">
            <tr>
              {/* Checkbox header */}
              {headings.checkbox ? (
                <th scope="col" className="pl-4 py-2">
                  <div className="flex items-center">
                    {headings.checkbox.label ? (
                      <span className="text-sm font-medium">
                        {headings.checkbox.label}
                      </span>
                    ) : (
                      <input
                        type="checkbox"
                        className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded"
                      />
                    )}
                  </div>
                </th>
              ) : (
                <th scope="col" className="pl-4 py-2"></th>
              )}

              {/* Dynamic headers */}
              {Object.keys(headings).map((key, index) => {
                if (key === "checkbox") return null;
                return (
                  <th
                    key={index}
                    className={`px-4 py-2 min-w-40 max-w-80 text-left capitalize font-medium ${
                      key === 'status' ? '' : ''
                    } ${
                      headings[key].isSticky
                        ? `${headings[key].stickyClassHeader}`
                        : "py-2"
                    }`}
                  >
                    {headings[key].label || key}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody className="bg-white relative">
            {rows.length > 0 ? (
              rows.map((row, rowIndex) => (
                <tr key={rowIndex} className="bg-white border-b-[0.5px]">
                  {/* Checkbox column */}
                  <td scope="col" className="px-4">
                    {headings.checkbox?.isCheckbox ? (
                      <input
                        type="checkbox"
                        onChange={() =>
                          headings.checkbox.onChange
                            ? headings.checkbox.onChange(row)
                            : null
                        }
                        className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded"
                      />
                    ) : (
                      <input
                        type="checkbox"
                        className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded"
                      />
                    )}
                  </td>

                  {/* Dynamic columns */}
                  {Object.keys(headings).map(
                    (key, colIndex) =>
                      key !== "checkbox" && (
                        <td
                          key={colIndex}
                          className={`px-4 py-2 min-w-40 max-w-80 font-medium ${
                            key === "Status" ? "text-center" : "text-left"
                          } text-dark ${
                            headings[key].isSticky
                              ? `${headings[key].stickyClassRow} `
                              : ""
                          }`}
                        >
                          <div className="min-w-40 max-w-80">
                            {headings[key].renderCell
                              ? headings[key].renderCell(row, rowIndex)
                              : row[key] || "N/A"}
                          </div>
                        </td>
                      )
                  )}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={Object.keys(headings).length + 1} className="px-6 py-8 text-center">
                  <div className="flex flex-col items-center justify-center text-gray-500">
                    <svg 
                      className="w-12 h-12 mb-4 text-gray-400" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth={2} 
                        d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M12 20a8 8 0 100-16 8 8 0 000 16z" 
                      />
                    </svg>
                    <p className="text-lg font-semibold">No Data Found</p>
                    <p className="text-sm text-gray-400">No data match your current filters or are available.</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {pagination && rows.length > 0 && (
        <div className="flex items-center justify-between p-4 bg-white mt-4">
          <div className="flex items-center space-x-2">
            <select
              value={limit}
              onChange={(e) => onLimitChange(Number(e.target.value))}
              className="px-3 py-2 border rounded-md text-sm border-stroke text-dark-4"
            >
              <option value={10}>10 per page</option>
              <option value={25}>25 per page</option>
              <option value={50}>50 per page</option>
              <option value={100}>100 per page</option>
            </select>
            <span className="text-sm text-dark-4">
              Showing {((page - 1) * limit) + 1} to {Math.min(page * limit, total)} of {total} entries
            </span>
          </div>
          
          <div className="min-w-36 text-sm border border-stroke rounded-2xl flex justify-center items-center">
            <div className="flex justify-center items-center min-h-8 min-w-36 rounded-l-2xl text-dark-4 bg-gray-2 border-stroke border-r-2">
              <div>
                <span className="text-dark font-bold mr-2">{page}</span>
                <span>of {totalPages}</span>
              </div>
            </div>
            <div className="flex">
              <button
                onClick={() => onPageChange(page - 1)}
                disabled={page === 1}
                className="flex items-center px-4 py-2 text-dark-4 disabled:opacity-50"
              >
                Previous
              </button>
              <button
                onClick={() => onPageChange(page + 1)}
                disabled={page >= totalPages}
                className="flex items-center px-4 py-2 text-dark-4 disabled:opacity-50"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DynamicTableWithoutAction;