'use client'
import React, { useEffect, useState } from "react";
import Input from "../Input/Input";
import Button from "../Button/Button";
import { productServices } from "@/app/services/productService";
import {
    getAllProductByCatIdRequest,
    getAllProductByCatIdSuccess,
    getAllProductByCatIdFailure,
} from "../../Actions/productActions";

import {
    getAllCategorySuccess,
    getAllCategoryRequest,
    getAllCategoryFailure,
} from "../../Actions/categoryActions";

import CategoryDropdown from "../CategoryDropdown/CategoryDropdown";
import ProductDropdown from "../ProductDropdown/ProductDropdown";
import { useDispatch, useSelector } from "react-redux";
import { categoryServices } from "@/app/services/categoryService";
import { b2bCustomerService } from "@/app/services/b2bCustomerService";
import { sfgCategories } from "@/app/constants/categoryConstants";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; 

const CreateB2BCustomerForm = () => {
    const { allCategories, selectedCatId } = useSelector(
        (state) => state.category
    );

    const { allProductsByCatId } = useSelector((state) => state.product);
    const { dropDownProductValue, dropdownProductName } = useSelector(
        (state) => state.dropdown
    );

    const [formDisabled, setFormDisabled] = useState(false);
    
    const [formData, setFormData] = useState({
        customerName: "",
        customerPhoneNumber: "",
        customerBillingAddress: "",
        customerShippingAddress: "",
        customerGSTNumber: "",
        listOfProducts: [],
    });
    const [productPrice, setProductPrice] = useState(null);
    const [errors, setErrors] = useState({});
    const dispatch = useDispatch();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevFormData) => ({
            ...prevFormData,
            [name]: value,
        }));
    };

    const handleRemoveProductsFromList = (index) => {
        setFormData((prevFormData) => ({
            ...prevFormData,
            listOfProducts: prevFormData.listOfProducts.filter((_, i) => i !== index),
        }));
    };

    const handleAddProduct = () => {
        if (dropDownProductValue && productPrice) {
            const newProduct = {
                skuCode: dropDownProductValue,
                price: productPrice,
                productName: dropdownProductName,
            };
            setFormData((prevFormData) => ({
                ...prevFormData,
                listOfProducts: [...prevFormData.listOfProducts, newProduct],
            }));
            setProductPrice("");
        } else {
            setErrors((prevErrors) => ({
                ...prevErrors,
                listOfProducts: "Please select a product and enter price per unit.",
            }));
        }
    };

    const getAllCategories = async () => {
        try {
            dispatch(getAllCategoryRequest());

            const response = await categoryServices.getAllCategories();
            const fgCategories = response.data.filter(
                (category) => !sfgCategories.includes(category.category_name)
            );

            if (response.success === true) {
                dispatch(getAllCategorySuccess(fgCategories));
            }
        } catch (err) {
            console.log(err);
            dispatch(getAllCategoryFailure());
        }
    };

    const getProductByCatId = async () => {
        try {
            dispatch(getAllProductByCatIdRequest());
            const response = await productServices.getAllProductsByCatId(
                selectedCatId
            );
            if (response.success === true) {
                dispatch(getAllProductByCatIdSuccess(response.data));
            }
        } catch (err) {
            console.log(err);
            dispatch(getAllProductByCatIdFailure());
        }
    };

    useEffect(() => {
        getProductByCatId();
    }, [selectedCatId]);

    useEffect(() => {
        getAllCategories();
    }, []);

    const validateForm = () => {
        const newErrors = {};
        if (!formData.customerName) newErrors.customerName = "Customer name is required.";
        if (!formData.customerPhoneNumber) newErrors.customerPhoneNumber = "Customer phone number is required.";
        if (!formData.customerBillingAddress) newErrors.customerBillingAddress = "Customer Billing Address is required.";
        if (!formData.customerShippingAddress) newErrors.customerShippingAddress = "Customer Shipping Address is required.";
        if (!formData.customerGSTNumber) newErrors.customerGSTNumber = "Customer GST number is required.";
        if (formData.listOfProducts.length === 0)
            newErrors.listOfProducts = "At least one product must be added.";

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const onFormSubmit = async () => {
        console.log("Form submitted"); // Check if this logs
        if (!validateForm()) return;
        try {


            console.log(formData);
            const response = await b2bCustomerService.createB2BCustomer(formData);
            console.log(response);
            if (response && response.success) {
                toast.success('B2B Customer Created Successfully', {
                    autoClose: 1500,
                    onClose: () => window.location.reload(),
                });
                setFormDisabled(true);
            } else {
                toast.error('Failed to create customer: ' + (response?.message || 'Unknown error'), {
                    autoClose: 5000,
                    onClose: () => window.location.reload(),
                });
                setFormDisabled(true);
            }
        } catch (err) {
            toast.error('Failed to create customer: ' + err, { autoClose: 3000 }
            );
            window.location.reload();
        }
    };
    

    return (
        <div className="h-[78vh] min-h-[78vh] max-h-[78vh] overflow-y-scroll">
            <div className="flex flex-col mt-3">
                <ToastContainer />
            </div>

            <h2 className="text-base font-semibold text-[#111928] mb-1">
          Create B2B Customer
        </h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
        Create a new B2B customer
        </p>
    
            <div className="flex flex-col mb-3">
                <label  className="block text-[#111928] text-sm font-medium mb-1">Customer Name <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
                <Input
                    bgColor="bg-[#F8F6F2]"
                    radius="rounded-lg"
                    height="h-[3.5vw] min-h-[3.5vh]"
                    padding="p-[1vw]"
                    type="text"
                    color="text-[#838481]"
                    textSize="text-[1vw]"
                    fontWeight="font-medium"
                    name="customerName"
                    value={formData.customerName}
                    onChange={handleChange}
                />
                {errors.customerName && (
                    <p className="text-red-500 text-xs">{errors.customerName}</p>
                )}
            </div>
    
            <div className="flex flex-col mb-3">
                <label  className="block text-[#111928] text-sm font-medium mb-1">Customer Phone Number <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
                <Input
                    bgColor="bg-[#F8F6F2]"
                    radius="rounded-lg"
                    height="h-[3.5vw] min-h-[3.5vh]"
                    padding="p-[1vw]"
                    type="text"
                    color="text-[#838481]"
                    textSize="text-[1vw]"
                    fontWeight="font-medium"
                    name="customerPhoneNumber"
                    value={formData.customerPhoneNumber}
                    onChange={handleChange}
                />
                {errors.customerPhoneNumber && (
                    <p className="text-red-500 text-xs">{errors.customerPhoneNumber}</p>
                )}
            </div>
    
            <div className="flex flex-col mb-3">
                <label  className="block text-[#111928] text-sm font-medium mb-1">Customer Billing Address <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
                <Input
                    bgColor="bg-[#F8F6F2]"
                    radius="rounded-lg"
                    height="h-[3.5vw] min-h-[3.5vh]"
                    padding="p-[1vw]"
                    type="text"
                    color="text-[#838481]"
                    textSize="text-[1vw]"
                    fontWeight="font-medium"
                    name="customerBillingAddress"
                    value={formData.customerBillingAddress}
                    onChange={handleChange}
                />
                {errors.customerBillingAddress && (
                    <p className="text-red-500 text-xs">{errors.customerBillingAddress}</p>
                )}
            </div>

            <div className="flex flex-col mb-3">
                <label  className="block text-[#111928] text-sm font-medium mb-1">Customer Shipping Address <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
                <Input
                    bgColor="bg-[#F8F6F2]"
                    radius="rounded-lg"
                    height="h-[3.5vw] min-h-[3.5vh]"
                    padding="p-[1vw]"
                    type="text"
                    color="text-[#838481]"
                    textSize="text-[1vw]"
                    fontWeight="font-medium"
                    name="customerShippingAddress"
                    value={formData.customerShippingAddress}
                    onChange={handleChange}
                />
                {errors.customerShippingAddress && (
                    <p className="text-red-500 text-xs">{errors.customerShippingAddress}</p>
                )}
            </div>
    
            <div className="flex flex-col mb-3">
                <label  className="block text-[#111928] text-sm font-medium mb-1">Customer GST Number <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
                <Input
                    bgColor="bg-[#F8F6F2]"
                    radius="rounded-lg"
                    height="h-[3.5vw] min-h-[3.5vh]"
                    padding="p-[1vw]"
                    type="text"
                    color="text-[#838481]"
                    textSize="text-[1vw]"
                    fontWeight="font-medium"
                    name="customerGSTNumber"
                    value={formData.customerGSTNumber}
                    onChange={handleChange}
                />
                {errors.customerGSTNumber && (
                    <p className="text-red-500 text-xs">{errors.customerGSTNumber}</p>
                )}
            </div>
    
            <label  className="block text-[#111928] text-sm font-medium mb-1">List Of Products</label>
            <div className="flex flex-col mb-2 p-4 border-2 border-[#F8F6F2] rounded-lg bg-white">
                <div className="flex flex-col mb-2">
                    <label  className="block text-[#111928] text-sm font-medium mb-1">Select Category <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
                    <CategoryDropdown bgColor="#F8F6F2" options={allCategories} />
                </div>
                <div className="flex flex-col mb-2">
                    <label  className="block text-[#111928] text-sm font-medium mb-1">Select Product <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
                    <ProductDropdown
                        name="product_id"
                        bgColor="#F8F6F2"
                        options={allProductsByCatId}
                    />
                </div>
                <div className="flex flex-col mb-2">
                    <label  className="block text-[#111928] text-sm font-medium mb-1" >Price Per Unit <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
                    <Input
                        bgColor="bg-[#F8F6F2]"
                        radius="rounded-lg"
                        height="h-[3.5vw] min-h-[3.5vh]"
                        padding="p-[1vw]"
                        type="number"
                        color="text-[#838481]"
                        textSize="text-[1vw]"
                        fontWeight="font-medium"
                        name="price"
                        placeholder="Enter Price per unit here"
                        value={productPrice}
                        onChange={(e) => setProductPrice(e.target.value)}
                    />
                </div>
    
                <div onClick={handleAddProduct} className="mt-2">
                    <Button
                        title="Add Product"
                        bgColor="bg-[rgb(79,201,218)]"
                        radius="rounded-lg"
                        height="h-[3vw] min-h-[3vh]"
                        padding="p-[1vw]"
                        color="text-[#ffff]"
                        textSize="text-[1vw]"
                        fontWeight="font-medium"
                        width="w-[10vw]"
                    />
                </div>
                {errors.listOfProducts && (
                    <p className="text-red-500 text-xs">{errors.listOfProducts}</p>
                )}
    
                <div className="mt-2">
                    {formData.listOfProducts.length > 0 && <label>Products :</label>}
                    <ul className="flex flex-row gap-4">
                        {formData.listOfProducts.map((product, index) => (
                            <li
                                key={index}
                                className="awb-number border bg-[#F8F6F2] text-black rounded-lg p-2 text-sm text-start"
                                onClick={() => handleRemoveProductsFromList(index)}
                            >
                                <span 
                                    className="remove-text text-xs font-semibold bg-red-500 text-white px-2 py-1 rounded-lg border border-red-700"
                                >
                                    Remove
                                </span>

                                <div className="flex flex-col">
                                    <span className="number px-3 text-black">
                                        Product Name: {product?.productName}
                                    </span>
                                    <span className="number px-3 text-black">
                                        Price Per Unit: {product?.price}
                                    </span>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
    
            <div className="flex flex-row gap-5">
                <div className="mt-2" onClick={onFormSubmit}>
                    <Button
                        title="Create Customer"
                        bgColor="bg-[rgb(79,201,218)]"
                        radius="rounded-lg"
                        height="h-[3vw] min-h-[3vh]"
                        padding="p-[1vw]"
                        color="text-[#ffff]"
                        textSize="text-[1vw]"
                        fontWeight="font-medium"
                        width="w-[14vw]"
                    />
                </div>
            </div>
    
            {formDisabled && (
                <div className="fixed top-0 left-0 w-full h-full bg-gray-400 opacity-50 z-50" />
            )}
        </div>
    );
    
};

export default CreateB2BCustomerForm;
