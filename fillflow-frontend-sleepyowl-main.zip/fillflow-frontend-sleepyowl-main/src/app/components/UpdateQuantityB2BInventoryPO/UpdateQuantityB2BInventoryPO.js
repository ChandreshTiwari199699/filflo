import React, { useState } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import { PrimaryButton, SecondaryButton } from "../ButtonComponent/ButtonComponent";
import { b2bInventoryPOService } from "../../services/b2bInventoryPOService";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const UpdateQuantityB2BInventoryPO = ({
  setIsSidebarOpen,
  selectedPO,
  filteredData,
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [changeReasons, setChangeReasons] = useState({});
  const [reasonErrors, setReasonErrors] = useState({});

  const validationSchema = Yup.object().shape(
    selectedPO.reduce((acc, poID) => {
      const po = filteredData.find((po) => po._id === poID);
      if (po) {
        acc[poID] = Yup.number()
          .required("Quantity is required")
          .min(0, "Quantity cannot be negative") // Min quantity is 0
          .max(po.quantity, `Max available: ${po.quantity}`);
      }
      return acc;
    }, {})
  );

  const initialValues = selectedPO.reduce((acc, poID) => {
    const po = filteredData.find((po) => po._id === poID);
    if (po) {
      acc[poID] = po.quantity;
    }
    return acc;
  }, {});

  const handleQuantityChange = (event, poID, setFieldValue) => {
    const newQuantity = event.target.value;
    setFieldValue(poID, newQuantity);

    const po = filteredData.find((po) => po._id === poID);
    if (po && newQuantity !== String(po.quantity)) {
      setChangeReasons((prev) => ({
        ...prev,
        [poID]: prev[poID] || "",
      }));
      setReasonErrors((prev) => ({
        ...prev,
        [poID]: "", // Clear error if reason exists
      }));
    } else {
      setChangeReasons((prev) => {
        const updatedReasons = { ...prev };
        delete updatedReasons[poID];
        return updatedReasons;
      });
      setReasonErrors((prev) => {
        const updatedErrors = { ...prev };
        delete updatedErrors[poID];
        return updatedErrors;
      });
    }
  };

  const handleReasonChange = (event, poID) => {
    const reason = event.target.value;
    setChangeReasons((prev) => ({
      ...prev,
      [poID]: reason,
    }));
    setReasonErrors((prev) => ({
      ...prev,
      [poID]: reason ? "" : "Reason is required",
    }));
  };

  const onSubmit = async (values) => {
    let isValid = true;
    const updatedErrors = {};

    selectedPO.forEach((poID) => {
      if (changeReasons[poID] !== undefined && !changeReasons[poID].trim()) {
        updatedErrors[poID] = "Reason is required";
        isValid = false;
      }
    });

    setReasonErrors(updatedErrors);
    if (!isValid) return;

    setIsSubmitting(true);
    try {
      const requestPayload = selectedPO.map((poID) => ({
        poID,
        newQuantity: values[poID],
        reason: changeReasons[poID] || "Updated by user",
      }));

      console.log("Payload Sent:", requestPayload);
      const response = await b2bInventoryPOService.updateB2BInventoryPOQuantity(requestPayload);

      if (response.success) {
        toast.success("Quantities updated successfully!", {
          autoClose: 1000,
          onClose: () => {
            window.location.reload();
          },
        });
      } else {
        toast.error(`Failed to update quantities: ${response.message}`, {
          autoClose: 2000,
        });
      }
    } catch (error) {
      console.error("Error updating quantities:", error);
      toast.error("An error occurred while updating quantities.", {
        autoClose: 2000,
      });
    }
    setIsSubmitting(false);
  };

  return (
    <div>
      <ToastContainer position="bottom-center" />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        {({ setFieldValue }) => (
          <Form>
            <h2 className="text-base font-semibold mb-2">Update Quantity</h2>
            <p className="text-sm font-normal mb-6">
              Modify order quantities within available limits.
            </p>

            <div className="space-y-4 pb-20 overflow-y-auto pr-2">
              {selectedPO.map((poID) => {
                const po = filteredData.find((po) => po._id === poID);
                return (
                  po && (
                    <div key={poID} className="mb-6 bg-gray-2 p-4 rounded-lg">
                      <label className="block text-dark text-sm font-medium mb-1">
                        {`Order ID: ${po.b2b_order_id.orderId}`}
                      </label>
                      <div className="text-sm mb-2">SKU Code: {po.product_id.sku_code}</div>
                      <div className="text-sm mb-2">PO Quantity: {po.quantity}</div>
                      <Field
                        type="number"
                        name={poID}
                        className="w-full border rounded-xl h-10 text-sm p-4"
                        onChange={(e) => handleQuantityChange(e, poID, setFieldValue)}
                      />
                      <ErrorMessage name={poID} component="div" className="text-red-500 text-xs mt-1" />

                      {/* Show reason field if quantity is changed */}
                      {changeReasons[poID] !== undefined && (
                        <div className="mt-2">
                          <label className="block text-dark text-sm font-medium mb-1">Reason for Change <span className="text-red-500">*</span></label>
                          <select
                            className="w-full border rounded-xl text-sm p-2"
                            value={changeReasons[poID]}
                            onChange={(e) => handleReasonChange(e, poID)}
                          >
                            <option value="">Select Reason</option>
                            <option value="Shortage - Raw Material Not Available">Shortage - Raw Material Not Available</option>
                            <option value="Shortage - Finished Good Not Available">Shortage - Finished Good Not Available</option>
                            <option value="Shortage - Packaging Material Not Available">Shortage - Packaging Material Not Available</option>
                          </select>
                          {reasonErrors[poID] && <div className="text-red-500 text-xs mt-1">{reasonErrors[poID]}</div>}
                        </div>
                      )}
                    </div>
                  )
                );
              })}
            </div>

            <div className="absolute bottom-0 left-0 w-full border bg-white p-2">
              <div className="flex gap-x-2">
                <SecondaryButton title="Cancel" onClick={() => setIsSidebarOpen(false)} size="full" />
                <PrimaryButton title="Update" type="submit" size="full" disabled={isSubmitting} />
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default UpdateQuantityB2BInventoryPO;
