import Script from "next/script";

const Analytics = () => {
  return (
    <>
      {/* Load the Google Analytics script */}
      <Script
        async
        src="https://www.googletagmanager.com/gtag/js?id=G-VMWNC0YRS0"
      />

      {/* Inline script to initialize Google Analytics */}
      <Script
        id="google-analytics"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-VMWNC0YRS0');
          `,
        }}
      />
    </>
  );
};

export default Analytics;
