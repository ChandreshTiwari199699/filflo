import React, { useRef } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

const GRNNote = ({ grnData }) => {
  const grnRef = useRef(null);
  const downloadButtonRef = useRef(null);

  const handleDownloadPdf = () => {
    if (downloadButtonRef.current) {
      downloadButtonRef.current.style.display = 'none';
    }
  
    // Ensure invoice background is white
    grnRef.current.style.backgroundColor = '#FFFFFF';
  
    html2canvas(grnRef.current, {
      scale: 2,
      useCORS: true,
      backgroundColor: '#FFFFFF', // Explicitly set background color
      logging: false
    }).then((canvas) => {
      const imgData = canvas.toDataURL('image/jpeg', 0.6);
      const pdf = new jsPDF('p', 'mm', 'a4');
  
      const pdfWidth = 210; 
      const pdfHeight = 297;
      const imgWidth = 190; 
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
  
      let y = 10;
  
      if (imgHeight <= pdfHeight - 20) {
        pdf.addImage(imgData, 'JPEG', 10, y, imgWidth, imgHeight, '', 'FAST');
      } else {
        let position = 0;
        while (position < canvas.height) {
          const section = document.createElement('canvas');
          section.width = canvas.width;
          section.height = (pdfHeight - 20) * (canvas.width / imgWidth);
          const sectionCtx = section.getContext('2d');
  
          // Ensure section canvas has a white background
          sectionCtx.fillStyle = '#FFFFFF';
          sectionCtx.fillRect(0, 0, section.width, section.height);
  
          sectionCtx.drawImage(canvas, 0, -position, canvas.width, canvas.height);
  
          const sectionImgData = section.toDataURL('image/jpeg', 0.6);
          pdf.addImage(sectionImgData, 'JPEG', 10, 10, imgWidth, pdfHeight - 20, '', 'FAST');
  
          position += section.height;
  
          if (position < canvas.height) {
            pdf.addPage();
          }
        }
      }
  
      pdf.save(`${grnNumber}-grn.pdf`);
  
      if (downloadButtonRef.current) {
        downloadButtonRef.current.style.display = 'block';
      }
    });
  };
  const { company, supplier, inwardDate, items, grnNumber, createdAt } = grnData || {};

  const calculateTotal = () => {
    return items?.reduce((sum, item) => {
      return sum + item.inwardedQty * item.price;
    }, 0)?.toFixed(2);
  };

  return (
    <div className="max-w-4xl mx-auto bg-white p-8 shadow-lg">
      <div ref={grnRef}>
        {/* Header with Company Logo and Info */}
        <div className="flex justify-between items-start border-b pb-6">
          <div className="flex items-start gap-4">
            <img src="/brandLogo.svg" alt="Company Logo" className="h-16 w-auto" />
            <div>
              <p className="font-bold">{company?.name}</p>
              <p className="text-sm text-gray-600">{company?.address}</p>
              {company?.gstin && (
                <p className="text-sm text-gray-600">GSTIN: {company.gstin}</p>
              )}
                  {company?.pan && (
                <p className="text-sm text-gray-600">PAN: {company.gstin}</p>
              )}
                  {company?.msme && (
      <p className="text-sm text-gray-600">MSME: {company.msme}</p>
    )}
    {company?.fssai && (
      <p className="text-sm text-gray-600">FSSAI: {company.fssai}</p>
    )}
            </div>

          </div>
          <div className="text-right">
            <h1 className="text-2xl font-bold text-gray-900">Goods Receipt Note</h1>
            <p className="text-sm text-gray-600">GRN #: {grnNumber}</p>
            <p className="text-sm text-gray-600">
              Date: {new Date(createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>

        {/* Supplier Info */}
        <div className="grid grid-cols-1 md:grid-cols-1 gap-8 my-6">
          <div className="border rounded-lg p-4">
            <h3 className="font-semibold text-gray-800 mb-2">Supplier</h3>
            <p className="font-medium">{supplier?.name}</p>
            <p className="text-sm text-gray-600">{supplier?.address}</p>
            {supplier?.gstin && (
              <p className="text-sm text-gray-600">GSTIN: {supplier.gstin}</p>
            )}
          </div>
        </div>

        {/* Items Table */}
        <div className="mt-8 overflow-x-auto">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Inwarded Items</h3>
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-2 py-2 text-left text-sm font-semibold text-gray-600">#</th>
                <th className="px-2 py-2 text-left text-sm font-semibold text-gray-600">Item</th>
                <th className="px-2 py-2 text-right text-sm font-semibold text-gray-600">Ordered Qty</th>
                <th className="px-2 py-2 text-right text-sm font-semibold text-gray-600">Inwarded Qty</th>
                <th className="px-2 py-2 text-right text-sm font-semibold text-gray-600">Price</th>
                <th className="px-2 py-2 text-right text-sm font-semibold text-gray-600">Amount</th>
              </tr>
            </thead>
            <tbody>
              {items?.map((item, i) => (
                <tr key={i} className="border-b">
                  <td className="px-2 py-2 text-sm">{i + 1}</td>
                  <td className="px-2 py-2 text-sm">{item.name}</td>
                  <td className="px-2 py-2 text-right text-sm">{item.orderedQty}</td>
                  <td className="px-2 py-2 text-right text-sm">{item.inwardedQty}</td>
                  <td className="px-2 py-2 text-right text-sm">₹{item.price.toFixed(2)}</td>
                  <td className="px-2 py-2 text-right text-sm">
                    ₹{(item.inwardedQty * item.price).toFixed(2)}
                  </td>
                </tr>
              ))}
              <tr className="bg-gray-100 font-semibold">
                <td colSpan="5" className="px-4 py-2 text-right">
                  Total
                </td>
                <td className="px-4 py-2 text-right">₹{calculateTotal()}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Custom Footer Section */}
        <div className="mt-8 text-center border-t pt-6 relative">
          <p className="text-md text-gray-800">Thank you for your business!</p>
          <p className="text-sm text-gray-600 mt-2">This is a computer-generated grn.</p>

          <div className="mt-2 flex justify-center items-center space-x-2">
            <span className="text-sm text-gray-600">Powered by</span>
            <img src="/logo.svg" alt="Powered by filflo" className="h-6 w-auto" />
          </div>

          <p className="text-sm text-gray-600 mt-2">No signature is required.</p>
        </div>
      </div>

      {/* Download Button */}
      <div className="flex justify-center mt-6 mb-10">
        <button
          ref={downloadButtonRef}
          onClick={handleDownloadPdf}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
        >
          Download GRN PDF
        </button>
      </div>
    </div>
  );
};

export default GRNNote;
