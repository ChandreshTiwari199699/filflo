import moment from "moment";

export const filterByDate = (data, dayFilter, startDate, endDate, dateField = 'createdAt') => {
  let filteredData = data;

  if (dayFilter !== "all") {
      const now = moment();
      filteredData = filteredData.filter((item) => {
          const itemDate = moment(item[dateField]);
          switch (dayFilter) {
              case "7days":
                  return itemDate.isAfter(now.clone().subtract(7, "days"));
              case "14days":
                  return itemDate.isAfter(now.clone().subtract(14, "days"));
              case "30days":
                  return itemDate.isAfter(now.clone().subtract(30, "days"));
              default:
                  return true;
          }
      });
  }

  if (startDate) {
      const startMoment = moment(startDate, "YYYY-MM-DD");
      filteredData = filteredData.filter((item) => moment(item[dateField]).isSameOrAfter(startMoment));
  }

  if (endDate) {
      const endMoment = moment(endDate, "YYYY-MM-DD").endOf("day");
      filteredData = filteredData.filter((item) => moment(item[dateField]).isSameOrBefore(endMoment));
  }

  return filteredData;
};
