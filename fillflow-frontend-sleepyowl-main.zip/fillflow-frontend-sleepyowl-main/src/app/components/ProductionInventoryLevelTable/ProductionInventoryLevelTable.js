"use client";
import React, { useState, useEffect } from "react";
import { rawMaterialServices } from "../../services/rawMaterialService";
import { useDispatch, useSelector } from "react-redux";
import { setRawMaterialIdBatch } from "../../Actions/batchActions";
import { useRouter } from "next/navigation";
import moment from "moment";
import DynamicTableWithoutAction from '@/app/components/DynamicTableWithoutAction/DynamicTableWithoutAction'
import { filterByDate } from '@/app/components/DateFilter/DateFilter';
import searchNested from '@/app/utils/searchUtils';
import TableFilterBar from "../TableFilterBar/TableFilterBar";

const ProductionInventoryLevelTable = () => {
const { allSKUs } = useSelector((state) => state.sku);
  

  const [filter, setFilter] = useState("allSKUs");
  const [dayFilter, setDayFilter] = useState("all");
  const [searchText, setSearchText] = useState("");

  const sortedSKUs = allSKUs.sort((a, b) => {
    return new Date(b.updatedAt) - new Date(a.updatedAt);
  });

  const [filteredData, setFilteredData] = useState(sortedSKUs);

  const applyFilters = () => {
    let data = allSKUs;

    data = filterByDate(data, dayFilter);

    if (filter !== "allSKUs") {
      data = data.filter(
        (item) => item.sku_category.category_name === filter
      );
    }

    data = data.filter((item) =>
      searchKeys.some((key) =>
        searchNested(item[key], searchText.toLowerCase(), key)
      )
    );

    setFilteredData(data);
  };


  useEffect(() => {
    applyFilters();
  }, [filter, allSKUs, searchText, dayFilter]);

  const router = useRouter();
  const dispatch = useDispatch();

  useEffect(() => {
    setFilteredData(sortedSKUs);
  }, [sortedSKUs]);


  const convertToCSV = (data) => {
    const headers = [
      "SKU NAME",
      "SKU CODE",
      "CATEGORY",
      "CURRENT STOCK",
      "LOWER THRESHOLD",
      "UPPER THRESHOLD",
      "UPDATED AT",
    ];
  
    // Function to escape values that contain commas or quotes
    const escapeValue = (value) => {
      if (value) {
        let escapedValue = String(value);
        if (escapedValue.includes(",") || escapedValue.includes('"')) {
          escapedValue = `"${escapedValue.replace(/"/g, '""')}"`;  // Wrap in quotes and escape any existing quotes
        }
        return escapedValue;
      }
      return "N/A";
    };
  
    const rows = data.map((material) => [
      escapeValue(material?.sku_name),  // SKU NAME
      escapeValue(material?.sku_code),  // SKU CODE
      escapeValue(material?.sku_category?.category_name),  // CATEGORY
      escapeValue(material?.current_production_count),  // CURRENT STOCK
      escapeValue(material?.lower_threshold_production),  // LOWER THRESHOLD
      escapeValue(material?.upper_threshold_production),  // UPPER THRESHOLD
      escapeValue(moment(material?.updatedAt).format("DD MMM YYYY")),  // UPDATED AT
    ]);
  
    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers.join(","), ...rows.map((row) => row.join(","))].join("\n");
  
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    const currentDateAndFileName = `Storage_Inventory_Level_${moment().format("DD-MMM-YYYY")}.csv`;
    link.setAttribute("download", currentDateAndFileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  

  const searchKeys = [
    "sku_name",
    "sku_code",
    "sku_category",
    "current_production_count",
  ];

  const headings = {
    current_stock: {
      label: "Current Stock",
      renderCell: (row) => row?.current_production_count || "N/A" ,
      isSticky: false,
    },
    sku_code: {
      label: "SKU Code",
      renderCell: (row) => row?.sku_code || "N/A",
      isSticky: false,
    },
    sku_name: {
      label: "SKU Name",
      renderCell: (row) => row?.sku_name || "N/A",
      isSticky: false,
    },
    category_name: {
      label: "Category",
      renderCell: (row) => row?.sku_category?.category_name || "N/A",
      isSticky: false,
    },
  };

  const generatePOActions = (po) => {
    return [
      {
        label: "View Batches",
        condition: null,
        action: () => {
          dispatch(setRawMaterialIdBatch(po._id));
          router.push("/storage/view_batches");
        }
      },
    ]
  };


  const filterOptions = [
    { value: "allSKUs", label: "All" },
    { value: "Raw Material", label: "Raw Material" },
    { value: "Finished Goods", label: "Finished Goods" },
  ];

  const handleDayFilterChange = (event) => {
    setDayFilter(event.target.value);
  };

  return (
    <>


      <TableFilterBar
        filter={filter}
        setFilter={setFilter}
        searchText={searchText}
        setSearchText={setSearchText}
        convertToCSV={convertToCSV}
        allPO={sortedSKUs}
        filterOptions={filterOptions}
      />

      <DynamicTableWithoutAction headings={headings} rows={filteredData} />
    </>
  );
};

export default ProductionInventoryLevelTable;
