"use client";
import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { PrimaryButton, SecondaryButton, PendingRed } from "@/app/components/ButtonComponent/ButtonComponent";
import Input from "@/app/components/Input/Input";
import { b2bOrderService } from "@/app/services/b2bOrderService";

const EditOrder = ({ selectedOrder, handleCancel }) => {
  const [editOrderData, setEditOrderData] = useState({
    orderInternalId: selectedOrder._id,
   orderId: selectedOrder.orderId,
  remarks: selectedOrder.remarks,
  });

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditOrderData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSaveChanges = async () => {
    try {
      const result = await b2bOrderService.editB2BOrderByOrderInternalId(editOrderData);
      if (result.success) {
        toast.success("B2B Order updated successfully!", {
          autoClose: 1500,
          onClose: () => window.location.reload()
        });
      } else {
        toast.error(`Failed to update order: ${result.error}`);
      }
    } catch (error) {
      toast.error("An unexpected error occurred while updating the order.");
    }
  };


 const handleDeleteOrder = async (orderId) => {
  const confirmation = window.confirm(
    'Are you sure you want to delete this order? This action is irreversible.'
  );

  if (confirmation) {
    try {
      const result = await b2bOrderService.deleteB2BOrderByOrderId(orderId);
   
      if (result.success) {
        toast.success("Order deleted successfully!", {
          autoClose: 1500,
          onClose: () => window.location.reload()
        });
        
      } else {
        toast.error(`Failed to delete order: ${result.message}`);
    } }catch (error) {
      toast.error("An unexpected error occurred while deleting the order.");
    }
  }
};

  return (
    <>
    <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
      <ToastContainer position="bottom-center" />
      <h2 className="text-base font-semibold text-[#111928] mb-1">Edit Order</h2>
      <p className="text-sm font-normal text-[#4B5563] mb-6">
        Edit order details and an option to delete the order
        </p>

    

      <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">
            Order ID
            <span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <Input
            radius={"rounded-xl"}
            height={"h-10"}
            padding={"p-[1vw]"}
            type={"text"}
            color={"text-[#838481]"}
            textSize={"text-sm"}
            fontWeight={"font-normal"}
            name="orderId"
            value={editOrderData.orderId}
            onChange={handleEditChange}
            placeholder={"Edit Order ID"}
          />
        </div>


    

      <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">
            Remarks
            <span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <Input
            radius={"rounded-xl"}
            height={"h-10"}
            padding={"p-[1vw]"}
            type={"text"}
            color={"text-[#838481]"}
            textSize={"text-sm"}
            fontWeight={"font-normal"}
            name="remarks"
            value={editOrderData.remarks}
            onChange={handleEditChange}
            placeholder={"Edit Remarks"}
          />
        </div>
        </div>



      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
            <div className="flex gap-x-3">
              <div className="flex-1">
                <SecondaryButton
                  title="Cancel"
                  onClick={handleCancel}
                  size='full'
                />
              </div>
              <div className="flex-1">
                <PrimaryButton
                  title="Save Changes"
                  type="submit"
                  size='full'
                  onClick={handleSaveChanges}
                />
              </div>
              <div className="flex-1">
                <PendingRed
                  title="Delete Order"
                  type="submit"
                  size='full'
                  onClick={() => handleDeleteOrder(editOrderData.orderInternalId)}

                />
              </div>
            </div>
          </div>
 
    </>
  );
};

export default EditOrder;
