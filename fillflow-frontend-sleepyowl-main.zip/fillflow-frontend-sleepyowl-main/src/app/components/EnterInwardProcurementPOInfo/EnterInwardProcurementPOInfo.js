"use client";
import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { PrimaryButton, SecondaryButton } from "@/app/components/ButtonComponent/ButtonComponent";
import { procurementPOServices } from "@/app/services/procurementPOService";

const EnterInwardProcurementPOInfo = ({ selectedPO, handleCancel }) => {
  
  const [inwardItems, setInwardItems] = useState(
    selectedPO.items.map((item) => {
      const notFulfilledQty = item.quantity_ordered - item.quantity_fulfilled;
      return {
        sku_id: item.sku_id,
        notFulfilledQty,
        quantity_received: "", // user input
      };
    })
  );

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleQuantityChange = (e, index) => {
    const value = e.target.value;
    setInwardItems((prev) => {
      const updated = [...prev];
      updated[index].quantity_received = value;
      return updated;
    });
  };

  const validateInputs = () => {
    const newErrors = {};
    inwardItems.forEach((item, idx) => {
      if (item.quantity_received !== "") {
        const qty = parseInt(item.quantity_received);
        if (isNaN(qty) || qty < 0) {
          newErrors[`item_${idx}`] = "Quantity must be a positive number.";
        } else if (qty > item.notFulfilledQty) {
          newErrors[`item_${idx}`] = `Cannot exceed remaining quantity (${item.notFulfilledQty})`;
        }
      }
    });

    if (!inwardItems.some((item) => item.quantity_received !== "")) {
      newErrors.general = "Please enter at least one received quantity.";
    }

    return newErrors;
  };

  const handleSubmit = async () => {
    const newErrors = validateInputs();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsSubmitting(true);

    const payload = {
      poId: selectedPO._id,
      items: inwardItems
        .filter((item) => item.quantity_received !== "")
        .map((item) => ({
          sku_id: item.sku_id,
          quantity_received: parseInt(item.quantity_received),
        })),
    };

    try {
      const response = await procurementPOServices.enterInwardInfo(payload);
      if (response.success) {
        toast.success("Inward info submitted successfully!", {
          autoClose: 1500,
          onClose: () => window.location.reload(),
        });
      } else {
        toast.error(`Failed to submit: ${response.error}`);
      }
    } catch (error) {
      toast.error("Error while submitting inward info.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div className="relative overflow-y-auto max-h-[80vh] pb-10 text-black">
        <ToastContainer position="bottom-center" />
        <h2 className="text-base font-semibold text-[#111928] mb-1">Enter Inward Info</h2>
        <p className="text-sm text-[#4B5563] mb-4">Log received units for the selected PO.</p>

        {errors.general && <div className="text-red-500 text-sm mb-3">{errors.general}</div>}

        <table className="min-w-full text-sm text-[#111928] font-medium border border-gray-300 rounded-lg overflow-hidden">
          <thead className="text-xs text-[#111928] uppercase bg-gray-200">
            <tr>
              <th className="px-4 py-2 text-left">SKU</th>
              <th className="px-4 py-2 text-left">Qty Left</th>
              <th className="px-4 py-2 text-left">Qty Received</th>
            </tr>
          </thead>
          <tbody>
            {inwardItems.map((item, idx) => (
              <tr key={item.sku_id} className="border-b">
                <td className="px-4 py-2">{item.sku_id?.sku_code}</td>
                <td className="px-4 py-2">{item.notFulfilledQty}</td>
                <td className="px-4 py-2">
                  <input
                    type="number"
                    className={`w-24 border rounded p-1 ${
                      errors[`item_${idx}`] ? "border-red-500" : ""
                    }`}
                    value={item.quantity_received}
                    onChange={(e) => handleQuantityChange(e, idx)}
                    min={0}
                    max={item.notFulfilledQty}
                  />
                  {errors[`item_${idx}`] && (
                    <div className="text-red-500 text-xs mt-1">{errors[`item_${idx}`]}</div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Buttons */}
      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
          </div>
          <div className="flex-1">
            <PrimaryButton
              title="Submit Inward"
              onClick={handleSubmit}
              size="full"
              disabled={isSubmitting}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default EnterInwardProcurementPOInfo;
