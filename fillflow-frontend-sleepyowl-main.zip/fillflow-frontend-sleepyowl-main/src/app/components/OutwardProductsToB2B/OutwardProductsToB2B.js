"use client";
import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import moment from "moment";
import * as Yup from "yup";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { qrCodeRecordsServices } from "@/app/services/qrCodeRecordsService";
import StatusComponent from "../StatusComponent/StatusComponent";
import DynamicTableWithoutAction from "@/app/components/DynamicTableWithoutAction/DynamicTableWithoutAction";
import RightSidebar from "../RightSidebar/RightSidebar";
import { PrimaryButton, SecondaryButton } from "../ButtonComponent/ButtonComponent";
import OutwardB2BQrCodeForm from "../OutwardB2BQrCodeForm/OutwardB2BQrCodeForm";
import { filterByDate } from "@/app/components/DateFilter/DateFilter";
import searchNested from "@/app/utils/searchUtils";
import { b2bInventoryPOService } from '@/app/services/b2bInventoryPOService';
import UpdateQuantityB2BInventoryPO from "../UpdateQuantityB2BInventoryPO/UpdateQuantityB2BInventoryPO";
import TableFilterBarWithSingleButton from '../TableFilterBarWithSingleButton/TableFilterBarWithSingleButton';

const ProcessOrdersModal = ({ isOpen, onClose, orders, selectedOrders, setSelectedOrders, handleProcessOrders }) => {

  if (!isOpen) return null;

  const [processing, setProcessing] = useState(false);

  const toggleOrderSelection = (orderId) => {

    setSelectedOrders(prevSelected =>
      prevSelected.includes(orderId)
        ? prevSelected.filter(id => id !== orderId)
        : [...prevSelected, orderId]
    );
  };

  const handleProcessClick = async () => {
    setProcessing(true);
    await handleProcessOrders();
    setProcessing(false);
  };

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center p-4">
      <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-2xl min-h-64 max-h-[80vh] overflow-y-auto">
        <h2 className="text-lg font-bold mb-4">Select Orders to Process</h2>
        <ul className="max-h-60 overflow-y-auto border p-2 rounded">
          {orders.map((order) => (
            <li key={order.b2b_order_id?.orderId} className="flex justify-between items-center p-2 border-b">
              <span>Order ID: {order.b2b_order_id?.orderId}</span>
              <input
                type="checkbox"
                checked={selectedOrders.includes(order.b2b_order_id?.orderId)}
                onChange={() => toggleOrderSelection(order.b2b_order_id?.orderId)}
                disabled={processing}
              />
            </li>
          ))}
        </ul>
        <div className="mt-4 flex justify-end gap-2">
          <SecondaryButton title="Cancel" onClick={onClose} disabled={processing} />
          <PrimaryButton title="Process" onClick={handleProcessClick} disabled={processing} />
        </div>
      </div>
    </div>
  );
};

Yup.addMethod(
  Yup.string,
  "checkQRCodeStatus2",
  function (message, allQrCodeRecords) {
    return this.test("checkQRCodeStatus", message, function (value) {
      const qrCodeStatus = allQrCodeRecords.find(
        (qrCode) => qrCode.qr_code === value
      );

      if (!qrCodeStatus) {
        return this.createError({
          path: this.path,
          message: `${message} does not exist in the system`,
        });
      }

      return (
        qrCodeStatus.current_status === "Inwarded" ||
        this.createError({
          path: this.path,
          message: `${message} Current status: ${
            qrCodeStatus ? qrCodeStatus.current_status : "Unknown"
          }`,
        })
      );
    });
  }
);

Yup.addMethod(Yup.string, "unique", function (message) {
  return this.test("unique", message, function (value) {
    const { path, parent } = this;
    const siblings = Object.keys(parent)
      .filter((key) => key !== path)
      .map((key) => parent[key]);

    const isUnique = !siblings.includes(value);
    return isUnique || this.createError({ path, message });
  });
});

Yup.addMethod(Yup.string, "startsWithSKU", function (message, skuCode) {
  return this.test("startsWithSKU", message, function (value) {
    if (value && !value.startsWith(skuCode)) {
      return this.createError({
        path: this.path,
        message: `${message} must start with ${skuCode}`,
      });
    }
    return true;
  });
});

const OutwardProductsToB2B = ({ onFilterChange = () => {} }) => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [downloadLoading, setDownloadLoading] = useState(false);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 50,
    total: 0,
    totalPages: 0
  });
  const [filters, setFilters] = useState({
    searchText: '',
    filter: 'all',
    dayFilter: 'all',
    startDate: '',
    endDate: ''
  });

  const [b2bInventoryPO, setB2BInventoryPO] = useState([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isUpdateQuantitySidebarOpen, setIsUpdateQuantitySidebarOpen] = useState(false);
  const sortedPO = b2bInventoryPO.sort(
    (a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)
  );

  const [filteredData, setFilteredData] = useState(sortedPO);
  const [selectedPO, setSelectedPO] = useState([]);
  const [allQrCodeRecords, setAllQrCodeRecords] = useState([]);
  const [validationSchema, setValidationSchema] = useState(Yup.object());
  const [searchText, setSearchText] = useState("");
  const [dayFilter, setDayFilter] = useState("all");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedOrders, setSelectedOrders] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [pendingOrders, setPendingOrders] = useState([]);
  const [pendingOrdersMap, setPendingOrdersMap] = useState({});

  const currentDateAndFileName = `Engraving_Order_${moment().format(
    "DD-MMM-YYYY"
  )}`;

  useEffect(() => {
    setFilteredData(sortedPO);
  }, [sortedPO]);

  const applyFilters = () => {
    let data = b2bInventoryPO;

    data = filterByDate(data, dayFilter);

    data = data.filter((item) =>
      searchKeys.some((key) =>
        searchNested(item[key], searchText.toLowerCase(), key)
      )
    );

    setFilteredData(data);
  };

  useEffect(() => {
    applyFilters();
  }, [b2bInventoryPO, searchText, dayFilter]);

  useEffect(() => {
    // Start QR code streaming

    const getAllQRCodeRecords = async () => {
      const response = await qrCodeRecordsServices.getAllQrCodeRecords();
      if (response.success) {
        setAllQrCodeRecords(response.data);
      }
    };
    getAllQRCodeRecords();
  }, []);
  

  const handleCheckboxChange = (row) => {
    // Ensure we have a valid row with status
    if (!row || !row.status) return;

    // Check status before allowing selection
    if (row.status === "fulfilled" || row.status === "deprecated") {
      toast.error(`Cannot select ${row.status} orders`, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
      return;
    }

    // If status is valid, toggle selection
    setSelectedPO(prevSelected =>
      prevSelected.includes(row._id)
        ? prevSelected.filter(id => id !== row._id)
        : [...prevSelected, row._id]
    );
  };
  
  const handleOutwardPO = () => {
    if (selectedPO.length === 0) {
      toast.error("Please select at least one PO");
      return;
    }

    // Set validation schema for outward
    const schemaFields = selectedPO.reduce((acc, poInternalId) => {
      const po = orders.find((po) => po._id === poInternalId);

      if (po) {
        const product = po.product_id;
        for (let i = 0; i < po.quantity; i++) {
          const fieldName = `qr_${po._id}_${product.skuCode}_${i + 1}`;
          acc[fieldName] = Yup.string()
            .required("QR Code is required")
            .startsWithSKU("QR Code", product.skuCode)
            .unique("This QR Code must be unique")
            .checkQRCodeStatus2("QR Code", allQrCodeRecords);
        }
      }

      return acc;
    }, {});

    setValidationSchema(Yup.object().shape(schemaFields));
    setIsSidebarOpen(true);
  };

  const handleUpdateQuantity = () => {
    if (selectedPO.length === 0) {
      toast.error("Please select at least one PO", {
        autoClose: 2000,
      });
      return;
    }

    // Validate selected POs
    const selectedItems = orders.filter(order => selectedPO.includes(order._id));
    const invalidItems = selectedItems.filter(item => 
      item.status === "fulfilled" || item.status === "deprecated"
    );

    if (invalidItems.length > 0) {
      toast.error("Cannot update fulfilled or deprecated orders", {
        autoClose: 2000,
      });
      return;
    }

    setIsUpdateQuantitySidebarOpen(true);
  };
  


  const handleSubmit = async (values) => {
    setIsSubmitting(true); 
    try {
      // Call the service to process the QR codes
     const response =
       await b2bInventoryPOService.updateB2BInventoryPO(values);

      if (response.success) {
        // Handle success case
        toast.success("PO fulfilled successfully!", {
          autoClose: 2000,
          onClose: () => {
            window.location.reload();
          },
        });
      } else {
        // Handle failure case
        toast.error(`Error: ${response.message}`, {
          autoClose: 2000,
          onClose: () => {
            window.location.reload();
          },
        });
      }
    } catch (error) {
      // Handle any unexpected errors
      console.error("Error in handleSubmit:", error);
      toast.error("An error occurred while submitting the QR codes.", {
        autoClose: 1500,
        onClose: () => {
          window.location.reload();
        },
      });
    }
  };
  const formatStatus = (status) => {
    if (!status) return "";
    return status
      .split("_")
      .map((word, index) => {
        if (index === 0) return word.toLowerCase(); // First word remains in lowercase
        return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase(); // Capitalize subsequent words
      })
      .join("");
  };

  const convertToCSV = (data) => {
    // Define the headers based on the `headings` object
    const headers = [
      "ORDER ID", 
      "PRODUCT NAME", 
      "QUANTITY", 
      "STATUS"
    ];
  
    // Map the data into rows, reflecting the table structure
    const rows = data
      .map((po) => {
        return [
          po?.b2b_order_id?.orderId || "N/A", // ORDER ID
          po?.product_id?.product_name || "N/A", // PRODUCT NAME
          po?.quantity || "N/A", // QUANTITY
          formatStatus(po?.status) || "N/A", // STATUS (formatted)
        ];
      }); 
    
    // Create the CSV content with headers and rows
    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers.join(","), ...rows.map((row) => row.join(","))].join("\n");
  
    // Encode the URI for downloading the CSV
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", currentDateAndFileName); // Use the current date as the file name
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link); // Clean up the DOM after downloading
  };
  
  



  const headings = {
    checkbox: {
      label: "Select",
      isCheckbox: true,
      onChange: handleCheckboxChange,
      renderCell: (row) => (
        <input
          type="checkbox"
          checked={selectedPO.includes(row._id)}
          onChange={() => handleCheckboxChange(row)}
          className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded"
        />
      ),
      isSticky: false,
    },
    

  
    orderID: {
      label: "Order ID",
      renderCell: (row) => row?.b2b_order_id?.orderId || "N/A",
      isSticky: false,
    },
    productName: {
        label: "Product Name",
        renderCell: (row) => row?.product_id?.product_name || "N/A",
        isSticky: false,
      },

      quantity: {
        label: "Quantity",
        renderCell: (row) => row?.quantity || "N/A",
        isSticky: false,
      },
    

    status: {
      label: "Status",
      renderCell: (row) => <StatusComponent status={row?.status} /> || "N/A",
      isSticky: false,
    },
    
    

  };
  const searchKeys = [
    "b2b_order_id","product_id", "quantity", "status" ];


    


  const handleDayFilterChange = (event) => {
    setDayFilter(event.target.value);
  };


  useEffect(() => {
    const fetchPendingOrders = async () => {
      try {
        const response = await b2bInventoryPOService.getUniquePendingB2BInventoryPOIds();
        if (response.success) {
          // Convert the key-value object into an array of orders with orderId and _id
          const ordersArray = Object.entries(response.data).map(([orderId, _id]) => ({
            b2b_order_id: { orderId },
            _id
          }));
          setPendingOrders(ordersArray);
          setPendingOrdersMap(response.data);
        } else {
          console.error("Failed to fetch pending orders:", response.message);
        }
      } catch (error) {
        console.error("Error fetching pending orders:", error);
      }
    };

    fetchPendingOrders();
  }, []);

  const handleProcessOrders = async () => {
    if (selectedOrders.length === 0) {
      toast.error("Please select at least one order", { autoClose: 2000 });
      return;
    }

    try {
      
      const response = await b2bInventoryPOService.processB2BInventoryPOs({
        selectedOrders: selectedOrders // Changed from selectedOrders to poIds
      });
      
      if (response.success) {
        toast.success("Orders processed successfully!", {
          autoClose: 2000,
          onClose: () => {
            setIsModalOpen(false);
            fetchOrders(); // Refresh the orders list
          }
        });
      } else {
        toast.error(`Error: ${response.message}`, { autoClose: 2000 });
      }
    } catch (error) {
      console.error("Error processing orders:", error);
      toast.error("An error occurred while processing the orders.", { autoClose: 2000 });
    }
  };
  
  const fetchOrders = async () => {
    setLoading(true);
    try {
      const response = await b2bInventoryPOService.getAllB2BInventoryPO({
        page: pagination.page,
        limit: pagination.limit,
        searchText: filters.searchText,
        filter: filters.filter,
        dayFilter: filters.dayFilter,
        startDate: filters.startDate,
        endDate: filters.endDate
      });

      if (response.success) {
        const updatedData = response.data.map((po) => ({
          ...po,
          product_id: {
            ...po.product_id,
            skuCode: po.product_id.sku_code,
          },
        }));
        setOrders(updatedData);
        setPagination(prev => ({
          ...prev,
          total: response.pagination.total,
          totalPages: response.pagination.totalPages
        }));
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast.error('Failed to fetch orders');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    onFilterChange(filters);
  }, [pagination.page, pagination.limit, filters]);

  const handleFilterChange = (newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleDownloadCSV = async () => {
    setDownloadLoading(true);
    try {
      const response = await b2bInventoryPOService.getAllB2BInventoryPOForDownload(filters);
      if (response.success && response.data.length > 0) {
        const csvData = response.data.map(order => ({
          'Order ID': order.b2b_order_id?.orderId || 'N/A',
          'Product Name': order.product_id?.product_name || 'N/A',
          'SKU Code': order.product_id?.skuCode || 'N/A',
          'Quantity': order.quantity || 'N/A',
          'Status': order.status || 'N/A',
          'Created At': moment(order.createdAt).format('DD/MM/YYYY'),
          'Updated At': moment(order.updatedAt).format('DD/MM/YYYY'),
        }));
        
        const headers = Object.keys(csvData[0]);
        const csvContent = [
          headers.join(','),
          ...csvData.map(row => headers.map(header => `"${row[header]}"`).join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `b2b_inventory_po_${moment().format('YYYY-MM-DD')}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        toast.warning('No data available for download');
      }
    } catch (error) {
      console.error('Error downloading CSV:', error);
      toast.error('Failed to download CSV');
    } finally {
      setDownloadLoading(false);
    }
  };

  const filterOptions = [
    { value: "all", label: "All Orders" },
    { value: "pending", label: "Pending Orders" },
    { value: "fulfilled", label: "Fulfilled Orders" },
    { value: "deprecated", label: "Deprecated Orders" },
  ];

  return (
    <>
      <div className="flex flex-col gap-4">
        <div className="flex gap-x-2">
             <ToastContainer />
          <div className="flex-1">
            <TableFilterBarWithSingleButton
              filter={filters.filter}
              setFilter={(value) => handleFilterChange({ filter: value })}
              searchText={filters.searchText}
              setSearchText={(value) => handleFilterChange({ searchText: value })}
              dayFilter={filters.dayFilter}
              handleDayFilterChange={(e) => handleFilterChange({ dayFilter: e.target.value })}
              startDate={filters.startDate}
              setStartDate={(date) => handleFilterChange({ startDate: date })}
              endDate={filters.endDate}
              setEndDate={(date) => handleFilterChange({ endDate: date })}
              onDownloadCSV={handleDownloadCSV}
              filterOptions={filterOptions}
              isLoading={downloadLoading}
            />
          </div>
          <SecondaryButton
            title="Update Quantity"
            onClick={handleUpdateQuantity}
            size="medium"
          />
          <PrimaryButton
            title="Outward to B2B"
            onClick={handleOutwardPO}
            size="medium"
          />
        </div>

        <div>
          <PrimaryButton 
            title="Process Orders Without Scanning" 
            onClick={() => setIsModalOpen(true)} 
            size="medium" 
          />
        </div>

        {loading ? (
          <div className="flex justify-center items-center p-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        ) : (
          <DynamicTableWithoutAction 
            headings={headings} 
            rows={orders}
            pagination={{
              ...pagination,
              onPageChange: (newPage) => setPagination(prev => ({ ...prev, page: newPage })),
              onLimitChange: (newLimit) => setPagination(prev => ({ ...prev, limit: newLimit, page: 1 }))
            }}
          />
        )}
      </div>

      <ProcessOrdersModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        orders={pendingOrders}
        selectedOrders={selectedOrders}
        setSelectedOrders={setSelectedOrders}
        handleProcessOrders={handleProcessOrders}
      />
  
      <RightSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      >
        <OutwardB2BQrCodeForm
          selectedPO={selectedPO}
          filteredData={orders.filter(order => selectedPO.includes(order._id))}
          allQrCodeRecords={allQrCodeRecords}
          validationSchema={validationSchema}
          handleSubmit={handleSubmit}
          handleCheckboxChange={handleCheckboxChange}
          setIsSidebarOpen={setIsSidebarOpen}
          isSubmitting={isSubmitting}
        />
      </RightSidebar>
  
      <RightSidebar
        isOpen={isUpdateQuantitySidebarOpen}
        onClose={() => setIsUpdateQuantitySidebarOpen(false)}
      >
        <UpdateQuantityB2BInventoryPO
          selectedPO={selectedPO}
          filteredData={orders.filter(order => selectedPO.includes(order._id))}
          setIsSidebarOpen={setIsUpdateQuantitySidebarOpen}
          onSuccess={fetchOrders}
        />
      </RightSidebar>
    </>
  );
};

export default OutwardProductsToB2B;
  