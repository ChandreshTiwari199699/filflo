"use client";
import React, { useState, useEffect } from "react";
import CategoryDropdown from "../CategoryDropdown/CategoryDropdown";
import {
  getAllCategorySuccess,
  getAllCategoryRequest,
  getAllCategoryFailure,
} from "../../Actions/categoryActions";
import Input from "../Input/Input";
import Button from "../Button/Button";
import { productServices } from "@/app/services/productService";
import { sfgCategories } from "@/app/constants/categoryConstants";
import {
  getAllMaterialFailure,
  getAllMaterialSuccess,
  getAllMaterialRequest,
} from "@/app/Actions/materialActions";
import { useDispatch, useSelector } from "react-redux";
import { categoryServices } from "@/app/services/categoryService";
import { rawMaterialServices } from "@/app/services/rawMaterialService";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; 

const CreateProductForm = () => {
  const dispatch = useDispatch();
  const { allCategories, selectedCatId } = useSelector((state) => state.category);
  const { dropDownMatValue, dropDownMatName } = useSelector((state) => state.dropdown);
  const warehouse_id = useSelector((state) => state.auth.userInfo.warehouseId);

  const [rawMaterialQuantity, setRawMaterialQuantity] = useState(null);
  const allMaterials = useSelector((state) => state.material.allMaterials);
  const [errors, setErrors] = useState({});
  const [formDisabled, setFormDisabled] = useState(false);
  const units = ["kilograms", "litres", "units"];
  const taxSlabs = ["TAX-05", "TAX-12", "TAX-18"];

  const [formData, setFormData] = useState({
    product_name: "",
    product_description: "",
    product_category_id: "",
    unit_of_measure: null,
    current_stock: null,
    current_count: null,
    lower_threshold: null,
    upper_threshold: null,
    warehouse_id: warehouse_id,
    sku_code: "",
    hsn_code: "",
    tax_slab: "",
    ppu: "",
    blinkit_sku_code: "",
    swiggy_sku_code: "",
    zepto_sku_code: "",
    case_size:"",
  });

  const handleRemoveItemFromList = (index) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      items: prevFormData.items.filter((_, i) => i !== index),
    }));
  };

  const handleAddItem = () => {
    if (dropDownMatValue && rawMaterialQuantity) {
      const newItem = {
        rawmaterial_id: dropDownMatValue,
        quantity: rawMaterialQuantity,
        itemName: dropDownMatName,
      };
      setFormData((prevFormData) => ({
        ...prevFormData,
        items: [...prevFormData.items, newItem],
      }));
      setRawMaterialQuantity("");
      setErrors({});
    } else {
      setErrors((prevErrors) => ({
        ...prevErrors,
        items: "Please select a product and enter quantity.",
      }));
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const getAllCategories = async () => {
    try {
      dispatch(getAllCategoryRequest());
      const response = await categoryServices.getAllCategories();
      const fgCategories = response.data.filter(
        (category) => !sfgCategories.includes(category.category_name)
      );
      if (response.success) {
        dispatch(getAllCategorySuccess(fgCategories));
      }
    } catch (err) {
      console.log(err);
      dispatch(getAllCategoryFailure());
    }
  };

  const getAllMaterials = async () => {
    try {
      dispatch(getAllMaterialRequest());
      const response = await rawMaterialServices.getAllRawMaterials();
      if (response.success) {
        dispatch(getAllMaterialSuccess(response.data));
      }
    } catch (error) {
      console.log(error);
      dispatch(getAllMaterialFailure());
    }
  };

  useEffect(() => {
    getAllMaterials();
    setFormData((prevFormData) => ({
      ...prevFormData,
      product_category_id: selectedCatId,
    }));
  }, [selectedCatId]);

  useEffect(() => {
    getAllCategories();
  }, []);

  const validateForm = () => {
    const newErrors = {};
    if (!formData.product_name) newErrors.product_name = "Product name is required.";
    if (!formData.sku_code) newErrors.sku_code = "SKU code is required.";
    if (!formData.product_category_id) newErrors.product_category_id = "Category is required.";
    if (!formData.ppu) newErrors.ppu = "PPU (Inclusive of tax) is required.";
    if (!formData.tax_slab) newErrors.tax_slab = "Tax Slab is required.";
    if (!formData.hsn_code) newErrors.hsn_code = "HSN Code is required.";
    if (!formData.case_size) newErrors.case_size = "Case size is required.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const onFormSubmit = async () => {
    if (!validateForm()) return;
    try {
      const response = await productServices.createNewProduct(formData);
      if (response?.success) {
        toast.success('Product Created Successfully', {
          autoClose: 1500,
          onClose: () => window.location.reload(),
        });
        setFormDisabled(true);
      } else {
        toast.error('Failed to create product: ' + (response?.message || 'Unknown error'), {
          autoClose: 5000,
          onClose: () => window.location.reload(),
        });
        setFormDisabled(true);
      }
    } catch (err) {
      toast.error('Failed to create product: ' + err, { autoClose: 3000 });
      window.location.reload();
    }
  };

  return (
    <div className="h-[78vh] min-h-[78vh] max-h-[78vh] overflow-y-scroll">
      <ToastContainer />

      <h2 className="text-base font-semibold text-[#111928] mb-1">Create Product</h2>
      <p className="text-sm font-normal text-[#4B5563] mb-6">
        Add in details to create a new product
      </p>

      {/* Product Name */}
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">Product Name</label>
        <Input
          name="product_name"
          value={formData.product_name}
          onChange={handleChange}
          {...inputProps}
        />
        {errors.product_name && <p className="text-red-500 text-xs">{errors.product_name}</p>}
      </div>

      {/* Product Description */}
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">Product Description</label>
        <Input
          name="product_description"
          value={formData.product_description}
          onChange={handleChange}
          {...inputProps}
        />
      </div>

      {/* Category Dropdown */}
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">Select Category</label>
        <CategoryDropdown bgColor={"#F8F6F2"} options={allCategories} />
        {errors.product_category_id && (
          <p className="text-red-500 text-xs">{errors.product_category_id}</p>
        )}
      </div>

      {/* Unit of Measure */}
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">Unit of Measure</label>
        <select
          className="w-full p-2 border font-normal text-sm h-10 px-4 bg-white border-gray-300 text-[#4B5563] rounded-xl focus:outline-none"
          name="unit_of_measure"
          value={formData.unit_of_measure}
          onChange={handleChange}
        >
          <option value="">Select Unit of Measure</option>
          {units.map((unit) => (
            <option key={unit} value={unit}>{unit}</option>
          ))}
        </select>
      </div>

      {/* Stock, Thresholds, SKU */}
      {["current_stock", "lower_threshold", "upper_threshold", "sku_code"].map((field) => (
        <div className="flex flex-col mb-3" key={field}>
          <label className="block text-[#111928] text-sm font-medium mb-1">
            {field.replace("_", " ").replace(/\b\w/g, l => l.toUpperCase())}
          </label>
          <Input
            name={field}
            value={formData[field]}
            onChange={handleChange}
            {...inputProps}
          />
          {errors[field] && <p className="text-red-500 text-xs">{errors[field]}</p>}
        </div>
      ))}

      {/* PPU */}
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">MRP (Inclusive of Tax)</label>
        <Input
          name="ppu"
          value={formData.ppu}
          onChange={handleChange}
          {...inputProps2}
        />
        {errors.ppu && <p className="text-red-500 text-xs">{errors.ppu}</p>}
      </div>

      {/* Tax Slab */}
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">Tax Slab</label>
        <select
          className="w-full p-2 border font-normal text-sm h-10 px-4 bg-white border-gray-300 text-[#4B5563] rounded-xl focus:outline-none"
          name="tax_slab"
          value={formData.tax_slab}
          onChange={handleChange}
        >
          <option value="">Select Tax Slab</option>
          {taxSlabs.map((slab) => (
            <option key={slab} value={slab}>{slab}</option>
          ))}
        </select>
        {errors.tax_slab && <p className="text-red-500 text-xs">{errors.tax_slab}</p>}
      </div>

      {/* HSN Code */}
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">HSN Code</label>
        <Input
          name="hsn_code"
          value={formData.hsn_code}
          onChange={handleChange}
          {...inputProps}
        />
        {errors.hsn_code && <p className="text-red-500 text-xs">{errors.hsn_code}</p>}
      </div>

      {/* Case Size */}
<div className="flex flex-col mb-3">
  <label className="block text-[#111928] text-sm font-medium mb-1">Case Size</label>
  <Input
    name="case_size"
    value={formData.case_size}
    onChange={handleChange}
    {...inputProps2}
  />
    {errors.case_size && <p className="text-red-500 text-xs">{errors.case_size}</p>}
</div>

      {/* Blinkit SKU Code */}
<div className="flex flex-col mb-3">
  <label className="block text-[#111928] text-sm font-medium mb-1">Blinkit SKU Code</label>
  <Input
    name="blinkit_sku_code"
    value={formData.blinkit_sku_code}
    onChange={handleChange}
    {...inputProps}
  />
</div>

{/* Swiggy SKU Code */}
<div className="flex flex-col mb-3">
  <label className="block text-[#111928] text-sm font-medium mb-1">Swiggy SKU Code</label>
  <Input
    name="swiggy_sku_code"
    value={formData.swiggy_sku_code}
    onChange={handleChange}
    {...inputProps}
  />

</div>

{/* Zepto SKU Code */}
<div className="flex flex-col mb-3">
  <label className="block text-[#111928] text-sm font-medium mb-1">Zepto SKU Code</label>
  <Input
    name="zepto_sku_code"
    value={formData.zepto_sku_code}
    onChange={handleChange}
    {...inputProps}
  />
</div>


      {/* Submit Button */}
      <div className="flex flex-row gap-5">
        <div className="mt-2" onClick={onFormSubmit}>
          <Button
            title={"Create Product"}
            bgColor={"bg-[rgb(79,201,218)]"}
            radius={"rounded-lg"}
            height={"h-[3vw] min-h-[3vh]"}
            padding={"p-[1vw]"}
            color={"text-[#ffff]"}
            textSize={"text-[1vw]"}
            fontWeight={"font-medium"}
            width={"w-[14vw]"}
          />
        </div>
      </div>

      {formDisabled && (
        <div className="fixed top-0 left-0 w-full h-full bg-gray-400 opacity-50 z-50" />
      )}
    </div>
  );
};

// Shared props for Input component
const inputProps = {
  bgColor: "bg-[#F8F6F2]",
  radius: "rounded-lg",
  height: "h-[3.5vw] min-h-[3.5vh]",
  padding: "p-[1vw]",
  type: "text",
  color: "text-[#838481]",
  textSize: "text-[1vw]",
  fontWeight: "font-medium",
};

const inputProps2 = {
  bgColor: "bg-[#F8F6F2]",
  radius: "rounded-lg",
  height: "h-[3.5vw] min-h-[3.5vh]",
  padding: "p-[1vw]",
  type: "number",
  color: "text-[#838481]",
  textSize: "text-[1vw]",
  fontWeight: "font-medium",
};

export default CreateProductForm;
