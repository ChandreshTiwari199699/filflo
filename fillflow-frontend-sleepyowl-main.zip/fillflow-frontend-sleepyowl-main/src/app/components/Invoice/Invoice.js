import React, { useRef, useState } from 'react';
import { Building2 } from 'lucide-react';
import QRCode from "react-qr-code";
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

const Invoice = ({ data }) => {
  const invoiceRef = useRef();
  const printButtonRef = useRef();  
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  const handleDownloadPdf = () => {
    console.log("Starting PDF generation..."); // Debug log
    
    if (printButtonRef.current) {
      printButtonRef.current.style.display = 'none';
    }
  
    // Set PDF generation state to true
    setIsGeneratingPdf(true);
  
    // Ensure invoice background is white
    invoiceRef.current.style.backgroundColor = '#FFFFFF';
  
    // Small delay to ensure styles are applied
    setTimeout(() => {
      html2canvas(invoiceRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#FFFFFF',
        logging: false
      }).then((canvas) => {
        console.log("Canvas generated successfully"); // Debug log
        const imgData = canvas.toDataURL('image/jpeg', 0.6);
        const pdf = new jsPDF('p', 'mm', 'a4');
    
        const pdfWidth = 210; 
        const pdfHeight = 297;
        const imgWidth = 190; 
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
        let y = 10;
    
        if (imgHeight <= pdfHeight - 20) {
          console.log("Adding single page to PDF"); // Debug log
          pdf.addImage(imgData, 'JPEG', 10, y, imgWidth, imgHeight, '', 'FAST');
        } else {
          console.log("Adding multiple pages to PDF"); // Debug log
          let position = 0;
          while (position < canvas.height) {
            const section = document.createElement('canvas');
            section.width = canvas.width;
            section.height = (pdfHeight - 20) * (canvas.width / imgWidth);
            const sectionCtx = section.getContext('2d');
    
            sectionCtx.fillStyle = '#FFFFFF';
            sectionCtx.fillRect(0, 0, section.width, section.height);
    
            sectionCtx.drawImage(canvas, 0, -position, canvas.width, canvas.height);
    
            const sectionImgData = section.toDataURL('image/jpeg', 0.6);
            pdf.addImage(sectionImgData, 'JPEG', 10, 10, imgWidth, pdfHeight - 20, '', 'FAST');
    
            position += section.height;
    
            if (position < canvas.height) {
              pdf.addPage();
            }
          }
        }
    
        console.log("Saving PDF..."); // Debug log
        pdf.save(`${data.invoiceDetails.number}-invoice.pdf`);
    
        if (printButtonRef.current) {
          printButtonRef.current.style.display = 'block';
        }
        
        // Reset PDF generation state
        setIsGeneratingPdf(false);
      });
    }, 100); // Small delay to ensure styles are applied
  };
  
  
  
  return (
      <div ref={invoiceRef} className="max-w-4xl mx-auto bg-white p-8 shadow-lg">
        <style jsx>{`
          .generating-pdf tr:nth-child(7) {
            border-bottom: none !important;
          }
          .generating-pdf tr:nth-child(7) + tr {
            height: 48px;
          }
        `}</style>
        {/* Header Section */}
        <div className="flex justify-between items-start border-b pb-6">
          {/* Left: Logo */}
          <div className="flex-shrink-0">
            {data.seller.logo ? (
              <img src="/brandLogo.svg" alt="Company Logo" className="h-16 w-auto" />
            ) : (
              <Building2 className="h-16 w-16 text-gray-700" />
            )}
          </div>

          {/* Middle: Seller Details (Starts right after logo, max 50% width) */}
          <div className="max-w-1/2 flex-grow px-4">
            <h1 className="text-2xl font-bold text-gray-900">{data.seller.companyName}</h1>
            <p className="text-sm text-gray-600">GSTIN: {data.seller.gstNumber}</p>
            <p className="text-sm text-gray-600">PAN: {data.seller.panNumber}</p>
            <p className="text-sm text-gray-600">MSME REGISTRATION: {data.seller.msmeNumber}</p>
            <p className="text-sm text-gray-600">FSSAI NO: {data.seller.fssaiNumber}</p>
            
            <p className="text-sm text-gray-600 mt-1 max-w-1/4 break-words whitespace-normal">
              {data.seller.address}
            </p>
            <p className="text-sm text-gray-600 mt-1">{data.seller.city}, {data.seller.pincode}</p>
          </div>

          {/* Right: Invoice Details */}
          <div className="text-right flex-shrink-0">
            <h2 className="text-xl font-semibold text-gray-900">TAX INVOICE</h2>
            <p className="text-sm text-gray-600 mt-1">Invoice #: {data.invoiceDetails.number}</p>
            <p className="text-sm text-gray-600">Date: {data.invoiceDetails.date}</p>
            <p className="text-sm text-gray-600">Order Ref / PO No: {data.invoiceDetails.orderNo}</p>
            <p className="text-sm text-gray-600">Order Date: {data.invoiceDetails.orderDate}</p>
          </div>
        </div>

        {/* Billing & Shipping Section */}
        <div className="grid grid-cols-2 gap-8 my-6">
          <div className="border rounded-lg p-4">
            <h3 className="font-semibold text-gray-800 mb-2">Bill To:</h3>
            <p className="font-medium">{data.billing.companyName}</p>
            <p className="text-sm text-gray-600">{data.billing.address}</p>
            <p className="text-sm text-gray-600">GST: {data.billing.gstNumber}</p>
          </div>
          <div className="border rounded-lg p-4">
            <h3 className="font-semibold text-gray-800 mb-2">Ship To:</h3>
            <p className="font-medium">{data.shipping.companyName}</p>
            <p className="text-sm text-gray-600">{data.shipping.address}</p>
            <p className="text-sm text-gray-600">GST: {data.shipping.gstNumber}</p>
          </div>
        </div>

        {/* Items Table */}
        <div className="mt-8 overflow-x-auto">
  <h3 className="text-lg font-semibold text-gray-900 mb-4">Item Details</h3>
  <table className="w-full">
    <thead>
      <tr className="bg-gray-50">
        <th className="px-1 py-2 text-left text-sm font-semibold text-gray-600">Sr.</th>
        <th className="px-2 py-2 text-left text-sm font-semibold text-gray-600">Item</th>
        <th className="px-2 py-2 text-left text-sm font-semibold text-gray-600">HSN</th>
       
        <th className="px-1 py-2 text-left text-sm font-semibold text-gray-600">Qty (Case units)</th>
        <th className="px-1 py-2 text-left text-sm font-semibold text-gray-600">Qty (Item units)</th>
        <th className="px-1 py-2 text-left text-sm font-semibold text-gray-600">GST Rate</th>
        <th className="px-1 py-2 text-left text-sm font-semibold text-gray-600">Mrp Per Unit</th>
        <th className="px py-2 text-right text-sm font-semibold text-gray-600">Rate Per Unit</th>
        {/* <th className="px-2 py-2 text-right text-sm font-semibold text-gray-600">IGST</th>
        <th className="px-2 py-2 text-right text-sm font-semibold text-gray-600">CGST</th>
        <th className="px-2 py-2 text-right text-sm font-semibold text-gray-600">SGST</th> */}
        <th className="px-2 py-2 text-right text-sm font-semibold text-gray-600">Taxable Amount</th>
      </tr>
    </thead>
    <tbody>
  {data.items.map((item, index) => {
    console.log(`Rendering item ${index + 1}, isGeneratingPdf:`, isGeneratingPdf); // Debug log
    return (
      <React.Fragment key={item.serialNo}>
        <tr className="border-b">
          <td className="px-1 py-2 text-left text-sm">{item.serialNo}</td>
          <td className="px-2 py-2 text-left text-sm">
            <div>
              {item.name}
              <br />
              (<span className="text-gray-500">{item.sku_code}</span>)
            </div>
          </td>
          <td className="px-2 py-2 text-left text-sm">{item.hsn}</td>
          <td className="px-1 py-2 text-left text-sm">{item.quantity}</td>
          <td className="px-1 py-2 text-left text-sm">{item.case_quantity}</td>
          <td className="px-1 py-2 text-left text-sm">{item.gstPercentage + "%"}</td>
          <td className="px-5 py-2 text-right text-sm">₹{item.mrpPerUnit.toFixed(2)}</td>
          <td className="px-5 py-2 text-right text-sm">₹{item.ratePerUnit.toFixed(2)}</td>
          <td className="px-2 py-2 text-right text-sm">₹{item.totalAmount.toFixed(2)}</td>
        </tr>

        {index === 6 && isGeneratingPdf && (
          <tr>
            <td colSpan="9">
              <div className="my-12" />
            </td>
          </tr>
        )}
      </React.Fragment>
    );
  })}
</tbody>

    <tfoot>
  <tr className="bg-gray-50 font-semibold">
    <td colSpan={3} className="px-4 py-2 text-right">Total Quantity:</td>
    <td className="px-1 py-2 text-left text-sm font-semibold">
      {data.items.reduce((sum, item) => sum + item.quantity, 0)}
    </td>
    <td className="px-1 py-2 text-left text-sm font-semibold">
      {data.items.reduce((sum, item) => sum + item.case_quantity, 0)}
    </td>
    <td colSpan={3} className="px-4 py-2 text-right">Subtotal:</td>
    <td className="px-4 py-2 text-right">₹{data.totals.subtotal}</td>
  </tr>

  {parseFloat(data.totals.totalIgst) > 0 && (
    <tr>
      <td colSpan={8} className="px-4 py-2 text-right">IGST:</td>
      <td className="px-4 py-2 text-right">₹{parseFloat(data.totals.totalIgst).toFixed(2)}</td>
    </tr>
  )}

  {parseFloat(data.totals.totalCgst) > 0 && (
    <tr>
      <td colSpan={8} className="px-4 py-2 text-right">CGST:</td>
      <td className="px-4 py-2 text-right">₹{parseFloat(data.totals.totalCgst).toFixed(2)}</td>
    </tr>
  )}

  {parseFloat(data.totals.totalSgst) > 0 && (
    <tr>
      <td colSpan={8} className="px-4 py-2 text-right">SGST:</td>
      <td className="px-4 py-2 text-right">₹{parseFloat(data.totals.totalSgst).toFixed(2)}</td>
    </tr>
  )}

  <tr className="bg-gray-50 font-semibold">
    <td colSpan={8} className="px-4 py-2 text-right">Total GST:</td>
    <td className="px-4 py-2 text-right">₹{(
      parseFloat(data.totals.totalIgst) +
      parseFloat(data.totals.totalCgst) +
      parseFloat(data.totals.totalSgst)
    ).toFixed(2)}</td>
  </tr>

  <tr className="bg-gray-100 font-bold">
    <td colSpan={8} className="px-4 py-2 text-right">Grand Total:</td>
    <td className="px-4 py-2 text-right">₹{data.totals.grandTotal}</td>
  </tr>
</tfoot>



  </table>
</div>


        <div className="mt-8 overflow-x-auto">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Tax Summary</h3>
          <table className="w-full border-collapse border border-gray-200">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-4 py-2 text-left text-sm font-semibold text-gray-600">HSN Code</th>
                <th className="px-4 py-2 text-right text-sm font-semibold text-gray-600">Taxable Value</th>
                <th className="px-4 py-2 text-right text-sm font-semibold text-gray-600">Rate</th>
                <th className="px-4 py-2 text-right text-sm font-semibold text-gray-600">IGST (Rs)</th>
                <th className="px-4 py-2 text-right text-sm font-semibold text-gray-600">CGST (Rs)</th>
                <th className="px-4 py-2 text-right text-sm font-semibold text-gray-600">SGST (Rs)</th>
                <th className="px-4 py-2 text-right text-sm font-semibold text-gray-600">Total (Rs)</th>
                
              </tr>
            </thead>
            <tbody>
              {data.gstDetails.map((gst, index) => (
                <tr key={index} className="border-b">
                  <td className="px-4 py-2 text-sm">{gst.HsnCd}</td>
                  <td className="px-4 py-2 text-sm text-right">₹{gst.TotalTaxableAmount.toFixed(2)}</td>
                  <td className="px-4 py-2 text-sm text-right">{gst.GstPercentage}%</td>
                  <td className="px-4 py-2 text-sm text-right">₹{gst.TotalIgstAmt.toFixed(2)}</td>
                  <td className="px-4 py-2 text-sm text-right">₹{gst.TotalCgstAmt.toFixed(2)}</td>
                  <td className="px-4 py-2 text-sm text-right">₹{gst.TotalSgstAmt.toFixed(2)}</td>
                  <td className="px-4 py-2 text-sm text-right">₹{gst.TotalAmount.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
  <tr className="bg-gray-50 font-semibold">
    <td className="px-4 py-2 text-sm font-bold">Total</td>
    <td className="px-4 py-2 text-sm text-right font-semibold">₹{data.totals.subtotal}</td>
    <td className="px-4 py-2 text-sm text-right"></td>
    <td className="px-4 py-2 text-sm text-right font-semibold">₹{data.totals.totalIgst}</td>
    <td className="px-4 py-2 text-sm text-right font-semibold">₹{data.totals.totalCgst}</td>
    <td className="px-4 py-2 text-sm text-right font-semibold">₹{data.totals.totalSgst}</td>
    <td className="px-4 py-2 text-sm text-right font-semibold">₹{data.totals.grandTotal}</td>
  </tr>
  <tr className="bg-gray-100 font-bold">
    <td colSpan={6} className="px-4 py-2 text-right">Grand Total:</td>
    <td className="px-4 py-2 text-right">₹{data.totals.grandTotal}</td>
  </tr>
</tfoot>
          </table>
        </div>

        {/* IRN Section */}
        <div className="mt-8 flex justify-between items-start border-t pt-6">
          <div>
            <h3 className="font-semibold text-gray-800 mb-2">IRN Details</h3>
            <p className="text-sm text-gray-600">IRN: {data.irn.number}</p>
            <p className="text-sm text-gray-600">Ack No: {data.irn.acknowledgementNo}</p>
            <p className="text-sm text-gray-600">Ack Date: {data.irn.acknowledgementDate}</p>
          </div>
          <div className="qr-code">
            {data.irn.qrCode ? (
              <QRCode value={data.irn.qrCode} size={150} />
            ) : (
              <div className="h-24 w-24 flex items-center justify-center bg-gray-200">
                <p className="text-gray-500 text-xs">No QR Code</p>
              </div>
            )}
          </div>
        </div>

                {/* Payment Information Section */}
                {data.paymentInfo && (
          <div className="mt-8 border-t pt-6">
            <h3 className="font-semibold text-gray-800 mb-2">Payment Information</h3>
            <p className="text-sm text-gray-600">Account Name: <span className="font-medium">Sleepy Owl Coffee Private Limited</span></p>
            <p className="text-sm text-gray-600">Account No: <span className="font-medium">6547832913</span></p>
            <p className="text-sm text-gray-600">IFSC: <span className="font-medium">KKBK0004591</span></p>
            <p className="text-sm text-gray-600">Bank Name: <span className="font-medium">Kotak Mahindra Bank</span></p>
            <p className="text-sm text-gray-600">Branch: <span className="font-medium">Hauz Khas</span></p>
          </div>
        )}


        <div className="mt-8 text-center border-t pt-6 relative">
  <p className="text-md text-gray-800">Thank you for your business!</p>
  <p className="text-sm text-gray-600 mt-2">This is a computer-generated invoice.</p>
  
  {/* Ensure proper alignment for "Powered by" section */}
  <div className="mt-2 flex justify-center items-center space-x-2">
    <span className="text-sm text-gray-600">Powered by</span>
    <img 
      src="/logo.svg" 
      alt="Powered by filflo" 
      className="h-6 w-auto" 
    />
  </div>

  <p className="text-sm text-gray-600 mt-2">No signature is required.</p>
</div>

        {/* PDF Download Button */}
        <div className="mt-8 text-center">
          <button
            ref={printButtonRef}
            onClick={handleDownloadPdf}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg shadow"
          >
            Download Invoice as PDF
          </button>
        </div>
      </div>
  );
};

export default Invoice;
