'use client';
import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import moment from 'moment';
import { creditNoteService } from '@/app/services/creditNoteService';
import searchNested from '@/app/utils/searchUtils';
import { filterByDate } from '../InvoiceDateFilter/InvoiceDateFilter';
import TableFilterBarWithDatePicker from '../TableFilterBarWithDatePicker/TableFilterBarWithDatePicker';
import StatusComponent from "../StatusComponent/StatusComponent";
import DynamicTableWithoutAction from '../DynamicTableWithoutAction/DynamicTableWithoutAction';
import BigRightSidebar from '../BigRightSidebar/BigRightSidebar';
import {
  stickyActionColumnClassname,
  stickyActionRowClassname,
} from "@/app/utils/stickyActionClassname";
import ActionDropdown from '../ActionDropdown/ActionDropdown';
import ViewCreditNoteParticular from '../ViewCreditNoteParticular/ViewCreditNoteParticular';

const CreditNotesTable = () => {
  const [creditNotes, setCreditNotes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState({
    total: 0,
    page: 1,
    limit: 50,
    totalPages: 0
  });
  const [filter, setFilter] = useState("allCreditNotes");
  const [searchText, setSearchText] = useState("");
  const [dayFilter, setDayFilter] = useState("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarType, setSidebarType] = useState(null);
  const [selectedCreditNote, setSelectedCreditNote] = useState(null);
  const [selectedCreditNotes, setSelectedCreditNotes] = useState([]);

  const fetchCreditNotes = async () => {
    try {
      setLoading(true);
      const response = await creditNoteService.getAllCreditNotes({
        page: pagination.page,
        limit: pagination.limit,
        searchText,
        filter,
        dayFilter,
        startDate: startDate ? moment(startDate).format('YYYY-MM-DD') : '',
        endDate: endDate ? moment(endDate).format('YYYY-MM-DD') : ''
      });

      if (response.success) {
        setCreditNotes(response.data);
        setPagination(prev => ({
          ...prev,
          total: response.pagination.total,
          totalPages: response.pagination.totalPages
        }));
      }
    } catch (error) {
      console.error('Error fetching credit notes:', error);
      setCreditNotes([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCreditNotes();
  }, [pagination.page, pagination.limit, filter, searchText, dayFilter, startDate, endDate]);

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleSearchChange = (newSearchText) => {
    setSearchText(newSearchText);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleDayFilterChange = (event) => {
    setDayFilter(event.target.value);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const convertToCSV = (data, selectedCreditNotes) => {
    const headers = [
      'Credit Note ID', 'Original Invoice ID', 'Customer Name', 'Credit Note Date', 
      'Reason', 'Total Amount', 'Total Tax Amount', 'IRN Number', 'IRN Status',
      'Created By', 'Created At', 'Number of Products', 'GST Details'
    ];

    const escapeCSVValue = (value) => {
      if (value === undefined || value === null) return '';
      const stringValue = String(value);
      return `"${stringValue.replace(/"/g, '""')}"`;
    };

    const formatDateTime = (dateString) => {
      if (!dateString) return '';
      const parsedDate = moment(dateString);
      return parsedDate.isValid() ? parsedDate.format("DD MMM YYYY HH:mm:ss") : 'Invalid Date';
    };

    const filteredData = selectedCreditNotes.length > 0
      ? data.filter((note) => selectedCreditNotes.includes(note._id))
      : data;

    const rows = filteredData.map((note) => [
      escapeCSVValue(note.creditNoteId),
      escapeCSVValue(note.originalInvoiceId),
      escapeCSVValue(note.customerID?.name),
      escapeCSVValue(formatDateTime(note.creditNoteDate)),
      escapeCSVValue(note.reason),
      escapeCSVValue(note.totalAmount),
      escapeCSVValue(note.totalTaxAmount),
      escapeCSVValue(note.irnDetails?.irn),
      escapeCSVValue(note.irnDetails?.status),
      escapeCSVValue(note.created_by?.name),
      escapeCSVValue(formatDateTime(note.createdAt)),
      escapeCSVValue(note.listOfProducts?.length),
      escapeCSVValue(JSON.stringify(note.gstDetails))
    ].join(','));

    const csvString = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'credit-notes.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const convertToCSVProductWise = (data, selectedCreditNotes) => {
    const headers = [
      'Credit Note ID', 'Original Invoice ID', 'Customer Name', 'Credit Note Date',
      'SKU Code', 'Product Name', 'Quantity', 'Price Per Unit', 'HSN Code',
      'Tax Slab', 'Total Amount', 'Total Tax Amount', 'IRN Number'
    ];

    const escapeCSVValue = (value) => {
      if (value === undefined || value === null) return '';
      const stringValue = String(value);
      return `"${stringValue.replace(/"/g, '""')}"`;
    };

    const formatDateTime = (dateString) => {
      if (!dateString) return '';
      const parsedDate = moment(dateString);
      return parsedDate.isValid() ? parsedDate.format("DD MMM YYYY HH:mm:ss") : 'Invalid Date';
    };

    const filteredData = selectedCreditNotes.length > 0
      ? data.filter(note => selectedCreditNotes.includes(note._id))
      : data;

    const rows = filteredData.flatMap(note => {
      return note.listOfProducts.map(product => [
        escapeCSVValue(note.creditNoteId),
        escapeCSVValue(note.originalInvoiceId),
        escapeCSVValue(note.customerID?.name),
        escapeCSVValue(formatDateTime(note.creditNoteDate)),
        escapeCSVValue(product.skuCode),
        escapeCSVValue(product.productName),
        escapeCSVValue(product.quantity),
        escapeCSVValue(product.ppu),
        escapeCSVValue(product.hsnCode),
        escapeCSVValue(product.taxSlab),
        escapeCSVValue(note.totalAmount),
        escapeCSVValue(note.totalTaxAmount),
        escapeCSVValue(note.irnDetails?.irn)
      ].join(','));
    });

    const csvString = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'credit-notes-product-wise.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const searchKeys = [
    "creditNoteId",
    "originalInvoiceId",
    "customerID",
    "reason"
  ];

  const headings = {
    checkbox: {
      label: "Select",
      isCheckbox: true,
      onChange: (row) => handleCheckboxChange(row._id),
      isSticky: false,
    },
    creditNoteId: {
      label: "Credit Note ID",
      renderCell: (row) => row?.creditNoteId || "N/A",
      isSticky: false,
    },
    originalInvoiceId: {
      label: "Original Invoice ID",
      renderCell: (row) => row?.originalInvoiceId || "N/A",
      isSticky: false,
    },
    customerName: {
      label: "Customer Name",
      renderCell: (row) => row?.customerID?.name || "N/A",
      isSticky: false,
    },
    creditNoteDate: {
      label: "Credit Note Date",
      renderCell: (row) => moment(row?.creditNoteDate).format('DD MMM YYYY') || "N/A",
      isSticky: false,
    },
    reason: {
      label: "Reason",
      renderCell: (row) => row?.reason || "N/A",
      isSticky: false,
    },
    totalAmount: {
      label: "Total Amount",
      renderCell: (row) => row?.totalAmount?.toFixed(2) || "N/A",
      isSticky: false,
    },
    distinctProducts: {
      label: "Products Count",
      renderCell: (row) => row?.listOfProducts?.length || "N/A",
      isSticky: false,
    },
    irnStatus: {
      label: "IRN Status",
      renderCell: (row) => row?.irnDetails?.status || "N/A",
      isSticky: false,
    },
    action: {
      label: "Action",
      renderCell: (row) => (
        <ActionDropdown order={row} actions={generateCreditNoteActions(row)} />
      ),
      isSticky: true,
      stickyClassHeader: stickyActionColumnClassname,
      stickyClassRow: stickyActionRowClassname,
    },
  };

  const generateCreditNoteActions = (creditNote) => {
    return [
      {
        label: "View Credit Note Details",
        condition: () => true,
        action: () => openSidebar("viewCreditNoteParticular", creditNote),
      },
    ];
  };

  const openSidebar = (type, creditNote) => {
    setSidebarType(type);
    setSelectedCreditNote(creditNote);
    setIsSidebarOpen(true);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
    setSidebarType(null);
    setSelectedCreditNote(null);
  };

  const filterOptions = [
    { value: "allCreditNotes", label: "All Credit Notes" },
    { value: "lastWeek", label: "Last Week" },
    { value: "lastMonth", label: "Last Month" },
    { value: "lastQuarter", label: "Last Quarter" }
  ];

  const handleCheckboxChange = (creditNoteId) => {
    setSelectedCreditNotes((prevSelected) =>
      prevSelected.includes(creditNoteId)
        ? prevSelected.filter((id) => id !== creditNoteId)
        : [...prevSelected, creditNoteId]
    );
  };

  const handleDownload = async () => {
    try {
      setLoading(true);
      const response = await b2bOrderService.getAllCreditNotesForDownload({
        searchText,
        filter,
        dayFilter,
        startDate: startDate ? moment(startDate).format('YYYY-MM-DD') : '',
        endDate: endDate ? moment(endDate).format('YYYY-MM-DD') : ''
      });

      if (response.success) {
        const dataToDownload = selectedCreditNotes.length > 0
          ? response.data.filter(note => selectedCreditNotes.includes(note._id))
          : response.data;
        
        convertToCSV(dataToDownload, selectedCreditNotes);
      }
    } catch (error) {
      console.error('Error downloading credit notes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadProductWise = async () => {
    try {
      setLoading(true);
      const response = await b2bOrderService.getAllCreditNotesForDownload({
        searchText,
        filter,
        dayFilter,
        startDate: startDate ? moment(startDate).format('YYYY-MM-DD') : '',
        endDate: endDate ? moment(endDate).format('YYYY-MM-DD') : ''
      });

      if (response.success) {
        const dataToDownload = selectedCreditNotes.length > 0
          ? response.data.filter(note => selectedCreditNotes.includes(note._id))
          : response.data;
        
        convertToCSVProductWise(dataToDownload, selectedCreditNotes);
      }
    } catch (error) {
      console.error('Error downloading product-wise credit notes:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* <TableFilterBarWithDatePicker
        filter={filter}
        setFilter={handleFilterChange}
        searchText={searchText}
        setSearchText={handleSearchChange}
        convertToCSV={handleDownload}
        convertToCSVSkuWise={handleDownloadProductWise}
        allPO={creditNotes}
        selectedRows={selectedCreditNotes}
        filterOptions={filterOptions}
        dayFilter={dayFilter}
        handleDayFilterChange={handleDayFilterChange}
        startDate={startDate}
        setStartDate={(date) => {
          setStartDate(date);
          setPagination(prev => ({ ...prev, page: 1 }));
        }}
        endDate={endDate}
        setEndDate={(date) => {
          setEndDate(date);
          setPagination(prev => ({ ...prev, page: 1 }));
        }}
        isLoading={loading}
      /> */}

      {loading ? (
        <div className="flex justify-center items-center p-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
        </div>
      ) : (
        <DynamicTableWithoutAction 
          headings={headings} 
          rows={creditNotes}
          pagination={{
            ...pagination,
            onPageChange: (newPage) => setPagination(prev => ({ ...prev, page: newPage })),
            onLimitChange: (newLimit) => setPagination(prev => ({ ...prev, limit: newLimit, page: 1 }))
          }}
        />
      )}

      {sidebarType === "viewCreditNoteParticular" && (
        <BigRightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
          <ViewCreditNoteParticular
            selectedCreditNote={selectedCreditNote}
            handleCancel={closeSidebar}
          />
        </BigRightSidebar>
      )}
    </>
  );
};

export default CreditNotesTable;
