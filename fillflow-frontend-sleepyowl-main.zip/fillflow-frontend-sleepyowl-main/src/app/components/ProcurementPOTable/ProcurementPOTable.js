"use client";
import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useRouter } from "next/navigation";
import moment from "moment";
import StatusComponent from "../StatusComponent/StatusComponent";
import DynamicTableWithoutAction from '@/app/components/DynamicTableWithoutAction/DynamicTableWithoutAction';
import TableFilterBar from "../TableFilterBar/TableFilterBar";
import { filterByDate } from '@/app/components/DateFilter/DateFilter';
import searchNested from '@/app/utils/searchUtils';
import {
  stickyActionColumnClassname,
  stickyActionRowClassname,
} from "@/app/utils/stickyActionClassname";
import ActionDropdown from '../ActionDropdown/ActionDropdown';
import RightSidebar from "../RightSidebar/RightSidebar";
import BigRightSidebar from "../BigRightSidebar/BigRightSidebar";
import ViewPOParticular from "../ViewPOParticular/ViewPOParticular";
import EnterInwardProcurementPOInfo from "../EnterInwardProcurementPOInfo/EnterInwardProcurementPOInfo";
const ProcurementPOTable = () => {
  const { allPOs } = useSelector((state) => state.procurementPO);
  const [filter, setFilter] = useState("all");
  const [dayFilter, setDayFilter] = useState("all");
  const [searchText, setSearchText] = useState("");
  const [filteredData, setFilteredData] = useState([]);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [sidebarType, setSidebarType] = useState(null);
    const [selectedPO, setSelectedPO] = useState(null);

  const router = useRouter();

  const statusOptions = [
    { value: "all", label: "All" },
    { value: "pending", label: "Pending" },
    { value: "partially_fulfilled", label: "Partially Fulfilled" },
    { value: "fulfilled", label: "Fulfilled" },
    { value: "cancelled", label: "Cancelled" },
  ];

  const searchKeys = ["po_number", "supplier_id", "status"];

  const applyFilters = () => {
    let data = [...allPOs];

    data = filterByDate(data, dayFilter, null, null, "order_date");

    if (filter !== "all") {
      data = data.filter((po) => po.status === filter);
    }

    if (searchText.trim() !== "") {
      data = data.filter((po) =>
        searchKeys.some((key) =>
          searchNested(po[key], searchText.toLowerCase(), key)
        )
      );
    }

    setFilteredData(data);
  };

  useEffect(() => {
    applyFilters();
  }, [filter, allPOs, searchText, dayFilter]);

  const convertToCSV = (data) => {
    const headers = [
      "PO Number",
      "Supplier Name",
      "Total Ordered Items",
      "Status",
      "Order Date",
    ];

    const escapeValue = (value) => {
      if (value) {
        let escaped = String(value);
        if (escaped.includes(",") || escaped.includes('"')) {
          escaped = `"${escaped.replace(/"/g, '""')}"`;
        }
        return escaped;
      }
      return "N/A";
    };

    const rows = data.map((po) => [
      escapeValue(po.po_number),
      escapeValue(po?.supplier_id?.name),
      escapeValue(po.items?.length || 0),
      escapeValue(po.status),
      escapeValue(moment(po.order_date).format("DD MMM YYYY")),
    ]);

    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers.join(","), ...rows.map((row) => row.join(","))].join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Procurement_PO_List_${moment().format("DD-MMM-YYYY")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const headings = {
    po_number: {
      label: "PO Number",
      renderCell: (row) => row?.po_number || "N/A",
      isSticky: false,
    },
    supplier_name: {
      label: "Supplier",
      renderCell: (row) => row?.supplier_id?.name || "N/A",
      isSticky: false,
    },
    status: {
      label: "Status",
      renderCell: (row) => <StatusComponent status={row?.status} /> || "N/A",
      isSticky: false,
    },
    order_date: {
      label: "Order Date",
      renderCell: (row) => moment(row?.order_date).format("DD MMM YYYY"),
      isSticky: false,
    },
    item_count: {
      label: "Items",
      renderCell: (row) => row?.items?.length || 0,
      isSticky: false,
    },


    action: {
      label: "Action",
      renderCell: (row) => (
        <ActionDropdown order={row} actions={generatePOActions(row)} />
      ),
      isSticky: true,
      stickyClassHeader: stickyActionColumnClassname,
      stickyClassRow: stickyActionRowClassname,
    },
  };


  const generatePOActions = (po) => {
    return [
      {
        label: "View PO Particulars",
        condition: () => true,
        action: () => openSidebar("viewPOParticular", po),
      },
      {
        label: "Enter Inward Info",
        condition: () => po.status !== "fulfilled" && po.status !== "cancelled",
        action: () => openSidebar("enterInwardInfo", po),
      },
      {
        label: "Cancel PO",
        condition: () => po.status === "pending",
        action: () => openSidebar("cancelPO", po),
      },
    ].filter(action => action.condition()); // Only return applicable actions
  };



  const openSidebar = (type, po) => {
    setSidebarType(type);
    setSelectedPO(po);
    setIsSidebarOpen(true);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
    setSidebarType(null);
    setSelectedPO(null);
  };
  

  return (
    <>
      <TableFilterBar
        filter={filter}
        setFilter={setFilter}
        searchText={searchText}
        setSearchText={setSearchText}
        convertToCSV={convertToCSV}
        allPO={allPOs}
        filterOptions={statusOptions}
        dayFilter={dayFilter}
        setDayFilter={setDayFilter}
      />

      <DynamicTableWithoutAction headings={headings} rows={filteredData} />

      {sidebarType === "viewPOParticular" ? (
  <BigRightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
    <ViewPOParticular
      selectedPO={selectedPO}
      handleCancel={closeSidebar}
    />
  </BigRightSidebar>
) : (
  <RightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
    {sidebarType === "enterInwardInfo" && (
      <EnterInwardProcurementPOInfo selectedPO={selectedPO} handleCancel={closeSidebar} />
    )}
    {sidebarType === "cancelPO" && (
      <CancelPO selectedPO={selectedPO} handleCancel={closeSidebar} />
    )}
  </RightSidebar>
)}

    </>
  );
};

export default ProcurementPOTable;
