'use client';
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import B2BCustomerDropdown from "../B2BCustomerDropdown/B2BCustomerDropdown";
import CategoryDropdown from "../CategoryDropdown/CategoryDropdown";
import ProductDropdown from "../ProductDropdown/ProductDropdown";
import Button from "../Button/Button";
import Input from "../Input/Input";
import {
  getAllB2BCustomerRequest,
  getAllB2BCustomerSuccess,
  getAllB2BCustomerFailure,
} from "../../Actions/b2bCustomerActions";
import {
  getAllProductByCatIdRequest,
  getAllProductByCatIdSuccess,
  getAllProductByCatIdFailure,
} from "../../Actions/productActions";
import {
  getAllCategorySuccess,
  getAllCategoryRequest,
  getAllCategoryFailure,
} from "../../Actions/categoryActions";
import { b2bCustomerService } from "@/app/services/b2bCustomerService";
import { productServices } from "@/app/services/productService";
import { categoryServices } from "@/app/services/categoryService";
import { sfgCategories } from "@/app/constants/categoryConstants";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const EditB2BCustomerForm = () => {
  const dispatch = useDispatch();
  const { b2bCustomers } = useSelector((state) => state.b2bCustomer);
  const { dropDownB2BCustomerValue } = useSelector((state) => state.dropdown);
  const { allCategories, selectedCatId } = useSelector((state) => state.category);
  const { allProductsByCatId } = useSelector((state) => state.product);
  const { dropDownProductValue, dropdownProductName } = useSelector((state) => state.dropdown);
  const [ loading, setLoading ] = useState(false);

  const [formDisabled, setFormDisabled] = useState(false);
  const [formData, setFormData] = useState({
    customerId: "",
    customerName: "",
    customerPhoneNumber: "",
    customerBillingAddress: "",
    customerShippingAddress: "",
    customerGSTNumber: "",
    listOfProducts: [],
  });
  const [productPrice, setProductPrice] = useState(null);
  const [errors, setErrors] = useState({});
  const [isDataLoaded, setIsDataLoaded] = useState(false);

  useEffect(() => {
    const getAllB2BCustomers = async () => {
      try {
        dispatch(getAllB2BCustomerRequest());
        const response = await b2bCustomerService.getAllB2BCustomers();
        if (response.success) {
          dispatch(getAllB2BCustomerSuccess(response.data));
        } else {
          toast.error("Failed to fetch customers");
        }
      } catch (err) {
        console.error(err);
        dispatch(getAllB2BCustomerFailure());
        toast.error("An error occurred while fetching customers");
      }
    };

    getAllB2BCustomers();
  }, [dispatch]);

  useEffect(() => {
    const getAllCategories = async () => {
      try {
        dispatch(getAllCategoryRequest());
        const response = await categoryServices.getAllCategories();
        const fgCategories = response.data.filter(
          (category) => !sfgCategories.includes(category.category_name)
        );
        if (response.success) {
          dispatch(getAllCategorySuccess(fgCategories));
        }
      } catch (err) {
        console.error(err);
        dispatch(getAllCategoryFailure());
      }
    };

    getAllCategories();
  }, [dispatch]);

  useEffect(() => {
    const getProductByCatId = async () => {
      try {
        dispatch(getAllProductByCatIdRequest());
        const response = await productServices.getAllProductsByCatId(selectedCatId);
        if (response.success) {
          dispatch(getAllProductByCatIdSuccess(response.data));
        }
      } catch (err) {
        console.error(err);
        dispatch(getAllProductByCatIdFailure());
      }
    };

    if (selectedCatId) {
      getProductByCatId();
    }
  }, [selectedCatId, dispatch]);

  const handleEditCustomer = async () => {
    if (!dropDownB2BCustomerValue) {
      return;
    }
  
    try {
      const response = await b2bCustomerService.getB2BCustomerDetailsById(dropDownB2BCustomerValue);
  
      if (response.success) {
        const { _id, customerId, name, phone, billing_address, shipping_address, gstNumber, products } = response.data;
  
        setFormData({
          customerInternalId: _id || "",
          customerId: customerId || "",
          customerName: name || "",
          customerPhoneNumber: phone || "",
          customerBillingAddress: billing_address || "",
          customerShippingAddress: shipping_address || "",
          customerGSTNumber: gstNumber || "",
          listOfProducts: products || [], // Populate existing products
        });
  
        setIsDataLoaded(true);
      } else {
        console.error("Failed to fetch customer details");
      }
    } catch (err) {
      console.error(err);
    }
  };
  

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handleRemoveProductsFromList = (index) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      listOfProducts: prevFormData.listOfProducts.filter((_, i) => i !== index),
    }));
  };

  const handleAddProduct = () => {
    if (!dropDownProductValue || !productPrice) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        listOfProducts: "Please select a product and enter price per unit.",
      }));
      return;
    }

    console.log("🚀 ~ handleAddProduct ~ listOfProducts:", formData.listOfProducts)
  
    // Check if the product is already in the list
    const isProductAlreadyAdded = formData.listOfProducts.some(
      (product) => product.productId === dropDownProductValue
    );
   
  
    if (isProductAlreadyAdded) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        listOfProducts: "This product is already associated to the B2B Customer",
      }));
      return;
    }
  
    const newProduct = {
      productId: dropDownProductValue,
      productName: dropdownProductName,
      price: productPrice,
    };
  
    setFormData((prevFormData) => ({
      ...prevFormData,
      listOfProducts: [...prevFormData.listOfProducts, newProduct],
    }));
  
    // Reset input field and error
    setProductPrice("");
    setErrors((prevErrors) => ({
      ...prevErrors,
      listOfProducts: "",
    }));
  };
  


  const onFormSubmit = async () => {
    try {
      const response = await b2bCustomerService.updateB2BCustomerById(formData);
      setLoading(false);
      if (response && response.success) {
        toast.success('B2B Customer Updated Successfully', {
          autoClose: 1500,
          onClose: () => window.location.reload(),
        });
        setFormDisabled(true);
      } else {
        toast.error('Failed to update customer: ' + (response?.message || 'Unknown error'), {
          autoClose: 5000,
          onClose: () => window.location.reload(),
        });
        setFormDisabled(true);
      }
    } catch (err) {
      toast.error('Failed to update customer: ' + err, { autoClose: 3000 });
      window.location.reload();
    }
  };

  return (
    <div className="h-[78vh] min-h-[78vh] max-h-[78vh] overflow-y-scroll">
      <ToastContainer />

      <h2 className="text-base font-semibold text-[#111928] mb-1">
          Edit B2B Customer
        </h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
        Select a customer to edit their details
        </p>
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">Select Customer <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
        <B2BCustomerDropdown
          id="customerDropdown"
          bgColor={"#F8F6F2"}
          options={b2bCustomers}
        />
        {!dropDownB2BCustomerValue && (
          <p className="text-red-500 text-xs">Please select a customer</p>
        )}
      </div>

      <div onClick={handleEditCustomer} className="mt-2">
        <Button
          title={"Edit Customer"}
          bgColor={"bg-[rgb(79,201,218)]"}
          radius={"rounded-lg"}
          height={"h-[3vw] min-h-[3vh]"}
          padding={"p-[1vw]"}
          color={"text-[#ffff]"}
          textSize={"text-[1vw]"}
          fontWeight={"font-medium"}
          width={"w-[10vw]"}
        />
      </div>

      {isDataLoaded && (
        <div className="h-[55vh] min-h-[55vh] max-h-[55vh] overflow-y-scroll">
        <div className="flex flex-col mt-3">
            <ToastContainer />
        </div>

        <div className="flex flex-col mb-3">
            <label className="block text-[#111928] text-sm font-medium mb-1">Customer Id</label>
            <Input
                bgColor="bg-[#F8F6F2]"
                radius="rounded-lg"
                height="h-[3.5vw] min-h-[3.5vh]"
                padding="p-[1vw]"
                type="text"
                color="text-[#838481]"
                textSize="text-[1vw]"
                fontWeight="font-medium"
                name="customerName"
                value={formData.customerId}
                onChange={handleChange}
            />
        </div>

        <div className="flex flex-col mb-3">
            <label className="block text-[#111928] text-sm font-medium mb-1">Customer Name</label>
            <Input
                bgColor="bg-[#F8F6F2]"
                radius="rounded-lg"
                height="h-[3.5vw] min-h-[3.5vh]"
                padding="p-[1vw]"
                type="text"
                color="text-[#838481]"
                textSize="text-[1vw]"
                fontWeight="font-medium"
                name="customerName"
                value={formData.customerName}
                onChange={handleChange}
            />
        </div>

        <div className="flex flex-col mb-3">
            <label className="block text-[#111928] text-sm font-medium mb-1">Customer Phone Number</label>
            <Input
                bgColor="bg-[#F8F6F2]"
                radius="rounded-lg"
                height="h-[3.5vw] min-h-[3.5vh]"
                padding="p-[1vw]"
                type="text"
                color="text-[#838481]"
                textSize="text-[1vw]"
                fontWeight="font-medium"
                name="customerPhoneNumber"
                value={formData.customerPhoneNumber}
                onChange={handleChange}
            />
         
        </div>

        <div className="flex flex-col mb-3">
            <label className="block text-[#111928] text-sm font-medium mb-1">Customer Billing Address</label>
            <Input
                bgColor="bg-[#F8F6F2]"
                radius="rounded-lg"
                height="h-[3.5vw] min-h-[3.5vh]"
                padding="p-[1vw]"
                type="text"
                color="text-[#838481]"
                textSize="text-[1vw]"
                fontWeight="font-medium"
                name="customerBillingAddress"
                value={formData.customerBillingAddress}
                onChange={handleChange}
            />
            
        </div>

        <div className="flex flex-col mb-3">
            <label className="block text-[#111928] text-sm font-medium mb-1">Customer Shipping Address</label>
            <Input
                bgColor="bg-[#F8F6F2]"
                radius="rounded-lg"
                height="h-[3.5vw] min-h-[3.5vh]"
                padding="p-[1vw]"
                type="text"
                color="text-[#838481]"
                textSize="text-[1vw]"
                fontWeight="font-medium"
                name="customerShippingAddress"
                value={formData.customerShippingAddress}
                onChange={handleChange}
            />
          
        </div>

        <div className="flex flex-col mb-3">
            <label className="block text-[#111928] text-sm font-medium mb-1">Customer GST Number</label>
            <Input
                bgColor="bg-[#F8F6F2]"
                radius="rounded-lg"
                height="h-[3.5vw] min-h-[3.5vh]"
                padding="p-[1vw]"
                type="text"
                color="text-[#838481]"
                textSize="text-[1vw]"
                fontWeight="font-medium"
                name="customerGSTNumber"
                value={formData.customerGSTNumber}
                onChange={handleChange}
            />
           
        </div>

        <label className="block text-[#111928] text-sm font-medium mb-1">List Of Products</label>
        <div className="flex flex-col  mb-3p-4 border-2 border-[#F8F6F2] rounded-lg bg-white">
            <div className="flex flex-col mb-3">
                <label className="block text-[#111928] text-sm font-medium mb-1">Select Category</label>
                <CategoryDropdown bgColor="#F8F6F2" options={allCategories} />
            </div>
            <div className="flex flex-col mb-3">
                <label className="block text-[#111928] text-sm font-medium mb-1">Select Product</label>
                <ProductDropdown
                    name="product_id"
                    bgColor="#F8F6F2"
                    options={allProductsByCatId}
                />
            </div>
            <div className="flex flex-col mb-3">
  <label>Price Per Unit</label>
  <Input
    bgColor="bg-[#F8F6F2]"
    radius="rounded-lg"
    height="h-[3.5vw] min-h-[3.5vh]"
    padding="p-[1vw]"
    type="number"
    color="text-[#838481]"
    textSize="text-[1vw]"
    fontWeight="font-medium"
    name="price"
    placeholder="Enter Price per unit here"
    value={productPrice}
    onChange={(e) => setProductPrice(e.target.value)}
  />
  {errors.listOfProducts && (
    <p className="text-red-500 text-xs mt-1">{errors.listOfProducts}</p>
  )}
</div>


            <div onClick={handleAddProduct} className="mt-2">
                <Button
                    title="Add Product"
                    bgColor="bg-[rgb(79,201,218)]"
                    radius="rounded-lg"
                    height="h-[3vw] min-h-[3vh]"
                    padding="p-[1vw]"
                    color="text-[#ffff]"
                    textSize="text-[1vw]"
                    fontWeight="font-medium"
                    width="w-[10vw]"
                />
            </div>

            <div className="mt-2">
  {formData.listOfProducts.length > 0 && <label>Products:</label>}
  <ul className="flex flex-col gap-4">
    {formData.listOfProducts.map((product, index) => (
      <li
        key={index}
        className="awb-number border bg-[#F8F6F2] text-black rounded-lg p-2 text-sm text-start"
      >
        <div className="flex">
          {/* Product details container takes 80% of space */}
          <div className="flex-grow text-left w-[80%]">
            <span className="font-semibold">Product Name:</span> {product.productName || "Unknown"}
            <br />
            <span className="font-semibold">Price Per Unit:</span> ₹{product.price}
          </div>
          {/* Remove button stays on the right */}
          <button
            onClick={() => handleRemoveProductsFromList(index)}
            className="bg-red-500 text-white px-2 py-1 rounded-lg"
          >
            Remove
          </button>
        </div>
      </li>
    ))}
  </ul>
</div>



        </div>

        <div className="flex flex-row gap-5">
            <div className="mt-2" onClick={onFormSubmit}>
                <Button
                    title="Update Customer"
                    bgColor="bg-[rgb(79,201,218)]"
                    radius="rounded-lg"
                    height="h-[3vw] min-h-[3vh]"
                    padding="p-[1vw]"
                    color="text-[#ffff]"
                    textSize="text-[1vw]"
                    fontWeight="font-medium"
                    width="w-[14vw]"
                    disabled={loading}
                />
            </div>
        </div>

        {formDisabled && (
            <div className="fixed top-0 left-0 w-full h-full bg-gray-400 opacity-50 z-50" />
        )}
    </div>
      )}
    </div>
  );
};

export default EditB2BCustomerForm;


