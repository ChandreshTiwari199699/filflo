'use client';
import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import moment from 'moment';
import { b2bOrderService } from '@/app/services/b2bOrderService';
import searchNested from '@/app/utils/searchUtils';
import { filterByDate } from '../InvoiceDateFilter/InvoiceDateFilter';
import TableFilterBarWithDatePicker from '../TableFilterBarWithDatePicker/TableFilterBarWithDatePicker';
import StatusComponent from "../StatusComponent/StatusComponent";
import DynamicTableWithoutAction from '../DynamicTableWithoutAction/DynamicTableWithoutAction';
import RightSidebar from '../RightSidebar/RightSidebar';
import BigRightSidebar from '../BigRightSidebar/BigRightSidebar';
import {
  stickyActionColumnClassname,
  stickyActionRowClassname,
} from "@/app/utils/stickyActionClassname";
import ActionDropdown from '../ActionDropdown/ActionDropdown';
import ViewOrderParticular from '../ViewOrderParticular/ViewOrderParticular';
import EditOrder from '../EditOrder/EditOrder';
import ApproveOrderComponent from '../ApproveOrderComponent/ApproveOrderComponent';
import ReadyToShipOrderComponent from '../ReadyToShipOrderComponent/ReadyToShipOrderComponent';
import InvoiceInfoOrderComponent from '../InvoiceInfoOrderComponent/InvoiceInfoOrderComponent';
import DispatchInfoOrderComponent from '../DispatchInfoOrderComponent/DispatchInfoOrderComponent';
import DeliveryInfoOrderComponent from '../DeliveryInfoOrderComponent/DeliveryInfoOrderComponent';
import GRNInfoOrderComponent from '../GRNInfoOrderComponent/GRNInfoOrderComponent';
import axios from 'axios';

const InvoiceTable = () => {
  const { allB2BOrders } = useSelector((state) => state.b2bOrder);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState({
    total: 0,
    page: 1,
    limit: 50,
    totalPages: 0
  });
  const [filter, setFilter] = useState("allOrders");
  const [searchText, setSearchText] = useState("");
  const [dayFilter, setDayFilter] = useState("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarType, setSidebarType] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [selectedOrders, setSelectedOrders] = useState([]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const response = await b2bOrderService.getAllB2BOrderInvoices({
        page: pagination.page,
        limit: pagination.limit,
        searchText,
        filter,
        dayFilter,
        startDate: startDate ? moment(startDate).format('YYYY-MM-DD') : '',
        endDate: endDate ? moment(endDate).format('YYYY-MM-DD') : ''
      });

      if (response.success) {
        setOrders(response.data);
        setPagination(prev => ({
          ...prev,
          total: response.pagination.total,
          totalPages: response.pagination.totalPages
        }));
      }
    } catch (error) {
      console.error('Error fetching invoiced orders:', error);
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [pagination.page, pagination.limit, filter, searchText, dayFilter, startDate, endDate]);

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleSearchChange = (newSearchText) => {
    setSearchText(newSearchText);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handleDayFilterChange = (event) => {
    setDayFilter(event.target.value);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const currentDateAndFileName = `Custom_Order_${moment().format('DD-MMM-YYYY')}`;

  // Convert data to CSV
  const convertToCSV = (data, selectedOrders) => {
    const headers = [
      'WH', 'PO Date', 'Appointment Date','PO Expiry Date', 'Punch Date','Invoice date', 'Dispatch Date', 'Delivery Date',
      'Voucher Type', 'PO Number/Order No', 'Order Status',  'Order Remarks', 'Platform/Order Type', 'Invoice Number', 'Total Invoice Value', 'Customer', 'Customer GST','Channel',
      'State/Zone', 'City', 'Account Managers', 'Distinct Sku - Ordered', 'Qty ordered (case units)',
      'Qty ordered (in units)', 'Distinct Sku - Approved', 'Qty Approved (case units)',
      'Qty Approved (in units)', 'Distinct Sku - Fulfilled/ Dispatched', 'Qty Fulfilled / Dispatched (case units)',
      'Qty Fulfilled / Dispatched (in units)', 'Distinct Sku - GRN',
      'Qty GRN (in units)',
      
      
       
    'Short Fulfilled Quantity (SKU)', 'Short Fulfilled Quantity (Units)',
    'Short GRN Quantity (SKU)', 'Short GRN Quantity (Units)',
    
      'Ordered vs Approved % (SKU)', 'Ordered vs Approved % (Qty)',
      'Approved vs Fulfilled % (SKU)', 'Approved vs Fulfilled % (Qty)',
      'Ordered vs Fulfilled % (SKU)', 'Ordered vs Fulfilled % (Qty)',
      'Fulfilled vs GRN % (SKU)', 'Fulfilled vs GRN % (Qty)',
      'Ordered vs GRN % (SKU)', 'Ordered vs GRN % (Qty)',

      'Approval Remarks', 'WH/Fulfillment Remarks', 'GRN Remarks', 
     'Dispatch Mode', 'EDD Date', 'Carrier*', 'Tracking number', 'Box Count',
      'Tracking Link',
    ];
  
    const escapeCSVValue = (value) => {
      if (value === undefined || value === null) return '';
      const stringValue = String(value);
      return `"${stringValue.replace(/"/g, '""')}"`;
    };
  
    const formatDateTime = (dateString) => {
      if (!dateString) return '';

        // If it's an Excel serial date (numeric string or number)
        const excelSerial = parseFloat(dateString);
        if (!isNaN(excelSerial) && excelSerial > 25569) {
          const utcDays = Math.floor(excelSerial - 25569);
          const utcValue = utcDays * 86400; // seconds since Unix epoch
          const dateInfo = new Date(utcValue * 1000);

          const fractionalDay = excelSerial % 1;
          const totalSeconds = Math.round(fractionalDay * 86400);
          dateInfo.setSeconds(dateInfo.getSeconds() + totalSeconds);

          return moment(dateInfo).format("DD MMM YYYY HH:mm:ss");
        }

      const parsedDate = moment(dateString, [
        "M/D/YY H:mm",
        "DD/MM/YY",
        "DD/MM/YYYY",
        "DD/MM/YYYY HH:mm:ss", 
        "DD-MM-YYYY",          
        "D-M-YYYY",
        "YYYY-MM-DD", 
        "YYYY/MM/DD", 
        "MM/DD/YYYY", 
        "M/D/YYYY H:mm", 
        "M/D/YYYY h:mm A", "x", "X", moment.ISO_8601
      ]);
      return parsedDate.isValid() ? parsedDate.format("DD MMM YYYY HH:mm:ss") : 'Invalid Date';
    };
  
    const filteredData = selectedOrders.length > 0
      ? data.filter((order) => selectedOrders.includes(order._id))
      : data;
  
    const rows = filteredData.map((order) => {
      let totalQty = 0, approvedQty = 0, fulfilledQty = 0, grnQty = 0;
      let totalQtyUnits = 0, approvedQtyUnits = 0, fulfilledQtyUnits = 0, grnQtyUnits = 0;
      let skuOrdered = 0, skuApproved = 0, skuFulfilled = 0, skuGRN = 0;
      let approvedReasons = new Set();
      let fulfilledReasons = new Set();
      let grnReasons = new Set ();
      (order?.listOfProducts || []).forEach(product => {
        const caseSize = product?._id?.case_size || 1;
  
        // Basic counts
        skuOrdered++;
        if (product?.approvedQuantity) skuApproved++;
        if (product?.fulfilledQuantity) skuFulfilled++;
        if (product?.grnQuantity) skuGRN++;
  
        // Totals
        const qty = product?.quantity || 0;
        const approved = product?.approvedQuantity || 0;
        const fulfilled = product?.fulfilledQuantity || 0;
        const grn = product?.grnQuantity || 0;
  
        totalQty += qty;
        approvedQty += approved;
        fulfilledQty += fulfilled;
        grnQty += grn;
  
        totalQtyUnits += qty * caseSize;
        approvedQtyUnits += approved * caseSize;
        fulfilledQtyUnits += fulfilled * caseSize;

            // Collect unique reasons
            if (product?.approvedQuantityChangeReason) {
              approvedReasons.add(product.approvedQuantityChangeReason);
            }
            if (product?.fulfilledQuantityChangeReason) {
              fulfilledReasons.add(product.fulfilledQuantityChangeReason);
            }
            if (product?.grnQuantityChangeReason) {
              grnReasons.add(product.grnQuantityChangeReason);
            }

      });
  
      const percent = (num, denom) => denom > 0 ? ((num / denom) * 100).toFixed(2) + '%' : 'N/A';
  
      return [
        '', // WH
        escapeCSVValue(formatDateTime(order?.orderReceivedDate)),
        escapeCSVValue(formatDateTime(order?.appointmentDate)),
        escapeCSVValue(formatDateTime(order?.poExpiryDate)),
        escapeCSVValue(formatDateTime(order?.createdAt)),
        escapeCSVValue(formatDateTime(order?.invoiceDate)),
        escapeCSVValue(formatDateTime(order?.actualDispatchDate)),
        escapeCSVValue(formatDateTime(order?.deliveryDate)),
        escapeCSVValue(order?.documentType === 'delivery-note' ? 'Delivery Note' : 'Tax Invoice'),
        escapeCSVValue(order?.orderId),
        escapeCSVValue(order?.status),
        escapeCSVValue(order?.remarks),
        escapeCSVValue(order?.orderType),
        escapeCSVValue(order?.invoiceId),
        escapeCSVValue(order?.irnDetails?.irnRequestBody?.ValDtls?.TotInvVal),
        escapeCSVValue(order?.customerID?.name),
        escapeCSVValue(order?.customerID?.gstNumber),
        '',
        '',
        '',
        '',
        escapeCSVValue(skuOrdered),
        escapeCSVValue(totalQty),
        escapeCSVValue(totalQtyUnits),
        escapeCSVValue(skuApproved),
        escapeCSVValue(approvedQty),
        escapeCSVValue(approvedQtyUnits),
        escapeCSVValue(skuFulfilled),
        escapeCSVValue(fulfilledQty),
        escapeCSVValue(fulfilledQtyUnits),
        escapeCSVValue(skuGRN),
        escapeCSVValue(grnQty),
  
      escapeCSVValue(skuApproved - skuFulfilled), escapeCSVValue(approvedQtyUnits - fulfilledQtyUnits),
      escapeCSVValue(skuFulfilled - skuGRN), escapeCSVValue(fulfilledQtyUnits - grnQty),
      
      percent(skuApproved, skuOrdered), percent(approvedQtyUnits, totalQtyUnits),
      percent(skuFulfilled, skuApproved), percent(fulfilledQtyUnits, approvedQtyUnits),
      percent(skuFulfilled, skuOrdered), percent(fulfilledQtyUnits, totalQtyUnits),
      percent(skuGRN, skuFulfilled), percent(grnQty, fulfilledQtyUnits),
      percent(skuGRN, skuOrdered), percent(grnQty, totalQtyUnits),

  
      escapeCSVValue(Array.from(approvedReasons).join(', ')), 
      escapeCSVValue(Array.from(fulfilledReasons).join(', ')),
      escapeCSVValue(Array.from(grnReasons).join(', ')), // WH / GRN Remarks
      
        escapeCSVValue(formatDateTime(order?.deliveryDate)),
        escapeCSVValue(order?.modeOfTransport),
        escapeCSVValue(order?.shippingPartner),
        escapeCSVValue(order?.awbNumber),
        '', '', 
      ].join(',');
    });
  
    const csvString = [headers.join(','), ...rows].join('\n');
  
    // ✅ Blob method for proper encoding & large data support
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'Order-wise-invoices.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const convertToCSVSkuWise = async (data, selectedOrders) => {
    const headers = [
      'WH', 'PO Date', 'PO Expiry Date', 'Punch Date', 'Invoice date*', 'Dispatch Date',
      'Voucher Type', 'PO Number', 'Invoice Number','Total Invoice Taxable Value', 'Total Invoice Amount With Tax', 'Customer', 'Customer GST', 'Shipping Address', 'Billing Address', 'State', 'City', 'Pincode', 'Mode of Transport',
      'AWB Number', 'Order ID', 'Order Type', 'Order Status', 'SKU Code', 'SKU Name',
      'Order Qty', 'Approved Qty', 'Fulfilled/Dispatched Qty', 
      'GRN Qty', 'Approval Remarks', 'WH/Fulfillment Remarks', 'GRN Remarks', 'MRP', 'MRP (Without tax)', 'Selling Price','Selling Price (Without tax)', 'Margin', 'GST Rate','Taxable Amount', 'IGST Amount', 'SGST Amount', 'CGST Amount', 'Total Item Value'
    ];
  
    const escapeCSVValue = (value) => {
      if (value === undefined || value === null) return '';
      const stringValue = String(value);
      return `"${stringValue.replace(/"/g, '""')}"`;
    };
  
    const formatDateTime = (dateString) => {
      if (!dateString) return '';

      // If it's an Excel serial date (numeric string or number)
      const excelSerial = parseFloat(dateString);
      if (!isNaN(excelSerial) && excelSerial > 25569) {
        const utcDays = Math.floor(excelSerial - 25569);
        const utcValue = utcDays * 86400; // seconds since Unix epoch
        const dateInfo = new Date(utcValue * 1000);

        const fractionalDay = excelSerial % 1;
        const totalSeconds = Math.round(fractionalDay * 86400);
        dateInfo.setSeconds(dateInfo.getSeconds() + totalSeconds);

        return moment(dateInfo).format("DD MMM YYYY HH:mm:ss");
      }

      const parsedDate = moment(dateString, [
        "M/D/YY H:mm",
        "DD/MM/YY",
        "DD/MM/YYYY",
        "DD/MM/YYYY HH:mm:ss", 
        "DD-MM-YYYY",          
        "D-M-YYYY",
        "YYYY-MM-DD", 
        "YYYY/MM/DD", 
        "MM/DD/YYYY", 
        "M/D/YYYY H:mm", 
        "M/D/YYYY h:mm A", "x", "X", moment.ISO_8601
      ]);
      return parsedDate.isValid() ? parsedDate.format("DD MMM YYYY HH:mm:ss") : 'Invalid Date';
    };

    // Initialize cache for pincode lookups
    const pincodeCache = new Map();
    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

    // Function to get location data with retries
    const getLocationFromPincode = async (pincode, retries = 2) => {
      if (!pincode) return { state: '', city: '' };
      
      // Check cache first
      if (pincodeCache.has(pincode)) {
        return pincodeCache.get(pincode);
      }

      for (let attempt = 0; attempt <= retries; attempt++) {
        try {
          if (attempt > 0) await delay(50 * attempt); // Increasing delay for each retry
          
          const response = await axios.get(`https://api.postalpincode.in/pincode/${pincode}`);
          const responseData = response.data[0];
          
          if (responseData.Status === "Success" && responseData.PostOffice?.length > 0) {
            const location = {
              state: responseData.PostOffice[0].State,
              city: responseData.PostOffice[0].District
            };
            pincodeCache.set(pincode, location);
            return location;
          }
        } catch (error) {
          if (attempt === retries) {
            console.error(`Failed to fetch location for pincode ${pincode} after ${retries} retries`);
            break;
          }
          await delay(50); // Wait before retry
        }
      }
      
      const emptyLocation = { state: '', city: '' };
      pincodeCache.set(pincode, emptyLocation);
      return emptyLocation;
    };

    // Pre-fetch all unique pincodes
    const prefetchPincodes = async (data) => {
      const uniquePincodes = new Set();
      data.forEach(order => {
        const billingAddress = order?.customerID?.billing_address || '';
        const pincode = billingAddress.match(/\b\d{6}\b/)?.[0];
        if (pincode) uniquePincodes.add(pincode);
      });

      // Process unique pincodes in parallel with a small delay between each
      const pincodeArray = Array.from(uniquePincodes);
      const batchSize = 5; // Process 5 pincodes at a time
      
      for (let i = 0; i < pincodeArray.length; i += batchSize) {
        const batch = pincodeArray.slice(i, i + batchSize);
        await Promise.all(batch.map(pincode => getLocationFromPincode(pincode)));
        if (i + batchSize < pincodeArray.length) {
          await delay(100); // 100ms delay between batches
        }
      }
    };

    const filteredData = selectedOrders.length > 0
      ? data.filter(order => selectedOrders.includes(order._id))
      : data;

    // Pre-fetch all pincodes before processing the data
    await prefetchPincodes(filteredData);

    const rows = await Promise.all(filteredData.flatMap(order => {
      return order?.listOfProducts?.map(async (product) => {
        // Find matching item details from ItemList
        const itemDetails = order?.irnDetails?.irnRequestBody?.ItemList?.find(item => 
          item?.PrdDesc?.toLowerCase() === product?.skuCode?.toLowerCase()
        ) || {};
        
        // Extract pincode from billing address
        const billingAddress = order?.customerID?.billing_address || '';
        const billingPincode = billingAddress.match(/\b\d{6}\b/)?.[0] || '';
        
        // Get state and city from cache (since we pre-fetched all pincodes)
        const { state, city } = pincodeCache.get(billingPincode) || { state: '', city: '' };

        const mrp = parseFloat(itemDetails?.PrdMrp) || 0;
        const gstRate = itemDetails?.GstRt !== undefined && itemDetails?.GstRt !== null ? parseFloat(itemDetails?.GstRt) : null;
        const unitPrice = parseFloat(itemDetails?.UnitPrice) || 0;
        
        let priceBeforeGST = "";
        let marginPercent = "";
        let formattedGstRate = "";
        let formattedUnitPriceWithoutTax = "";
        let formattedUnitPriceWithTax = "";
        
        // Only calculate if MRP is available and greater than 0
        if (mrp > 0 && gstRate !== null) {
            priceBeforeGST = (mrp / (1 + (gstRate / 100))).toFixed(2);
            marginPercent = Math.round(((priceBeforeGST - unitPrice) / priceBeforeGST) * 100) + '%';
            formattedGstRate = gstRate + '%';
            formattedUnitPriceWithoutTax = unitPrice.toFixed(2);
            formattedUnitPriceWithTax = product?.ppu;
        }

        return [
          escapeCSVValue(''), // WH
          escapeCSVValue(formatDateTime(order?.orderReceivedDate)),
          escapeCSVValue(formatDateTime(order?.poExpiryDate)),
          escapeCSVValue(formatDateTime(order?.createdAt)),
          escapeCSVValue(formatDateTime(order?.invoiceDate)),
          escapeCSVValue(formatDateTime(order?.actualDispatchDate)),
          escapeCSVValue(order?.documentType === 'delivery-note' ? 'Delivery Note' : 'Tax Invoice'),
          escapeCSVValue(order?.orderId),
          escapeCSVValue(order?.invoiceId || ' '),
          escapeCSVValue(order?.irnDetails?.irnRequestBody?.ValDtls?.AssVal || 'N/A'),
          escapeCSVValue(order?.irnDetails?.irnRequestBody?.ValDtls?.TotInvVal || 'N/A'),
          escapeCSVValue(order?.customerID?.name),
          escapeCSVValue(order?.customerID?.gstNumber),
          escapeCSVValue(order?.customerID?.shipping_address),
          escapeCSVValue(billingAddress),
          escapeCSVValue(state),
          escapeCSVValue(city),
          escapeCSVValue(billingPincode),
          escapeCSVValue(order?.modeOfTransport),
          escapeCSVValue(order?.awbNumber),
          escapeCSVValue(order?.orderId),
          escapeCSVValue(order?.orderType),
          escapeCSVValue(order?.status),
          escapeCSVValue(product?.skuCode),
          escapeCSVValue(itemDetails?.PrdName || ''),
          escapeCSVValue(product?.quantity),
          escapeCSVValue(product?.approvedQuantity),
          escapeCSVValue(product?.fulfilledQuantity),
          escapeCSVValue(product?.grnQuantity),
          escapeCSVValue(product?.approvedQuantityChangeReason),
          escapeCSVValue(order?.remarks),
          escapeCSVValue(''),
          escapeCSVValue(itemDetails?.PrdMrp || ''),
          escapeCSVValue(priceBeforeGST),
          escapeCSVValue(formattedUnitPriceWithTax),
          escapeCSVValue(formattedUnitPriceWithoutTax),
          escapeCSVValue(marginPercent),
          escapeCSVValue(formattedGstRate),
          escapeCSVValue(itemDetails?.TotAmt || ''),
          escapeCSVValue(itemDetails?.IgstAmt || ''),
          escapeCSVValue(itemDetails?.SgstAmt || ''),
          escapeCSVValue(itemDetails?.CgstAmt || ''),
          escapeCSVValue(itemDetails?.TotItemVal || '')
        ].join(',');
      });
    }));

    const csvString = [headers.join(','), ...rows].join('\n');
  
    // Create and download the CSV file
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'Sku-wise-invoices.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };
  
  const searchKeys = [
    "orderId",
    "customerID",
    "invoiceId",
    "shippingAddress",
    "orderType"
  ];

  const headings = {
    checkbox: {
      label: "Select",
      isCheckbox: true,
      onChange: (row) => handleCheckboxChange(row._id),
      isSticky: false,
    },
    invoiceId: {
    label: "Invoice ID",
    renderCell: (row) => row?.invoiceId || "N/A",
    isSticky: false,
  },
    orderId: {
      label: "Order ID",
      renderCell: (row) => row?.orderId || "N/A",
      isSticky: false,
    },
    customerName: {
      label: "Customer Name",
      renderCell: (row) => row?.customerID?.name || "N/A",
      isSticky: false,
    },
    status: {
      label: "Status",
      renderCell: (row) => <StatusComponent status={row?.status} /> || "N/A",
      isSticky: false,
    },
    orderType: {
      label: "Order Type",
      renderCell: (row) => row?.orderType || "N/A",
      isSticky: false,
    },
    shippingAddress: {
      label: "Shipping Address",
      renderCell: (row) =>
        (row?.shippingAddress || row?.customerID?.shipping_address)?.slice(0, 25) + "..." || "N/A",
      isSticky: false,
    },
    distinctProducts: {
      label: "Distinct Products",
      renderCell: (row) => row?.listOfProducts?.length || "N/A",
      isSticky: false,
    },
    fulfilledProducts : {
      label: "Fulfilled Products",
      renderCell: (row) =>
        row?.listOfProducts?.reduce(
          (acc, product) => 
            (product.fulfilledQuantity !== undefined && product.fulfilledQuantity >= 1) ? acc + 1 : acc,
          0
        ) || "N/A",
      isSticky: false,
    },
    remarks: {
      label: "Remarks",
      renderCell: (row) => row?.remarks || "N/A",
      isSticky: false,
    },
    action: {
      label: "Action",
      renderCell: (row) => (
        <ActionDropdown order={row} actions={generateOrderActions(row)} />
      ),
      isSticky: true,
      stickyClassHeader: stickyActionColumnClassname,
      stickyClassRow: stickyActionRowClassname,
    },
  };


  const generateOrderActions = (order) => {
    return [
      {
        label: "View Order Particulars",
        condition: () => true,
        action: () => openSidebar("viewOrderParticular", order),
      },

    ];
  };

  const openSidebar = (type, order) => {
    setSidebarType(type);
    setSelectedOrder(order);
    setIsSidebarOpen(true);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
    setSidebarType(null);
    setSelectedOrder(null);
  };
  

  const filterOptions = [
    { value: "allOrders", label: "All Invoices" },
    { value: "delivered", label: "Delivered Orders" },
    { value: "delivery-note", label: "Delivery Notes" },
    { value: "Blinkit", label: "Blinkit Orders" },
    { value: "Zepto", label: "Zepto Orders" },
    { value: "Swiggy", label: "Swiggy Orders" }
  ];

  const handleCheckboxChange = (orderInternalId) => {
    // Toggle the orderID in the selected Orders list
    setSelectedOrders((prevSelectedOrders) =>
      prevSelectedOrders.includes(orderInternalId)
        ? prevSelectedOrders.filter((id) => id !== orderInternalId)
        : [...prevSelectedOrders, orderInternalId]
    );
    console.log ("Checking ", selectedOrders);
  };





  const handleDownload = async () => {
    try {
      setLoading(true);
      const response = await b2bOrderService.getAllB2BOrderInvoicesForDownload({
        searchText,
        filter,
        dayFilter,
        startDate: startDate ? moment(startDate).format('YYYY-MM-DD') : '',
        endDate: endDate ? moment(endDate).format('YYYY-MM-DD') : ''
      });

      if (response.success) {
        const dataToDownload = selectedOrders.length > 0
          ? response.data.filter(order => selectedOrders.includes(order._id))
          : response.data;
        
        convertToCSV(dataToDownload, selectedOrders);
      }
    } catch (error) {
      console.error('Error downloading orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadSkuWise = async () => {
    try {
      setLoading(true);
      const response = await b2bOrderService.getAllB2BOrderInvoicesForDownload({
        searchText,
        filter,
        dayFilter,
        startDate: startDate ? moment(startDate).format('YYYY-MM-DD') : '',
        endDate: endDate ? moment(endDate).format('YYYY-MM-DD') : ''
      });

      if (response.success) {
        const dataToDownload = selectedOrders.length > 0
          ? response.data.filter(order => selectedOrders.includes(order._id))
          : response.data;
        
        await convertToCSVSkuWise(dataToDownload, selectedOrders);

      }
    } catch (error) {
      console.error('Error downloading SKU-wise orders:', error);
    } finally {
      setLoading(false);
    }
  };



return (
  <>
    <TableFilterBarWithDatePicker
      filter={filter}
      setFilter={handleFilterChange}
      searchText={searchText}
      setSearchText={handleSearchChange}
      convertToCSV={handleDownload}
      convertToCSVSkuWise={handleDownloadSkuWise}
      allPO={orders}
      selectedRows={selectedOrders}
      filterOptions={filterOptions}
      dayFilter={dayFilter}
      handleDayFilterChange={handleDayFilterChange}
      startDate={startDate}
      setStartDate={(date) => {
        setStartDate(date);
        setPagination(prev => ({ ...prev, page: 1 }));
      }}
      endDate={endDate}
      setEndDate={(date) => {
        setEndDate(date);
        setPagination(prev => ({ ...prev, page: 1 }));
      }}
      isLoading={loading}
    />

    {loading ? (
      <div className="flex justify-center items-center p-4">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    ) : (
      <DynamicTableWithoutAction 
        headings={headings} 
        rows={orders}
        pagination={{
          ...pagination,
          onPageChange: (newPage) => setPagination(prev => ({ ...prev, page: newPage })),
          onLimitChange: (newLimit) => setPagination(prev => ({ ...prev, limit: newLimit, page: 1 }))
        }}
      />
    )}

    {sidebarType === "viewOrderParticular" && (
      <BigRightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
        <ViewOrderParticular
          selectedOrder={selectedOrder}
          handleCancel={closeSidebar}
        />
      </BigRightSidebar>
    )}
  </>
);
};

export default InvoiceTable;

