import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import CategoryDropdown from "@/app/components/CategoryDropdown/CategoryDropdown";
import SKUDropdown from "../SKUDropdown/SKUDropdown";
import Input from "../Input/Input";
import { categoryServices } from "@/app/services/categoryService";
import {
  getAllCategorySuccess,
  getAllCategoryRequest,
} from "../../Actions/categoryActions";
import {
  getSKUByCategoryFailure,
  getSKUByCategoryRequest,
  getSKUByCategorySuccess,
} from "../../Actions/skuActions";
import { sfgCategories } from "@/app/constants/categoryConstants";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  SecondaryButton,
  PrimaryButton,
} from "../ButtonComponent/ButtonComponent";
import { skuServices } from "@/app/services/skuServices";
import { productionPOServices } from "@/app/services/productionPOService";

const CreateProductionPO = ({ onCancel }) => {
  const { allCategories, selectedCatId } = useSelector(
    (state) => state.category
  );
  const { skusByCategory } = useSelector((state) => state.sku);
  const { dropDownSKUName, dropDownSKUValue } = useSelector((state) => state.dropdown);
  const [selectedSKU, setSelectedSKU] = useState(null);
  const [quantity, setQuantity] = useState(null);
  const [listData, setListData] = useState([]);
  const [errors, setErrors] = useState({});
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);

  const addItemsToList = () => {
    if (!selectedSKU || !quantity) {
      setErrors({
        selectedSKU: !selectedSKU ? "Please select an SKU." : undefined,
        quantity: !quantity ? "Please enter a quantity." : undefined,
      });
      return;
    }

    // Add SKU and quantity to the list
    setListData([...listData, { sku: selectedSKU, quantity , skuName: dropDownSKUName}]);
    
    // Reset input fields
    setSelectedSKU(null);
    setQuantity(null);
    setErrors({});
  };

  const getAllCategories = async () => {
    try {
      dispatch(getAllCategoryRequest());
      const response = await categoryServices.getAllCategories();
      const fgCategories = response.data.filter((category) =>
        sfgCategories.includes(category.category_name)
      );
      if (response.success) {
        dispatch(getAllCategorySuccess(fgCategories));
      }
    } catch (err) {
      console.error(err);
    }
  };

    useEffect(() => {
     setSelectedSKU (dropDownSKUValue);
    }, [dropDownSKUName]);

  const getSKUByCatId = async () => {
    try {
      dispatch(getSKUByCategoryRequest());
      const response = await skuServices.getSKUsByCategoryId(selectedCatId);
      if (response.success) {
        dispatch(getSKUByCategorySuccess(response.data));
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    getSKUByCatId();
  }, [selectedCatId]);

  useEffect(() => {
    getAllCategories();
  }, []);

  const createPO = async () => {
    if (listData.length === 0) {
      toast.error("Please add at least one item to the list.");
      return;
    }
    setLoading(true);

    try {
      const response = await productionPOServices.createProductionPO(listData);
      
      if (response.success) {
        toast.success("Production PO raised successfully!", {
            autoClose: 1500,
            onClose: () => {
              window.location.reload();
            },
          });
        setListData([]); 
      } else {
        toast.error(response.message || "Error creating Production PO.");
      }
    } catch (error) {
      toast.error(error.message || "Error creating Production PO.");
    }
  };

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <ToastContainer position="bottom-center" />
        <h2 className="text-base font-semibold text-[#111928] mb-1">
          Raise Production PO
        </h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          Select SKU items and specify quantities to raise a Production PO.
        </p>

        <div className="flex flex-col my-6">
          <label className="text-[#111928] text-sm font-medium mb-1">
            Category Name<span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <CategoryDropdown options={allCategories} />
        </div>

        <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">
            Select SKU<span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <SKUDropdown
            name="selectedSKU"
            options={skusByCategory}
            value={selectedSKU}
            onChange={(e) => {
              setSelectedSKU(e.target.value);
              setErrors((prev) => ({ ...prev, selectedSKU: undefined }));
            }}
          />
          {errors.selectedSKU && (
            <p className="text-xs mt-1 ml-1 text-red-500">{errors.selectedSKU}</p>
          )}
        </div>

        <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">
            Quantity<span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <Input
            type="number"
            name="quantity"
            value={quantity || ""}
            onChange={(e) => {
              setQuantity(e.target.value);
              setErrors((prev) => ({ ...prev, quantity: undefined }));
            }}
            placeholder="Enter Quantity"
          />
          {errors.quantity && (
            <p className="text-xs mt-1 ml-1 text-red-500">{errors.quantity}</p>
          )}
        </div>

        <div className="mt-3">
          <SecondaryButton title="+ Add Item" onClick={addItemsToList} />
        </div>

        {listData.length > 0 && (
          <div className="mt-4">
            <h2 className="text-base font-semibold text-dark mb-2">
              Selected Items: {listData.length}
            </h2>
            <ul className="flex flex-col gap-2">
              {listData.map((item, idx) => (
                <li
                  key={idx}
                  className="shadow-sm rounded-lg py-3 bg-white flex items-center justify-between px-4"
                >
                  <div className="flex gap-6">
                    <div className="flex gap-x-2">
                      <span className="text-sm text-dark-4 font-medium">
                        SKU:
                      </span>
                      <span className="font-normal text-sm text-dark-4">
                        {item.skuName}
                      </span>
                    </div>
                    <div className="flex gap-x-2">
                      <span className="font-normal text-sm text-dark-4">
                        Quantity:
                      </span>
                      <span className="font-normal text-sm text-dark-4">
                        {item.quantity}
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" width="w-full" onClick={onCancel} />
          </div>
          <div className="flex-1">
            <PrimaryButton
              title="Raise Production PO"
              onClick={createPO}
              disabled={listData.length === 0}
              width="w-full"
            />
          </div>
        </div>
      </div>

      {loading && (
      <div
        className="fixed top-0 left-0 w-full h-full bg-gray-400 opacity-50 z-50"
        style={{ zIndex: 1000 }}
      />
    )}
    </>
  );
};

export default CreateProductionPO;
