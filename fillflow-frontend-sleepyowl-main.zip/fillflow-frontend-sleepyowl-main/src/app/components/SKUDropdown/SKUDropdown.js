import React, { useState, useRef, useEffect } from "react";
import { useDispatch } from "react-redux";
import { getSkuValue, getSkuName } from "../../Actions/dropdownValuesActions";

const SKUDropdown = ({ bgColor, height, width, options }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const dispatch = useDispatch();
  const dropdownRef = useRef(null);

  const handleSKUChange = (sku) => {
    dispatch(getSkuValue(sku._id));
    dispatch(getSkuName(sku.sku_name));
    setDropdownVisible(false);
    setSearchTerm(`${sku.sku_code} - ${sku.sku_name}`);
    console.log("Selected SKU Value:", sku._id);
  };

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
    setDropdownVisible(true);
    console.log("Search Term:", event.target.value);
  };

  const sortedOptions = [...options].sort((a, b) => a.sku_name.localeCompare(b.sku_name));
  const filteredOptions = sortedOptions.filter((sku) =>
    `${sku.sku_code} - ${sku.sku_name}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setDropdownVisible(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div style={{ width: width || "auto", position: "relative" }} ref={dropdownRef}>
      <input
        type="text"
        value={searchTerm}
        onChange={handleSearchChange}
        onFocus={() => setDropdownVisible(true)}
        placeholder="Search SKUs..."
        className="w-full p-2 border font-normal text-sm h-10 px-4 bg-white border-gray-300 text-[#4B5563] rounded-xl"
      />
      {dropdownVisible && (
        <div
          className="absolute z-50 bg-white border border-gray-300 rounded-[6px] max-h-[20vw] overflow-y-auto 
        w-full shadow-md scrollbar-none"
        >
          <ul style={{ listStyleType: "none", padding: "0", margin: "0" }}>
            {filteredOptions.length > 0 ? (
              filteredOptions.map((sku) => (
                <li
                  key={sku._id}
                  value={sku._id}
                  onClick={() => handleSKUChange(sku)}
                  className="px-5 py-3 text-sm font-medium cursor-pointer text-[#111928] hover:bg-[#F5F3FF] hover:text-[#3758F9]"
                  style={{
                    borderBottom: "1px solid #e5e7eb",
                  }}
                >
                  {sku.sku_code} - {sku.sku_name}
                </li>
              ))
            ) : (
              <li style={{ padding: "0.5vw 1vw", color: "#838481", backgroundColor: bgColor || "white" }}>
                No SKUs found
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default SKUDropdown;
