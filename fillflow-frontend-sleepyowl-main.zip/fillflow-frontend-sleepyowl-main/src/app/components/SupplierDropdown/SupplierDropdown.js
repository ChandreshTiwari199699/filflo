import React, { useState, useRef, useEffect } from "react";
import { useDispatch } from "react-redux";
import { getSupplierName, getSupplierValue } from "../../Actions/dropdownValuesActions";

const SupplierDropdown = ({ bgColor, height, width, options }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const dispatch = useDispatch();
  const dropdownRef = useRef(null);

  const handleSupplierChange = (supplier) => {
    dispatch(getSupplierValue(supplier._id));
    dispatch(getSupplierName(supplier.name));
    setDropdownVisible(false);
    setSearchTerm(`${supplier.supplierId} - ${supplier.name}`);
  };

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
    setDropdownVisible(true);
  };

  const sortedOptions = [...options].sort((a, b) => a.name.localeCompare(b.name));

  const filteredOptions = sortedOptions.filter((supplier) =>
    `${supplier.supplierId} - ${supplier.name}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setDropdownVisible(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div style={{ width: width || "auto", position: "relative" }} ref={dropdownRef}>
      <input
        type="text"
        value={searchTerm}
        onChange={handleSearchChange}
        onFocus={() => setDropdownVisible(true)}
        placeholder="Search suppliers..."
        className="w-full p-2 border font-normal text-sm h-10 px-4 bg-white border-gray-300 text-[#4B5563] rounded-xl"
      />

      {dropdownVisible && (
        <div
          className={`absolute z-50 bg-white border border-gray-300 rounded-[6px] max-h-[20vw] overflow-y-auto 
        w-full shadow-md scrollbar-none`}
        >
          <ul style={{ listStyleType: "none", padding: "0", margin: "0" }}>
            {filteredOptions.length > 0 ? (
              filteredOptions.map((supplier) => (
                <li
                  key={supplier._id}
                  value={supplier._id}
                  onClick={() => handleSupplierChange(supplier)}
                  className="px-5 py-3 text-sm font-medium cursor-pointer text-[#111928] hover:bg-[#F5F3FF] hover:text-[#3758F9]"
                  onMouseEnter={(e) => (e.target.style.backgroundColor = "#f3f4f6")}
                  onMouseLeave={(e) => (e.target.style.backgroundColor = "white")}
                  style={{
                    borderBottom: "1px solid #e5e7eb",
                  }}
                >
                  {supplier.supplierId} - {supplier.name}
                </li>
              ))
            ) : (
              <li
                style={{
                  padding: "0.75rem 1rem",
                  color: "#9ca3af",
                  backgroundColor: "#f9fafb",
                  textAlign: "center",
                }}
              >
                No suppliers found
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default SupplierDropdown;
