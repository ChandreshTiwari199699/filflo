"use client";
import React, { useState, useEffect } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Input from "@/app/components/Input/Input";
import { PrimaryButton, SecondaryButton } from "@/app/components/ButtonComponent/ButtonComponent";
import { b2bOrderService } from "@/app/services/b2bOrderService";

const ApproveOrderComponent = ({ selectedOrderOriginal, handleCancel }) => {
    const [selectedOrder, setSelectedOrder] = useState({
        ...selectedOrderOriginal,
        listOfProducts: selectedOrderOriginal.listOfProducts.map((product) => ({
          ...product,
          approvedQuantity: product.approvedQuantity || product.quantity,
          escalationReason: "", 
        })),
      });
      
  const [processOrderData, setProcessOrderData] = useState({
    orderPriority: "",
    status: selectedOrder.status || "open",
    scheduledDispatchDate: selectedOrder.scheduledDispatchDate || "",
  });

  const [isApproved, setIsApproved] = useState(false);
  const [errors, setErrors] = useState({});
  const [orderData, setOrderData] = useState(selectedOrder);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [scheduledDispatchDate, setScheduledDispatchDate] = useState(selectedOrder.scheduledDispatchDate || "");
  const [invoiceWithPaymentInfo, setInvoiceWithPaymentInfo] = useState(false); 
  const [showScheduledDispatchDate, setShowScheduledDispatchDate] = useState(!selectedOrder.scheduledDispatchDate);


  useEffect(() => {
    setOrderData(selectedOrder);
  }, [selectedOrder]);

  useEffect(() => {
    // Once the user sets a date, keep it visible
    if (scheduledDispatchDate) {
      setShowScheduledDispatchDate(true);
    }
  }, [scheduledDispatchDate]);


  

  // Handle form changes
  const handleProcessChange = (e) => {
    const { name, value } = e.target;
    setProcessOrderData((prev) => ({ ...prev, [name]: value }));
  };

  const handleApprovedQuantityChange = (e, productIndex) => {
    const newApprovedQuantity = e.target.value;
    setSelectedOrder((prevState) => {
      const updatedListOfProducts = [...prevState.listOfProducts];
      updatedListOfProducts[productIndex] = {
        ...updatedListOfProducts[productIndex],
        approvedQuantity: newApprovedQuantity,
        escalationReason:
          newApprovedQuantity != updatedListOfProducts[productIndex].quantity
            ? "escalation"
            : "", 
      };
      return { ...prevState, listOfProducts: updatedListOfProducts };
    });
  };
  
  

  const handleSaveChanges = async (e) => {
    e.preventDefault();
    const newErrors = {};

    // Validation
    if (!processOrderData.orderPriority)
      newErrors.orderPriority = "Order Priority is required.";
    if (!isApproved) newErrors.status = "Status must be marked as approved.";
    if (!scheduledDispatchDate) {
      newErrors.scheduledDispatchDate = "Scheduled Dispatch Date is required.";
    }

    orderData.listOfProducts.forEach((product, index) => {
        if (!product.approvedQuantity || product.approvedQuantity < 0) {
          newErrors[`product_${index}`] = `Approved units for SKU ${product.skuCode} are required.`;
        } else if (product.approvedQuantity > product.quantity) {
          // Add validation for exceeding the desired quantity
          newErrors[`product_${index}`] = `Approved units cannot exceed desired units (${product.quantity}).`;
        }
          // Escalation reason required if quantity is changed
  if (product.approvedQuantity != product.quantity && !product.escalationReason.trim()) {
    newErrors[`escalation_${index}`] = `Escalation reason is required for SKU ${product.skuCode}.`;
  }
      });
      

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsSubmitting(true);

    try {
      const updatedData = {
        ...processOrderData,
        orderInternalId: selectedOrder._id,
        status: isApproved ? "approved" : processOrderData.status,
        scheduledDispatchDate,
        invoiceWithPaymentInfo,
        products: orderData.listOfProducts.map((product) => ({
          skuCode: product.skuCode,
          approvedQuantity: product.approvedQuantity,
          approvedQuantityChangeReason: 
          product.approvedQuantity !== product.quantity ? product.escalationReason : null,
        })),
      };

      const result = await b2bOrderService.editB2BOrderByOrderInternalId(updatedData);

      if (result.success) {
        toast.success("B2B Order processed successfully!", {
          autoClose: 1500,
          onClose: () => {
            window.location.reload();
          },
        });
      } else {
        toast.error(`Failed to process order: ${result.error}`);
      }
    } catch (error) {
      toast.error("An error occurred while processing the order.");
    }
    finally {
    }
  };

  return (
    <>
<div className="relative overflow-y-auto max-h-[80vh] scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200 pb-10 text-black">
      <ToastContainer position="bottom-center" />
      <h2 className="text-base font-semibold text-[#111928] mb-1">Process Order</h2>
      <p className="text-sm font-normal text-[#4B5563] mb-6">
        Fill in details to process the order and update quantities.
      </p>

      {/* Table for Products */}
      <table className="min-w-full text-sm text-[#111928] font-medium border border-gray-300 rounded-lg overflow-hidden">
  <thead className="text-xs text-[#111928] uppercase bg-gray-200">
    <tr>
      <th className="px-4 py-2 text-left w-1/4">SKU Code</th>
      <th className="px-4 py-2 text-left w-1/4">Desired Units</th>
      <th className="px-4 py-2 text-left w-1/4">Approved Units</th>
      <th className="px-4 py-2 text-left w-1/4">Quantity Change Reason</th> 
    </tr>
  </thead>
  <tbody>
    {selectedOrder?.listOfProducts.map((product, index) => (
      <tr key={index} className="border-b">
        <td className="px-4 py-2">{product.skuCode}</td>
        <td className="px-4 py-2">{product.quantity}</td>
        <td className="px-4 py-2">
          <input
            type="number"
            value={product.approvedQuantity || ""}
            className={`w-20 border rounded p-1 ${
              errors[`product_${index}`] ? "border-red-500" : ""
            }`}
            onChange={(e) => handleApprovedQuantityChange(e, index)}
          />
          {errors[`product_${index}`] && (
            <div className="text-red-500 text-xs mt-1">
              {errors[`product_${index}`]}
            </div>
          )}
        </td>

        {/* Escalation Reason Field (Always Visible, But Disabled if Not Needed) */}
        <td className="px-4 py-2 w-[250px]"> {/* ✅ Increased width */}
          <input
            type="text"
            value={product.escalationReason}
            onChange={(e) => {
              const newReason = e.target.value;
              setSelectedOrder((prevState) => {
                const updatedListOfProducts = [...prevState.listOfProducts];
                updatedListOfProducts[index] = {
                  ...updatedListOfProducts[index],
                  escalationReason: newReason,
                };
                return { ...prevState, listOfProducts: updatedListOfProducts };
              });
            }}
            className={`w-full border rounded p-1 ${
              errors[`escalation_${index}`] ? "border-red-500" : ""
            }`}
            disabled={product.approvedQuantity == product.quantity} // ✅ Disable if not needed
          />
          {errors[`escalation_${index}`] && (
            <div className="text-red-500 text-xs mt-1">
              {errors[`escalation_${index}`]}
            </div>
          )}
        </td>
      </tr>
    ))}
  </tbody>
</table>



      {/* Order Priority Dropdown */}
      <div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Order Priority <span className="text-[#9CA3AF] ml-[2px]">*</span>
  </label>
  <select
    name="orderPriority"
    value={processOrderData.orderPriority}
    onChange={handleProcessChange}
    className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
      errors.orderPriority ? "border-red-500" : "border-gray-300"
    }`}
  >
    <option value="" className="text-[#9CA3AF] text-sm font-medium">
      Select Priority
    </option>
    <option value="Urgent" className="text-[#111928] text-sm font-medium">
      Urgent
    </option>
    <option value="Standard" className="text-[#111928] text-sm font-medium">
      Standard
    </option>
    <option value="Low" className="text-[#111928] text-sm font-medium">
      Low
    </option>
  </select>
  {errors.orderPriority && (
    <div className="text-red-500 text-xs mt-1">{errors.orderPriority}</div>
  )}
</div>

{showScheduledDispatchDate && (
  <div className="flex flex-col mb-6">
    <label className="block text-[#111928] text-sm font-medium mb-1">
      Scheduled Dispatch Date <span className="text-[#9CA3AF] ml-[2px]">*</span>
    </label>
    <input
      type="date"
      value={scheduledDispatchDate}
      onChange={(e) => setScheduledDispatchDate(e.target.value)}
      className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
        errors.scheduledDispatchDate ? "border-red-500" : "border-gray-300"
      }`}
    />
    {errors.scheduledDispatchDate && (
      <div className="text-red-500 text-xs mt-1">{errors.scheduledDispatchDate}</div>
    )}
  </div>
)}




      {/* Checkbox for Approval */}
      <div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Status : <span className="text-[#9CA3AF] ml-[2px]">*</span>
  </label>
  <div className="flex items-center">
    <input
      type="checkbox"
      name="status"
      checked={isApproved}
      onChange={(e) => setIsApproved(e.target.checked)}
      className={`w-4 h-4 text-blue-600 border-gray-300 rounded ${
        errors.status ? "border-red-500" : ""
      }`}
    />
    <span className="ml-2 text-[#111928] text-sm font-medium">Mark as Approved</span>
  </div>
  {errors.status && (
    <div className="text-red-500 text-xs mt-1">{errors.status}</div>
  )}
</div>
</div>

  <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">
            Invoice with Payment Info
          </label>
          <div className="flex items-center">
            <input
              type="checkbox"
              name="invoiceWithPaymentInfo"
              checked={invoiceWithPaymentInfo}
              onChange={(e) => setInvoiceWithPaymentInfo(e.target.checked)}
              className="w-4 h-4 text-blue-600 border-gray-300 rounded"
            />
            <span className="ml-2 text-[#111928] text-sm font-medium">Include payment details in the invoice</span>
          </div>
        </div>



      {/* Buttons */}
      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
          </div>
          <div className="flex-1">
            <PrimaryButton title="Save Changes" onClick={handleSaveChanges} size="full"  disabled={isSubmitting}/>
          </div>
        </div>
      </div>
    
    </>
  );
};

export default ApproveOrderComponent;
