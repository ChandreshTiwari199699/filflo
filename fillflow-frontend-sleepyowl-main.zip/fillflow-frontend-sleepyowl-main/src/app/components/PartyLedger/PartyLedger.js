'use client';
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import { b2bOrderService } from '@/app/services/b2bOrderService';
import B2BCustomerDropdown from "../B2BCustomerDropdown/B2BCustomerDropdown";
import { getAllB2BCustomerRequest, getAllB2BCustomerSuccess, getAllB2BCustomerFailure } from "../../Actions/b2bCustomerActions";
import searchNested from '@/app/utils/searchUtils';
import { filterByDate } from "../DateFilter/DateFilter";
import TableFilterBarWithDatePicker from '../TableFilterBarWithDatePicker/TableFilterBarWithDatePicker';
import StatusComponent from "../StatusComponent/StatusComponent";
import DynamicTableWithoutAction from '../DynamicTableWithoutAction/DynamicTableWithoutAction';
import RightSidebar from '../RightSidebar/RightSidebar';
import BigRightSidebar from '../BigRightSidebar/BigRightSidebar';
import {
  stickyActionColumnClassname,
  stickyActionRowClassname,
} from "@/app/utils/stickyActionClassname";
import ActionDropdown from '../ActionDropdown/ActionDropdown';
import ViewOrderParticular from '../ViewOrderParticular/ViewOrderParticular';
import EditOrder from '../EditOrder/EditOrder';
import ApproveOrderComponent from '../ApproveOrderComponent/ApproveOrderComponent';
import ReadyToShipOrderComponent from '../ReadyToShipOrderComponent/ReadyToShipOrderComponent';
import InvoiceInfoOrderComponent from '../InvoiceInfoOrderComponent/InvoiceInfoOrderComponent';
import DispatchInfoOrderComponent from '../DispatchInfoOrderComponent/DispatchInfoOrderComponent';
import DeliveryInfoOrderComponent from '../DeliveryInfoOrderComponent/DeliveryInfoOrderComponent';
import GRNInfoOrderComponent from '../GRNInfoOrderComponent/GRNInfoOrderComponent';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { b2bCustomerService } from "@/app/services/b2bCustomerService";



const PartyLedger = () => {
  const [allB2BOrders, setAllB2BOrders] = useState ([]);
  const { b2bCustomers } = useSelector((state) => state.b2bCustomer);
  const { dropDownB2BCustomerName, dropDownB2BCustomerValue } = useSelector((state) => state.dropdown);
  const [filter, setFilter] = useState("allOrders");
  const [searchText, setSearchText] = useState("");
  const [dayFilter, setDayFilter] = useState("all");
  const sortedOrders = allB2BOrders.sort((a, b) => {
    return new Date(b.updatedAt) - new Date(a.updatedAt);
  });
  const [filteredData, setFilteredData] = useState(sortedOrders);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarType, setSidebarType] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [selectedOrders, setSelectedOrders] = useState ([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const dispatch = useDispatch();


    // Fetch B2B Customers on mount
    useEffect(() => {
      const fetchB2BCustomers = async () => {
        try {
          dispatch(getAllB2BCustomerRequest());
          const response = await b2bCustomerService.getAllB2BCustomers();
          if (response.success) {
            dispatch(getAllB2BCustomerSuccess(response.data));
          } else {
            toast.error("Failed to fetch customers");
          }
        } catch (err) {
          console.error(err);
          toast.error("An error occurred while fetching customers");
        }
      };
  
      fetchB2BCustomers();
    }, [dispatch]);


    useEffect(() => {
        const fetchB2BOrders = async () => {
          if (!dropDownB2BCustomerValue) return; // Prevent API call if value is falsy
      
          try {
            const response = await b2bOrderService.getAllB2BOrderByB2BCustomerId( dropDownB2BCustomerValue );
      
            if (response?.success) {
              setAllB2BOrders(response.data);
            } else {
              toast.error("Failed to fetch orders for the selected B2B customer.");
            }
              console.log("🚀 ~ fetchB2BOrders ~ response.data:", response.data)
          } catch (error) {
            console.error("Error fetching B2B orders:", error);
            toast.error("An error occurred while fetching orders. Please try again.");
          }
        };
      
        fetchB2BOrders();
      }, [dropDownB2BCustomerValue]);
      



  


  const applyFilters = () => {
    let data = allB2BOrders;

    if (filter !== "allOrders") {
      if (filter === "picked") {
        // Include multiple statuses under "Picked Orders"
        data = data.filter((item) =>
          ["picked", "invoiced"].includes(item.status)
        );
      } 
      else if (filter === "delivered") {
        // Include multiple statuses under "Delivered Orders"
        data = data.filter((item) =>
          ["delivered","grn_entered" ].includes(item.status)
        );
      } 
      else{
        data = data.filter((item) => item.status === filter);
      }
      
    }

    data = filterByDate(data, dayFilter, startDate, endDate);

    data = data.filter((item) =>
      searchKeys.some((key) =>
        searchNested(item[key], searchText.toLowerCase(), key)
      )
    );

    setFilteredData(data);
  };

  useEffect(() => {
    applyFilters();
  }, [filter, searchText, dayFilter, allB2BOrders, startDate, endDate]);

  


  useEffect(() => {
    setFilteredData(sortedOrders);
  }, [sortedOrders]);

  const currentDateAndFileName = `Custom_Order_${moment().format('DD-MMM-YYYY')}`;

  // Convert data to CSV
      const convertToCSV = (data, selectedOrders) => {
        const headers = [
          'WH', 'PO Date', 'Appointment Date','PO Expiry Date', 'Punch Date','Invoice date', 'Dispatch Date', 'Delivery Date',
          'Voucher Type', 'PO Number/Order No', 'Order Status',  'Order Remarks', 'Platform/Order Type', 'Invoice Number', 'Total Invoice Value', 'Customer', 'Customer GST','Channel',
          'State/Zone', 'City', 'Account Managers', 'Distinct Sku - Ordered', 'Qty ordered (case units)',
          'Qty ordered (in units)', 'Distinct Sku - Approved', 'Qty Approved (case units)',
          'Qty Approved (in units)', 'Distinct Sku - Fulfilled/ Dispatched', 'Qty Fulfilled / Dispatched (case units)',
          'Qty Fulfilled / Dispatched (in units)', 'Distinct Sku - GRN',
          'Qty GRN (in units)',
          
          
           
        'Short Fulfilled Quantity (SKU)', 'Short Fulfilled Quantity (Units)',
        'Short GRN Quantity (SKU)', 'Short GRN Quantity (Units)',
        
          'Ordered vs Approved % (SKU)', 'Ordered vs Approved % (Qty)',
          'Approved vs Fulfilled % (SKU)', 'Approved vs Fulfilled % (Qty)',
          'Ordered vs Fulfilled % (SKU)', 'Ordered vs Fulfilled % (Qty)',
          'Fulfilled vs GRN % (SKU)', 'Fulfilled vs GRN % (Qty)',
          'Ordered vs GRN % (SKU)', 'Ordered vs GRN % (Qty)',
    
          'Approval Remarks', 'WH/Fulfillment Remarks', 'GRN Remarks', 
         'Dispatch Mode', 'EDD Date', 'Carrier*', 'Tracking number', 'Box Count',
          'Tracking Link',
        ];
      
        const escapeCSVValue = (value) => {
          if (value === undefined || value === null) return '';
          const stringValue = String(value);
          return `"${stringValue.replace(/"/g, '""')}"`;
        };
      
        const formatDateTime = (dateString) => {
          if (!dateString) return '';
          const parsedDate = moment(dateString, [
            "M/D/YY H:mm",
            "DD/MM/YY",
            "DD/MM/YYYY",
            "DD/MM/YYYY HH:mm:ss", 
            "YYYY-MM-DD", 
            "YYYY/MM/DD", 
            "MM/DD/YYYY", 
            "M/D/YYYY H:mm", 
            "M/D/YYYY h:mm A", "x", "X", moment.ISO_8601
          ]);
          return parsedDate.isValid() ? parsedDate.format("DD MMM YYYY HH:mm:ss") : 'Invalid Date';
        };
      
        // const filteredData = selectedOrders.length > 0
        //   ? data.filter((order) => selectedOrders.includes(order._id))
        //   : data;
      
        const rows = filteredData.map((order) => {
          let totalQty = 0, approvedQty = 0, fulfilledQty = 0, grnQty = 0;
          let totalQtyUnits = 0, approvedQtyUnits = 0, fulfilledQtyUnits = 0, grnQtyUnits = 0;
          let skuOrdered = 0, skuApproved = 0, skuFulfilled = 0, skuGRN = 0;
          let approvedReasons = new Set();
          let fulfilledReasons = new Set();
          let grnReasons = new Set ();
          (order?.listOfProducts || []).forEach(product => {
            const caseSize = product?._id?.case_size || 1;
      
            // Basic counts
            skuOrdered++;
            if (product?.approvedQuantity) skuApproved++;
            if (product?.fulfilledQuantity) skuFulfilled++;
            if (product?.grnQuantity) skuGRN++;
      
            // Totals
            const qty = product?.quantity || 0;
            const approved = product?.approvedQuantity || 0;
            const fulfilled = product?.fulfilledQuantity || 0;
            const grn = product?.grnQuantity || 0;
      
            totalQty += qty;
            approvedQty += approved;
            fulfilledQty += fulfilled;
            grnQty += grn;
      
            totalQtyUnits += qty * caseSize;
            approvedQtyUnits += approved * caseSize;
            fulfilledQtyUnits += fulfilled * caseSize;
    
                // Collect unique reasons
                if (product?.approvedQuantityChangeReason) {
                  approvedReasons.add(product.approvedQuantityChangeReason);
                }
                if (product?.fulfilledQuantityChangeReason) {
                  fulfilledReasons.add(product.fulfilledQuantityChangeReason);
                }
                if (product?.grnQuantityChangeReason) {
                  grnReasons.add(product.grnQuantityChangeReason);
                }
    
          });
      
          const percent = (num, denom) => denom > 0 ? ((num / denom) * 100).toFixed(2) + '%' : 'N/A';
      
          return [
            '', // WH
            escapeCSVValue(formatDateTime(order?.orderReceivedDate)),
            escapeCSVValue(formatDateTime(order?.appointmentDate)),
            escapeCSVValue(formatDateTime(order?.poExpiryDate)),
            escapeCSVValue(formatDateTime(order?.createdAt)),
            escapeCSVValue(formatDateTime(order?.invoiceDate)),
            escapeCSVValue(formatDateTime(order?.actualDispatchDate)),
            escapeCSVValue(formatDateTime(order?.deliveryDate)),
            escapeCSVValue(order?.documentType === 'delivery-note' ? 'Delivery Note' : 'Tax Invoice'),
            escapeCSVValue(order?.orderId),
            escapeCSVValue(order?.status),
            escapeCSVValue(order?.remarks),
            escapeCSVValue(order?.orderType),
            escapeCSVValue(order?.invoiceId),
            escapeCSVValue(order?.irnDetails?.irnRequestBody?.ValDtls?.TotInvVal),
            escapeCSVValue(order?.customerID?.name),
            escapeCSVValue(order?.customerID?.gstNumber),
            '',
            '',
            '',
            '',
            escapeCSVValue(skuOrdered),
            escapeCSVValue(totalQty),
            escapeCSVValue(totalQtyUnits),
            escapeCSVValue(skuApproved),
            escapeCSVValue(approvedQty),
            escapeCSVValue(approvedQtyUnits),
            escapeCSVValue(skuFulfilled),
            escapeCSVValue(fulfilledQty),
            escapeCSVValue(fulfilledQtyUnits),
            escapeCSVValue(skuGRN),
            escapeCSVValue(grnQty),
      
          escapeCSVValue(skuApproved - skuFulfilled), escapeCSVValue(approvedQtyUnits - fulfilledQtyUnits),
          escapeCSVValue(skuFulfilled - skuGRN), escapeCSVValue(fulfilledQtyUnits - grnQty),
          
          percent(skuApproved, skuOrdered), percent(approvedQtyUnits, totalQtyUnits),
          percent(skuFulfilled, skuApproved), percent(fulfilledQtyUnits, approvedQtyUnits),
          percent(skuFulfilled, skuOrdered), percent(fulfilledQtyUnits, totalQtyUnits),
          percent(skuGRN, skuFulfilled), percent(grnQty, fulfilledQtyUnits),
          percent(skuGRN, skuOrdered), percent(grnQty, totalQtyUnits),
    
      
          escapeCSVValue(Array.from(approvedReasons).join(', ')), 
          escapeCSVValue(Array.from(fulfilledReasons).join(', ')),
          escapeCSVValue(Array.from(grnReasons).join(', ')), // WH / GRN Remarks
          
            escapeCSVValue(formatDateTime(order?.deliveryDate)),
            escapeCSVValue(order?.modeOfTransport),
            escapeCSVValue(order?.shippingPartner),
            escapeCSVValue(order?.awbNumber),
            '', '', 
          ].join(',');
        });
      
        const csvString = [headers.join(','), ...rows].join('\n');
  
    // ✅ Blob method for proper encoding & large data support
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'sku-wise-orders.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
      };
  

  
  const convertToCSVSkuWise = (data, selectedOrders) => {
    const headers = [
      'WH', 'PO Date', 'PO Expiry Date', 'Punch Date', 'Invoice date', 'Dispatch Date', 'Delivery Date',
      'Voucher Type', 'PO Number', 'Invoice Number', 'Taxable Invoice Value', 'Total Invoice Amount With Tax','Customer', 'Customer GST','Shipping Address', 'Mode of Transport',
      'AWB Number', 'Order ID', 'Order Type', 'Order Status', 'SKU Code', 'SKU Description',
      'Order Qty (Case Units)', 'Approved Qty  (Case Units)' , 'Fulfilled/Dispatched Qty  (Case Units)',
      'Order Qty (in Units)', 'Approved Qty (in Units)', 'Fulfilled/Dispatched Qty (in Units)',
      'GRN Qty (in Units)', 'Approval Remarks', 'WH/Fulfillment Remarks' , 'GRN Remarks'
    ];
  
    const escapeCSVValue = (value) => {
      if (value === undefined || value === null) return '';
      const stringValue = String(value);
      return `"${stringValue.replace(/"/g, '""')}"`; 
    };
  
    const formatDateTime = (dateString) => {
      if (!dateString) return '';
      const parsedDate = moment(dateString, [
        "M/D/YY H:mm",  
        "DD/MM/YY",
        "DD/MM/YYYY",
        "DD/MM/YYYY HH:mm:ss", 
        "YYYY-MM-DD",
        "YYYY/MM/DD",
        "MM/DD/YYYY",
        "M/D/YYYY H:mm",
        "M/D/YYYY h:mm A",
        "x", "X",
        moment.ISO_8601
      ]);
      return parsedDate.isValid() ? parsedDate.format("DD MMM YYYY HH:mm:ss") : 'Invalid Date';
    };
  
    // const filteredData = selectedOrders.length > 0
    //   ? data.filter((order) => selectedOrders.includes(order._id))
    //   : data;
  
    const rows = filteredData.flatMap((order) => {
      return order?.listOfProducts?.map((product) => {
        const caseSize = product?._id?.case_size || 1;
        const productName = product?._id?.product_name || '';
  
        const orderQtyInUnits = (product?.quantity ?? 0) * (caseSize ?? 1);
        const approvedQtyInUnits = (product?.approvedQuantity ?? 0) * (caseSize ?? 1);
        const fulfilledQtyInUnits = (product?.fulfilledQuantity ?? 0) * (caseSize ?? 1);
        
  
        return [
          escapeCSVValue(''), // WH
          escapeCSVValue(formatDateTime(order?.orderReceivedDate)), // PO Date
          escapeCSVValue(formatDateTime(order?.poExpiryDate)), // PO Expiry Date
          escapeCSVValue(formatDateTime(order?.createdAt)), // Punch Date
          escapeCSVValue(formatDateTime(order?.invoiceDate)), // Invoice Date
          escapeCSVValue(formatDateTime(order?.actualDispatchDate)), // Dispatch Date
          escapeCSVValue(formatDateTime(order?.deliveryDate)),
          escapeCSVValue(order?.documentType === 'delivery-note' ? 'Delivery Note' : 'Tax Invoice'),
          escapeCSVValue(order?.orderId), // PO Number
          escapeCSVValue(order?.invoiceId || ' '), // Invoice Number
          escapeCSVValue(order?.irnDetails?.irnRequestBody?.ValDtls?.AssVal || 'N/A'), // Taxable Value
          escapeCSVValue(order?.irnDetails?.irnRequestBody?.ValDtls?.TotInvVal || 'N/A'), // Total Amount With Tax
          escapeCSVValue(order?.customerID?.name), // Customer
          escapeCSVValue(order?.customerID?.gstNumber),
          escapeCSVValue(order?.shippingAddress || order?.customerID?.shipping_address), // Shipping Address
          escapeCSVValue(order?.modeOfTransport), // Mode of Transport
          escapeCSVValue(order?.awbNumber), // AWB Number
          escapeCSVValue(order?.orderId), // Order ID
          escapeCSVValue(order?.orderType), // Order Type
          escapeCSVValue(order?.status), // Order Status
          escapeCSVValue(product?.skuCode), // SKU Code
          escapeCSVValue(productName ||''), // SKU Description
          escapeCSVValue(product?.quantity), // Order Qty
          escapeCSVValue(product?.approvedQuantity), // Approved Qty
          escapeCSVValue(product?.fulfilledQuantity), // Fulfilled/Dispatched Qty
          escapeCSVValue(orderQtyInUnits), // Order Qty (in Units)
          escapeCSVValue(approvedQtyInUnits), // Approved Qty (in Units)
          escapeCSVValue(fulfilledQtyInUnits), // Fulfilled/Dispatched Qty (in Units)
          escapeCSVValue(product?.grnQuantity), // GRN Qty
          escapeCSVValue(product?.approvedQuantityChangeReason), // Approval Remarks
          escapeCSVValue(product?.fulfilledQuantityChangeReason),
          escapeCSVValue(product?.grnQuantityChangeReason) // WH/Fulfillment Remarks
        ].join(',');
      });
    });
  
    const csvString = [headers.join(','), ...rows].join('\n');
  
    // ✅ Blob method for proper encoding & large data support
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'sku-wise.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };
  
  
  
  const searchKeys = [
    "orderId",
    "customerID",
    "shippingAddress",
    "orderType"
  ];

  const headings = {
    checkbox: {
      label: "Select",
      isCheckbox: true,
      onChange: (row) => handleCheckboxChange(row._id),
      isSticky: false,
    },
    orderId: {
      label: "Order ID",
      renderCell: (row) => row?.orderId || "N/A",
      isSticky: false,
    },
    customerName: {
      label: "Customer Name",
      renderCell: (row) => row?.customerID?.name || "N/A",
      isSticky: false,
    },
    status: {
      label: "Status",
      renderCell: (row) => <StatusComponent status={row?.status} /> || "N/A",
      isSticky: false,
    },
    orderType: {
      label: "Order Type",
      renderCell: (row) => row?.orderType || "N/A",
      isSticky: false,
    },
    shippingAddress: {
      label: "Shipping Address",
      renderCell: (row) =>
        (row?.shippingAddress || row?.customerID?.shipping_address)?.slice(0, 25) + "..." || "N/A",
      isSticky: false,
    },
    distinctProducts: {
      label: "Distinct Products",
      renderCell: (row) => row?.listOfProducts?.length || "N/A",
      isSticky: false,
    },
    fulfilledProducts : {
      label: "Fulfilled Products",
      renderCell: (row) =>
        row?.listOfProducts?.reduce(
          (acc, product) => 
            (product.fulfilledQuantity !== undefined && product.fulfilledQuantity >= 1) ? acc + 1 : acc,
          0
        ) || "N/A",
      isSticky: false,
    },
    remarks: {
      label: "Remarks",
      renderCell: (row) => row?.remarks || "N/A",
      isSticky: false,
    },
    action: {
      label: "Action",
      renderCell: (row) => (
        <ActionDropdown order={row} actions={generateOrderActions(row)} />
      ),
      isSticky: true,
      stickyClassHeader: stickyActionColumnClassname,
      stickyClassRow: stickyActionRowClassname,
    },
  };


  const generateOrderActions = (order) => {
    return [
      {
        label: "View Order Particulars",
        condition: () => true,
        action: () => openSidebar("viewOrderParticular", order),
      },


    ];
  };

  const openSidebar = (type, order) => {
    setSidebarType(type);
    setSelectedOrder(order);
    setIsSidebarOpen(true);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
    setSidebarType(null);
    setSelectedOrder(null);
  };
  

  const filterOptions = [
    { value: "allOrders", label: "All Orders" },
    { value: "open", label: "Pending Orders" },
    { value: "approved", label: "Approved Orders" },
    { value: "picked", label: "Picked Orders" },
    { value: "in_transit", label: "Dispatched Orders" },
    { value: "delivered", label: "Delivered Orders" },
    { value: "rto", label: "RTO Orders" },
  ];

  const handleDayFilterChange = (event) => {
    setDayFilter(event.target.value);
  };

 const handleCheckboxChange = (orderInternalId) => {
  
    // Toggle the orderID in the selected Orders list
    setSelectedOrders((prevSelectedOrders) =>
      prevSelectedOrders.includes(orderInternalId)
        ? prevSelectedOrders.filter((id) => id !== orderInternalId)
        : [...prevSelectedOrders, orderInternalId]
    );
    console.log ("Checking ", selectedOrders);
  };

  

return (
  <>

    {/* Select B2B Customers */}
    <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">
          Select B2B Customer <span className="text-[#9CA3AF] ml-[2px]">*</span>
        </label>
        <B2BCustomerDropdown
          id="customerDropdown"
          bgColor={"#F8F6F2"}
          options={b2bCustomers}
        />
        {/* {errors.customers && (
          <p className="text-red-500 text-xs">{errors.customers}</p>
        )} */}
      </div>
    <TableFilterBarWithDatePicker
      filter={filter}
      setFilter={setFilter}
      searchText={searchText}
      setSearchText={setSearchText}
      convertToCSV={convertToCSV}
      convertToCSVSkuWise={convertToCSVSkuWise}
      allPO={filteredData}
      selectedRows={selectedOrders}
      filterOptions={filterOptions}
      dayFilter={dayFilter}
      handleDayFilterChange={handleDayFilterChange}
      startDate={startDate}
      setStartDate={setStartDate}
      endDate={endDate}
      setEndDate={setEndDate}
    />

    <DynamicTableWithoutAction headings={headings} rows={filteredData} />
    {sidebarType === "viewOrderParticular" ? (
  <BigRightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
    <ViewOrderParticular
      selectedOrder={selectedOrder}
      handleCancel={closeSidebar}
    />
  </BigRightSidebar>
) : (
  <RightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
    {sidebarType === "editOrder" && (
      <EditOrder selectedOrder={selectedOrder} handleCancel={closeSidebar} />
    )}
    {sidebarType === "approveOrder" && (
      <ApproveOrderComponent
        selectedOrderOriginal={selectedOrder}
        handleCancel={closeSidebar}
      />
    )}
    {sidebarType === "enterShippingDetails" && (
      <ReadyToShipOrderComponent
        selectedOrder={selectedOrder}
        handleCancel={closeSidebar}
      />
    )}
    {sidebarType === "enterInvoiceInfo" && (
      <InvoiceInfoOrderComponent
        selectedOrder={selectedOrder}
        handleCancel={closeSidebar}
      />
    )}
    {sidebarType === "enterDispatchInfo" && (
      <DispatchInfoOrderComponent
        selectedOrder={selectedOrder}
        handleCancel={closeSidebar}
      />
    )}
    {sidebarType === "enterDeliveryInfo" && (
      <DeliveryInfoOrderComponent
        selectedOrder={selectedOrder}
        handleCancel={closeSidebar}
      />
    )}
    {sidebarType === "enterGRNInfo" && (
      <GRNInfoOrderComponent
        selectedOrderOriginal={selectedOrder}
        handleCancel={closeSidebar}
      />
    )}
  </RightSidebar>
)}

 
  </>
);
};

export default PartyLedger;

