'use client'
import React, { use, useEffect, useState } from "react";
import Input from "../Input/Input";
import Button from "../Button/Button";
import CustomDatePicker from "../DatePicker/DatePicker";
import dayjs from "dayjs";
import {
  getAllProductByB2BCustomerIdRequest,
  getAllProductByB2BCustomerIdSuccess,
  getAllProductByB2BCustomerIdFailure,
} from "../../Actions/productActions";
import {
  getAllB2BCustomerRequest,
  getAllB2BCustomerSuccess,
  getAllB2BCustomerFailure,
} from "../../Actions/b2bCustomerActions";
import { productServices } from "@/app/services/productService";
import { b2bCustomerService } from "@/app/services/b2bCustomerService";
import B2BCustomerDropdown from "../B2BCustomerDropdown/B2BCustomerDropdown";
import ProductDropdown from "../ProductDropdown/ProductDropdown";
import { useDispatch, useSelector } from "react-redux";
import "./CreateB2BOrderForm.css";
import { b2bOrderService } from "@/app/services/b2bOrderService";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; 
import {
  SecondaryButton,
  PrimaryButton,
} from "../ButtonComponent/ButtonComponent";


const CreateB2BOrderForm = ({onCancel}) => {
  const { b2bCustomers } = useSelector((state) => state.b2bCustomer);
  const { allProductsByB2BCustomerId } = useSelector((state) => state.product);
  const { dropDownProductValue, dropdownProductName, dropDownB2BCustomerValue } = useSelector(
    (state) => state.dropdown
  );

  const [selectedDate, setSelectedDate] = useState();

  const [scheduledDispatchDate, setScheduledDispatchDate] = useState();
  const [formDisabled, setFormDisabled] = useState(false);
  

  const [formData, setFormData] = useState({
    orderReceivedDate: dayjs().startOf("day").format("YYYY-MM-DD HH:mm:ss"),
    scheduledDispatchDate: dayjs().startOf("day").format("YYYY-MM-DD HH:mm:ss"), 
    expectedDeliveryDate: dayjs().startOf("day").format("YYYY-MM-DD HH:mm:ss"),
    orderId: "",
    orderType: "",
    documentType:"",
    shippingAddress: "",
    modeOfTransport: "",
    remarks: "",
    customerID: "",
    listOfProducts: [],
  });
  const [productQuantity, setProductQuantity] = useState(null);
  const [errors, setErrors] = useState({});
  const [selectedOrderType, setSelectedOrderType] = useState("");
  const [selectedDocumentType, setSelectedDocumentType] = useState("");

  const dispatch = useDispatch();

  const handleDateChange = (newDate) => {
    const adjustedDate = newDate.clone().startOf("day");
    const formattedDate = adjustedDate.format("YYYY-MM-DD HH:mm:ss");
    setSelectedDate(formattedDate);
    setFormData((prevFormData) => ({
      ...prevFormData,
      orderReceivedDate: formattedDate,
    }));
  };

  const handleScheduledDispatchDateChange = (newDate) => {
    const adjustedDate = newDate.clone().startOf("day");
    const formattedDate = adjustedDate.format("YYYY-MM-DD HH:mm:ss");
    setScheduledDispatchDate(formattedDate);
    setFormData((prevFormData) => ({
      ...prevFormData,
      scheduledDispatchDate: formattedDate,
    }));
  };

  const handleExpectedDeliveryDateChange = (newDate) => {
    const adjustedDate = newDate.clone().startOf("day");
    const formattedDate = adjustedDate.format("YYYY-MM-DD HH:mm:ss");
    setScheduledDispatchDate(formattedDate);
    setFormData((prevFormData) => ({
      ...prevFormData,
      expectedDeliveryDate: formattedDate,
    }));
  };
  

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handleOrderTypeChange = (e) => {
    const orderType = e.target.value;
    setSelectedOrderType(orderType);
    setFormData((prevFormData) => ({
      ...prevFormData,
      orderType: orderType,
    }));
  };

  const handleDocumentTypeChange = (e) => {
    const documentType = e.target.value;
    setSelectedDocumentType(documentType);
    setFormData((prevFormData) => ({
      ...prevFormData,
      documentType: documentType,
    }));
  };

 


  const handleRemoveProductsFromList = (index) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      listOfProducts: prevFormData.listOfProducts.filter((_, i) => i !== index),
    }));
  };

  const handleAddProduct = () => {
    if (!dropDownProductValue || !productQuantity) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        listOfProducts: "Please select a product and enter quantity.",
      }));
      return;
    }
  
    // Check if the product is already in the list
    const isProductAlreadyAdded = formData.listOfProducts.some(
      (product) => product.skuCode === dropDownProductValue
    );
  
    if (isProductAlreadyAdded) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        listOfProducts: "This product is already added.",
      }));
      return;
    }
  
    // Add the new product if it doesn't exist
    const newProduct = {
      skuCode: dropDownProductValue,
      quantity: productQuantity,
      productName: dropdownProductName,
    };
  
    setFormData((prevFormData) => ({
      ...prevFormData,
      listOfProducts: [...prevFormData.listOfProducts, newProduct],
    }));
  
    // Reset input field and error
    setProductQuantity("");
    setErrors((prevErrors) => ({
      ...prevErrors,
      listOfProducts: "",
    }));
  };
  




  useEffect(() => {
    if (dropDownB2BCustomerValue) {
      setFormData((prevFormData) => ({
        ...prevFormData,
        customerID: dropDownB2BCustomerValue,
      }));
      console.log("Customer ID:", dropDownB2BCustomerValue);
    }
  }, [dropDownB2BCustomerValue]);
 

  const getAllB2BCustomers = async () => {
    try {
      dispatch(getAllB2BCustomerRequest());

      const response = await b2bCustomerService.getAllB2BCustomers();
      if (response.success === true) {
        dispatch(getAllB2BCustomerSuccess(response.data));
      }
    } catch (err) {
      console.log(err);
      dispatch(getAllB2BCustomerFailure());
    }
  };

  const getProductByB2BCustomerID= async () => {
    dispatch(getAllProductByB2BCustomerIdSuccess([]));
    dispatch(getAllProductByB2BCustomerIdRequest());
    try {
      dispatch(getAllProductByB2BCustomerIdRequest());
      const response = await productServices.getAllProductsByB2BCustomerId(
        dropDownB2BCustomerValue);
      if (response.success === true) {
        dispatch(getAllProductByB2BCustomerIdSuccess(response.data));
      }
    } catch (err) {
      console.log(err);
      dispatch(getAllProductByB2BCustomerIdFailure());
    }
  };

  useEffect(() => {
    getAllB2BCustomers();
  }, []);

  useEffect(() => {
    getProductByB2BCustomerID();
  }, [dropDownB2BCustomerValue]);


  const validateForm = () => {
    const newErrors = {};
    if (!formData.orderReceivedDate) newErrors.orderReceivedDate = "Order Received date is required.";
    if (!formData.scheduledDispatchDate) newErrors.scheduledDispatchDate = "Scheduled dispatch date is required."; 
    if (!formData.expectedDeliveryDate) newErrors.expectedDeliveryDate = "Expected delivery date is required.";
    if (!formData.orderId) newErrors.orderId = "Order ID is required.";
    if (!formData.orderType) newErrors.orderType = "Order Type selection is required.";
    if (!formData.documentType) newErrors.documentType = "Document Type selection is required.";
    if (!formData.customerID) newErrors.customerID = "Customer ID is required.";
    if (formData.listOfProducts.length === 0)
      newErrors.listOfProducts = "At least one product must be added.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const onFormSubmit = async () => {
    console.log("Form submitted"); // Check if this logs
    if (!validateForm()) return;
    try {
console.log("Form submitted and form data is", formData); 
     
      const response = await b2bOrderService.createB2BOrder(formData);
      if (response && response.success) {
        toast.success('B2B Order Created Successfully', {
          autoClose: 1500,
          onClose: () => window.location.reload(),
        });
        setFormDisabled(true);
      } else {
        toast.error('Failed to create order: ' + (response?.message || 'Unknown error'), {
          autoClose: 5000,
          onClose: () => window.location.reload(),
        });
        setFormDisabled(true);
      }
    } catch (err) {
      toast.error('Failed to create order: ' + err, { autoClose: 3000 }
      );
      window.location.reload();
    }
  };
  

  return (
    <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <ToastContainer position="bottom-center"/>
        <h2 className="text-base font-semibold text-[#111928] mb-1">
          Raise B2B Order
        </h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
        Create a Business To Businees Order.
        </p>
      <div className="flex flex-col my-6">
    
        <CustomDatePicker
         onDateChange={handleDateChange}
         label="Order Received Date"
         className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-[1vw] font-medium"
        />
        {errors.orderReceivedDate && (
          <p className="text-red-500 text-xs">{errors.orderReceivedDate}</p>
        )}
      </div>
    
    {/* Scheduled Dispatch Date Picker */}
    <div className="flex flex-col my-6">
      <CustomDatePicker
        onDateChange={handleScheduledDispatchDateChange}
        label="Scheduled Dispatch Date" 
        className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-[1vw] font-medium"
      />
      {errors.scheduledDispatchDate && (
        <p className="text-red-500 text-xs">{errors.scheduledDispatchDate}
        </p>
      )}
    </div>

     {/* Scheduled Delivery  Date Picker */}
     <div className="flex flex-col my-6">
      <CustomDatePicker
        onDateChange={handleExpectedDeliveryDateChange} 
        label="Expected Delivery  Date"
        className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-[1vw] font-medium" 
      />
      {errors.scheduledDispatchDate && (
        <p className="text-red-500 text-xs">{errors.expectedDeliveryDate}
        </p>
      )}
    </div>

    <div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Order ID / PO Number
    <span className="text-[#9CA3AF] ml-[2px]">*</span>
  </label>
  <Input
    bgColor={"bg-[#F8F6F2]"}
    radius={"rounded-lg"}
    height={"h-[3.5vw] min-h-[3.5vh]"}
    padding={"p-[1vw]"}
    type={"text"}
    color={"text-[#838481]"}
    textSize={"text-[1vw]"}
    fontWeight={"font-medium"}
    name="orderId"
    value={formData.orderId}
    onChange={handleChange}
  />
  {errors.orderId && (
    <p className="text-red-500 text-xs">{errors.orderId}</p>
  )}
</div>



  
<div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Order Type
    <span className="text-[#9CA3AF] ml-[2px]">*</span>
  </label>
  <select
    className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-[1vw] font-medium"
    value={selectedOrderType}
    onChange={handleOrderTypeChange}
  >
    <option value="">Select Order Type</option>
    <option value="Q-Commerce">Q-Commerce</option>
    <option value="General-Trade">General Trade</option>
    <option value="Modern-Trade">Modern Trade</option>
    <option value="Institutional">Institutional</option>
    <option value="FBA">FBA</option>
    <option value="ARIPL">ARIPL</option>
    <option value="Head Office - FOC">Head Office - FOC</option>

  </select>
  {errors.orderType && (
    <p className="text-red-500 text-xs">{errors.orderType}</p>
  )}
</div>

<div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Document Type
    <span className="text-[#9CA3AF] ml-[2px]">*</span>
  </label>
  <select
    className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-[1vw] font-medium"
    value={selectedDocumentType}
    onChange={handleDocumentTypeChange}
  >
    <option value="">Select Document Type</option>
    <option value="invoice">Invoice</option>
    <option value="delivery-note">Delivery Note</option>
  </select>
  {errors.documentType && (
    <p className="text-red-500 text-xs">{errors.documentType}</p>
  )}
</div>



<div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Shipping Address
  </label>
  <Input
    bgColor={"bg-[#F8F6F2]"}
    radius={"rounded-lg"}
    height={"h-[3.5vw] min-h-[3.5vh]"}
    padding={"p-[1vw]"}
    type={"text"}
    color={"text-[#838481]"}
    textSize={"text-[1vw]"}
    fontWeight={"font-medium"}
    name="shippingAddress"
    value={formData.shippingAddress}
    onChange={handleChange}
  />
  {errors.shippingAddress && (
    <p className="text-red-500 text-xs">{errors.shippingAddress}</p>
  )}
</div>

<div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Mode of Transport
  </label>
  <Input
    bgColor={"bg-[#F8F6F2]"}
    radius={"rounded-lg"}
    height={"h-[3.5vw] min-h-[3.5vh]"}
    padding={"p-[1vw]"}
    type={"text"}
    color={"text-[#838481]"}
    textSize={"text-[1vw]"}
    fontWeight={"font-medium"}
    name="modeOfTransport"
    value={formData.modeOfTransport}
    onChange={handleChange}
  />
  {errors.modeOfTransport && (
    <p className="text-red-500 text-xs">{errors.modeOfTransport}</p>
  )}
</div>


  

<div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Remarks
  </label>
  <Input
    bgColor={"bg-[#F8F6F2]"}
    radius={"rounded-lg"}
    height={"h-[3.5vw] min-h-[3.5vh]"}
    padding={"p-[1vw]"}
    type={"text"}
    color={"text-[#838481]"}
    textSize={"text-[1vw]"}
    fontWeight={"font-medium"}
    name="remarks"
    value={formData.remarks}
    onChange={handleChange}
  />
  {errors.remarks && (
    <p className="text-red-500 text-xs">{errors.remarks}</p>
  )}
</div>

      <div className="flex flex-col mb-6 ">
        <label className="block text-[#111928] text-sm font-medium mb-1" >Select Customer    <span className="text-[#9CA3AF] ml-[2px]">*</span> </label>
        <B2BCustomerDropdown
          bgColor={"#F8F6F2"}
          options={b2bCustomers}
        />
      </div>
      {errors.customerID && (
          <p className="text-red-500 text-xs">{errors.customerID}</p>
        )}



      <label className="block text-[#111928] text-sm font-medium mb-1">List Of Products</label>
      <div className="flex flex-col p-4 border-2 border-[#F8F6F2] rounded-lg bg-white">
     
        <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">Select Product    <span className="text-[#9CA3AF] ml-[2px]">*</span> </label>
          <ProductDropdown
            name="product_id"
            bgColor={"#F8F6F2"}
            options={allProductsByB2BCustomerId}
          />
        </div>
        <div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Quantity
    <span className="text-[#9CA3AF] ml-[2px]">*</span>
  </label>
  <Input
    bgColor={"bg-[#F8F6F2]"}
    radius={"rounded-lg"}
    height={"h-[3.5vw] min-h-[3.5vh]"}
    padding={"p-[1vw]"}
    type={"number"}
    color={"text-[#838481]"}
    textSize={"text-[1vw]"}
    fontWeight={"font-medium"}
    name="quantity"
    placeholder={"Enter Quantity here"}
    value={productQuantity}
    onChange={(e) => setProductQuantity(e.target.value)}
  />
</div>


        <div  className="flex-1">
<PrimaryButton
 title="Add Product"
 onClick = {handleAddProduct}
  size='full'
              bgColor="bg-primary"
/>
        </div>
        {errors.listOfProducts && (
          <p className="text-red-500 text-xs">{errors.listOfProducts}</p>
        )}

<div className="mt-2">
  {formData.listOfProducts.length > 0 && <label>Products:</label>}

  <ul className="flex flex-wrap gap-4">
    {formData.listOfProducts.map((product, index) => (
      <li
        key={index}
        className="awb-number border bg-[#F8F6F2] text-black rounded-lg p-2 text-sm text-start flex-[0_0_calc(45%-0.5rem)]"
        onClick={() => handleRemoveProductsFromList(index)}
      >
        <span className="remove-text text-xs font-semibold">
          Remove
        </span>
        <div className="flex flex-col">
          <span className="number px-3 text-black">
            Product Name: {product?.productName}
          </span>
          <span className="number px-3 text-black">
            Product Quantity: {product?.quantity}
          </span>
        </div>
      </li>
    ))}
  </ul>
</div>

      </div>

      <div className="absolute bottom-0 left-0 w-full border border-t-stroke  bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" size='full' onClick={onCancel} />
          </div>
          <div className="flex-1">
            <PrimaryButton
              title="Raise PO"
              onClick={onFormSubmit} 
              size='full'
              bgColor="bg-primary"
            />
          </div>
        </div>
      </div>

      {formDisabled && (
        <div
          className="fixed top-0 left-0 w-full h-full bg-gray-400 opacity-50 z-50"
          style={{ zIndex: 1000 }}
        />
      )}
      
    </div>
  );
};

export default CreateB2BOrderForm;

