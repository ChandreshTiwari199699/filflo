"use client";
import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Input from "@/app/components/Input/Input";
import { PrimaryButton, SecondaryButton } from "@/app/components/ButtonComponent/ButtonComponent";
import { b2bOrderService } from "@/app/services/b2bOrderService";

const DeliveryInfoOrderComponent = ({ selectedOrder, handleCancel }) => {
  const [processOrderData, setProcessOrderData] = useState({
    status: selectedOrder?.status || "",
    orderInternalId: selectedOrder?._id || "",
    deliveryDate: selectedOrder?.deliveryDate || "",
    proofOfDelivery: selectedOrder?.proofOfDelivery || "",
    returnInfo: selectedOrder?.returnInfo || "",
  });

  const [errors, setErrors] = useState({});
  const [actionType, setActionType] = useState("");

  const handleProcessChange = (e) => {
    const { name, value } = e.target;
    setProcessOrderData((prev) => ({ ...prev, [name]: value }));
  };

  const handleInTransitSave = async (e) => {
    e.preventDefault();

    // Validate if action type is selected
  if (!actionType) {
    setErrors((prev) => ({
      ...prev,
      actionType: "Action type is required.",
    }));
    return;
  } else {
    setErrors((prev) => {
      const { actionType, ...rest } = prev; // Remove the actionType error if any
      return rest;
    });
  }

    if (actionType === "delivery") {
      const { deliveryDate, proofOfDelivery } = processOrderData;

      const newErrors = {};
      if (!deliveryDate) newErrors.deliveryDate = "Delivery Date is required.";
      // if (!proofOfDelivery)
      //   newErrors.proofOfDelivery = "Proof of Delivery must be an image file.";

      if (Object.keys(newErrors).length > 0) {
        setErrors(newErrors);
        return;
      }

      try {
        const updatedData = {
          ...processOrderData,
          status: "delivered",
        };

        const result = await b2bOrderService.editB2BOrderByOrderInternalId(updatedData);

        if (result.success) {
          toast.success("Delivery details saved successfully!", {
            autoClose: 1500,
            onClose: () => {
              window.location.reload();
            },
          });
        } else {
          toast.error(`Failed to update order: ${result.error}`);
        }
      } catch (error) {
        toast.error("An unexpected error occurred. Please try again.");
        console.error("Error updating delivery details:", error);
      }
    } else if (actionType === "return") {
      if (!processOrderData.returnInfo) {
        setErrors((prev) => ({
          ...prev,
          returnInfo: "Please enter return info.",
        }));
        return;
      }

      try {
        const updatedData = {
          ...processOrderData,
          status: "rto", // Status change to "Return to Origin"
        };

        const result = await b2bOrderService.editB2BOrderByOrderInternalId(updatedData);

        if (result.success) {
          toast.success("Return info saved successfully!", {
            autoClose: 1500,
            onClose: () => {
              window.location.reload();
            },
          });
        } else {
          toast.error(`Failed to update return info: ${result.error}`);
        }
      } catch (error) {
        toast.error("An unexpected error occurred. Please try again.");
        console.error("Error saving return info:", error);
      }
    }
  };

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <ToastContainer position="bottom-center" />
        <h2 className="text-base font-semibold text-[#111928] mb-1">Delivery Information</h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          Please choose the appropriate action (Delivery or Return) and provide the required details.
        </p>

        {processOrderData.status === "in_transit" && (
          <>
            {/* Action Type Dropdown */}
            <div className="flex flex-col mb-6">
              <label className="block text-[#111928] text-sm font-medium mb-1">Choose Action <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
              <select
                name="actionType"
                value={actionType}
                onChange={(e) => setActionType(e.target.value)}
                className="border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none"
              >
                <option value="">Select an Action</option>
                <option value="delivery">Enter Delivery Details</option>
                <option value="return">Enter Return Info</option>
              </select>
              {errors.actionType && (
    <div className="text-red-500 text-xs mt-1">{errors.actionType}</div>
  )}
            </div>

            {/* Delivery Details Form */}
            {actionType === "delivery" && (
              <>
                <div className="flex flex-col mb-6">
                  <label className="block text-[#111928] text-sm font-medium mb-1">Delivery Date <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
                  <input
                    type="date"
                    name="deliveryDate"
                    value={processOrderData.deliveryDate}
                    onChange={handleProcessChange}
                    className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
                      errors.deliveryDate ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.deliveryDate && (
                    <div className="text-red-500 text-xs mt-1">{errors.deliveryDate}</div>
                  )}
                </div>

                <div className="flex flex-col mb-6">
                  <label className="block text-[#111928] text-sm font-medium mb-1">Proof of Delivery </label>
                  <input
                    type="file"
                    name="proofOfDelivery"
                    onChange={handleProcessChange}
                    accept="image/*"
                    className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
                      errors.proofOfDelivery ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.proofOfDelivery && (
                    <div className="text-red-500 text-xs mt-1">{errors.proofOfDelivery}</div>
                  )}
                </div>
              </>
            )}

            {/* Return Info Form */}
            {actionType === "return" && (
              <div className="flex flex-col mb-6">
                <label className="block text-[#111928] text-sm font-medium mb-1">Enter Return Info <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
                <input
                  type="text"
                  name="returnInfo"
                  value={processOrderData.returnInfo}
                  onChange={handleProcessChange}
                  className="border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none"
                  placeholder="Enter details about the return..."
                />
                {errors.returnInfo && (
                  <div className="text-red-500 text-xs mt-1">{errors.returnInfo}</div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* Action Buttons */}
      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
          </div>
          <div className="flex-1">
            <PrimaryButton title="Save Changes" onClick={handleInTransitSave} size="full" />
          </div>
        </div>
      </div>
    </>
  );
};

export default DeliveryInfoOrderComponent;
