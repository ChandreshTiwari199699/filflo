"use client";
import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { PrimaryButton, SecondaryButton } from "@/app/components/ButtonComponent/ButtonComponent";
import { b2bOrderService } from "@/app/services/b2bOrderService"; // Adjust if different

const CANCEL_REASONS = {
  "1": "Duplicate",
  "2": "Data Entry Mistake",
  "3": "Order Cancelled",
  "4": "Others"
};

const CancelInvoiceComponent = ({ selectedOrder, handleCancel }) => {
  const [cancelReason, setCancelReason] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleCancelInvoice = async (e) => {
    e.preventDefault();

    if (!cancelReason) {
      setError("Please select a reason to cancel the invoice.");
      return;
    }

    try {
      setLoading(true);
      const payload = {
        orderId: selectedOrder._id,
        CnlRsn: cancelReason, // Using the exact field name as per schema
      };

      const result = await b2bOrderService.cancelInvoice(payload);

      if (result.success) {
        toast.success("Invoice cancelled successfully!", {
          autoClose: 1500,
          onClose: () => {
            window.location.reload();
          },
        });
      } else {
        toast.error(`Failed to cancel invoice: ${result.error}`);
      }
    } catch (err) {
      toast.error("An unexpected error occurred. Please try again.");
      console.error("Error cancelling invoice:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <ToastContainer position="bottom-center" />
        <h2 className="text-base font-semibold text-[#111928] mb-1">Cancel Invoice</h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          Please select a reason for cancelling the invoice. This action cannot be undone.
        </p>

        <div className="mb-4">
          <label className="block text-[#111928] text-sm font-medium mb-1">
            Cancellation Reason <span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <select
            value={cancelReason}
            onChange={(e) => {
              setCancelReason(e.target.value);
              setError("");
            }}
            className={`w-full border rounded-lg px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
              error ? "border-red-500" : "border-gray-300"
            }`}
          >
            <option value="">Select Reason</option>
            {Object.entries(CANCEL_REASONS).map(([code, reason]) => (
              <option key={code} value={code}>
                {code} - {reason}
              </option>
            ))}
          </select>
          {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
        </div>

        {/* Order Details */}
        <div className="mt-6">
          <h3 className="text-sm font-semibold text-[#111928] mb-3">Order Details</h3>
          <table className="min-w-full text-sm text-left text-gray-500">
            <tbody>
              <tr className="bg-gray-50">
                <td className="px-4 py-2 font-medium text-[#111928]">Order ID:</td>
                <td className="px-4 py-2">{selectedOrder?.orderId || "N/A"}</td>
              </tr>
              <tr>
                <td className="px-4 py-2 font-medium text-[#111928]">Invoice Date:</td>
                <td className="px-4 py-2">{selectedOrder?.invoiceDate || "N/A"}</td>
              </tr>
              <tr className="bg-gray-50">
                <td className="px-4 py-2 font-medium text-[#111928]">Customer:</td>
                <td className="px-4 py-2">{selectedOrder?.customerID?.name || "N/A"}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
          </div>
          <div className="flex-1">
            <PrimaryButton 
              title="Cancel Invoice" 
              onClick={handleCancelInvoice} 
              size="full" 
              disabled={loading}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default CancelInvoiceComponent;
