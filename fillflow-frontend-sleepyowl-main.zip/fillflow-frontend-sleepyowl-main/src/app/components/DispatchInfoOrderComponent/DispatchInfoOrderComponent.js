"use client";
import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Input from "@/app/components/Input/Input";
import { PrimaryButton, SecondaryButton } from "@/app/components/ButtonComponent/ButtonComponent";
import { b2bOrderService } from "@/app/services/b2bOrderService";

const DispatchInfoOrderComponent = ({ selectedOrder, handleCancel }) => {
  const [processOrderData, setProcessOrderData] = useState({
    status: selectedOrder?.status || "",
    orderInternalId: selectedOrder?._id || "",
    actualDispatchDate: selectedOrder?.actualDispatchDate || "",
    ewaybillNumber: selectedOrder?.ewaybillNumber || "",
    awbNumber: selectedOrder?.awbNumber || "",
    shippingPartner: selectedOrder?.shippingPartner || "",
  });

  const [errors, setErrors] = useState({});

  const handleProcessChange = (e) => {
    const { name, value } = e.target;
    setProcessOrderData((prev) => ({ ...prev, [name]: value }));
  };

  const handleInvoicedSave = async (e) => {
    e.preventDefault();

    const { actualDispatchDate, awbNumber, shippingPartner } = processOrderData;
    const newErrors = {};

    if (!actualDispatchDate) newErrors.actualDispatchDate = "Actual Dispatch Date is required.";
    if (!awbNumber) newErrors.awbNumber = "AWB Number is required.";
    if (!shippingPartner) newErrors.shippingPartner = "Shipping Partner is required.";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      const updatedData = {
        ...processOrderData,
        status: "in_transit",
      };

      const result = await b2bOrderService.editB2BOrderByOrderInternalId(updatedData);

      if (result.success) {
        toast.success("Order updated to 'In Transit' successfully!", {
          autoClose: 1500,
          onClose: () => {
            window.location.reload();
          },
        });
      } else {
        toast.error(`Failed to update order: ${result.error}`);
      }
    } catch (error) {
      toast.error("An unexpected error occurred. Please try again.");
      console.error("Error saving 'Invoiced' order:", error);
    }
  };

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <ToastContainer position="bottom-center" />
        <h2 className="text-base font-semibold text-[#111928] mb-1">Dispatch Information</h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          Please provide the actual dispatch date and shipping details to proceed with the order.
        </p>

        {processOrderData.status === "invoiced" && (
          <>
            {/* Actual Dispatch Date */}
            <div className="flex flex-col mb-6">
              <label className="block text-[#111928] text-sm font-medium mb-1">
                Actual Dispatch Date <span className="text-[#9CA3AF] ml-[2px]">*</span>
              </label>
              <input
                type="date"
                name="actualDispatchDate"
                value={processOrderData.actualDispatchDate}
                onChange={handleProcessChange}
                className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
                  errors.actualDispatchDate ? "border-red-500" : "border-gray-300"
                }`}
              />
              {errors.actualDispatchDate && (
                <div className="text-red-500 text-xs mt-1">{errors.actualDispatchDate}</div>
              )}
            </div>

            {/* E-Way Bill Number */}
            <div className="flex flex-col mb-6">
              <label className="block text-[#111928] text-sm font-medium mb-1">
                E-Way Bill Number <span className="text-[#9CA3AF] ml-[2px]">(If applicable)</span>
              </label>
              <input
                type="text"
                name="ewaybillNumber"
                value={processOrderData.ewaybillNumber}
                onChange={handleProcessChange}
                className="border border-gray-300 rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none"
              />
            </div>

            {/* AWB Number */}
            <div className="flex flex-col mb-6">
              <label className="block text-[#111928] text-sm font-medium mb-1">
                AWB Number <span className="text-[#9CA3AF] ml-[2px]">*</span>
              </label>
              <input
                type="text"
                name="awbNumber"
                value={processOrderData.awbNumber}
                onChange={handleProcessChange}
                className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
                  errors.awbNumber ? "border-red-500" : "border-gray-300"
                }`}
              />
              {errors.awbNumber && (
                <div className="text-red-500 text-xs mt-1">{errors.awbNumber}</div>
              )}
            </div>

            {/* Shipping Partner */}
            <div className="flex flex-col mb-6">
              <label className="block text-[#111928] text-sm font-medium mb-1">
                Shipping Partner <span className="text-[#9CA3AF] ml-[2px]">*</span>
              </label>
              <select
                name="shippingPartner"
                value={processOrderData.shippingPartner}
                onChange={handleProcessChange}
                className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
                  errors.shippingPartner ? "border-red-500" : "border-gray-300"
                }`}
              >
                <option value="">Select a Shipping Partner</option>
                <option value="Movin">Movin</option>
                <option value="DPWorld">DPWorld</option>
                <option value="UTS">UTS</option>
                <option value="Delhivery"className="text-[#9CA3AF] text-sm font-medium" >Delhivery</option>
                <option value="Vishwakarma-Transports"className="text-[#9CA3AF] text-sm font-medium" >Vishwakarma-Transports</option>
                <option value="Others"className="text-[#9CA3AF] text-sm font-medium" >Others</option>
              </select>
              {errors.shippingPartner && (
                <div className="text-red-500 text-xs mt-1">{errors.shippingPartner}</div>
              )}
            </div>
          </>
        )}
      </div>

      {/* Buttons */}
      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
          </div>
          <div className="flex-1">
            <PrimaryButton title="Save Changes" onClick={handleInvoicedSave} size="full" />
          </div>
        </div>
      </div>
    </>
  );
};

export default DispatchInfoOrderComponent;
