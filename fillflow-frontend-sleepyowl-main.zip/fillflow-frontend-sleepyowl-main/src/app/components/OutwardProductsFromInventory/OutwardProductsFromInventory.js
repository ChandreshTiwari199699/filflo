import React, { useState, useEffect } from "react";
import Input from "../Input/Input";
import Button from "../Button/Button";
import { Formik, Field, ErrorMessage, Form } from "formik";
import * as Yup from "yup";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { qrCodeRecordsServices } from "@/app/services/qrCodeRecordsService";
import {
  PrimaryButton,
  SecondaryButton,
} from "@/app/components/ButtonComponent/ButtonComponent";

Yup.addMethod(
  Yup.string,
  "checkQRCodeStatus3",
  function (message, allQrCodeRecords) {
    return this.test("checkQRCodeStatus", message, function (value) {
      const qrCodeStatus = allQrCodeRecords.find(
        (qrCode) => qrCode.qr_code === value
      );

      if (!qrCodeStatus) {
        return this.createError({
          path: this.path,
          message: `${message} does not exist in the system`,
        });
      }

      return (
        qrCodeStatus.current_status === "Inwarded" ||
        this.createError({
          path: this.path,
          message: `${message} Current status: ${
            qrCodeStatus ? qrCodeStatus.current_status : "Unknown"
          }`,
        })
      );
    });
  }
);

Yup.addMethod(Yup.string, "unique", function (message) {
  return this.test("unique", message, function (value) {
    const { path, parent } = this;
    const siblings = Object.keys(parent)
      .filter((key) => key !== path)
      .map((key) => parent[key]);

    const isUnique = !siblings.includes(value);
    return isUnique || this.createError({ path, message });
  });
});

const OutwardProductsFromInventory = ( {onCancel}) => {
  const [numberOfTextFields, setNumberOfTextFields] = useState(0);
  const [inputValue, setInputValue] = useState("");
  const [initialValues, setInitialValues] = useState({});
  const [allQrCodeRecords, setAllQrCodeRecords] = useState([]);
  const [formVisible, setFormVisible] = useState(false);
  const [isFulfillButtonVisible, setIsFulfillButtonVisible] = useState(false);
  const [loading, setLoading] = useState(false); // Add a loading state
  const [validationSchema, setValidationSchema] = useState(Yup.object());


  useEffect(() => {
    const getAllQRCodeRecords = async () => {
      const response = await qrCodeRecordsServices.getAllQrCodeRecords();
      if (response.success) {
        setAllQrCodeRecords(response.data);
      }
    };
    getAllQRCodeRecords();
    
  }, []);
  



  useEffect(() => {
    const schema = Yup.object().shape(
      Object.keys(initialValues).reduce((acc, fieldName) => {
        acc[fieldName] = Yup.string()
          .required("This field is required")
          .unique("This value must be unique")
          .checkQRCodeStatus3("QR Code", allQrCodeRecords);
        return acc;
      }, {})
    );
  
    setValidationSchema(schema); // Set the new validation schema
  }, [initialValues, allQrCodeRecords]); // Dependencies for useEffect
  

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleButtonClick = () => {
    const numFields = parseInt(inputValue, 10) || 0;
    setNumberOfTextFields(numFields);
    const initial = {};
    for (let i = 0; i < numFields; i++) {
      initial[`text-field-${i}`] = "";
    }
    setInitialValues(initial);
    setFormVisible(true);
    if (inputValue) {
      setIsFulfillButtonVisible(true);
    }
  };

  const handleKeyDown = (e, id) => {
    if (e.key === "Enter") {
      e.preventDefault();

      const inputNodes = document.querySelectorAll('input[type="text"]');
      const inputs = Array.from(inputNodes);

      const currentIndex = inputs.findIndex(
        (input) => input.name === `text-field-${id}`
      );
      const nextIndex = currentIndex + 1;

      if (nextIndex < inputs.length) {
        inputs[nextIndex].focus();
      }
    }
  };


  const handleSubmit = async (values, actions) => {
    if (loading) return; // Prevent submission if already loading

    setLoading(true); // Set loading state to true

    try {
      const qrCodes = {};
      Object.keys(values).forEach((key) => {
        qrCodes[key] = values[key];
      });

      const response = await qrCodeRecordsServices.updateQRCodeStatuses3(qrCodes);

      console.log("QR code statuses updated:", response);

      toast.success("Products Outwarded Successfully!", { autoClose: 1500 });

      // Reload the page after showing the success toast
      setTimeout(() => {
        window.location.reload();
      }, 1500); // Adjust the timeout as needed

    } catch (error) {
      console.error("Error updating QR code statuses:", error.message);
      toast.error("Failed to submit form. Please try again.");
    } 
  };

  return (
    <>
    <div  className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
      <ToastContainer  position="bottom-center"/>

      <h2 className="text-base font-semibold text-[#111928] mb-1">
            Outward Products From Inventory
            </h2>

        <p className="text-sm font-normal text-[#4B5563] mb-6">
          Scan in QR codes of products to outward them from inventory.
        </p>

      <label className="block text-[#111928] text-sm font-medium mb-1">
        Enter amount of products you want to outward from inventory
      </label>
      <div className="flex flex-col mb-3">
        <Input
          type={"number"}
          name="quantity"
          value={inputValue}
          onChange={handleInputChange}
          className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none`}
        />
      </div>
      <div className="mt-2 mb-2" onClick={handleButtonClick}>
        <SecondaryButton
          title={"Outward Products"}
          onClick={handleButtonClick}
          size={"medium"}
        />
      </div>
      {formVisible && (
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
          enableReinitialize
        >
          {({ handleChange }) => (
            <Form style={{ marginTop: "10px" }}>
              {numberOfTextFields > 0 &&
                [...Array(numberOfTextFields)].map((_, id) => (
                  <div key={id}  className="flex flex-wrap  mt-2 mb-2">
              
                    <div className="flex flex-col">
                    <span className="text-sm font-medium mb-1">Product {id + 1}</span>
                    <Field
                      as={Input}
                      radius={"rounded-2xl"}
                      height={"h-[3.5vw] min-h-[3.5vh]"}
                      width={"w-[30vw] min-w-[30vw]"}
                      padding={"p-[1vw]"}
                      type={"text"}
                      color={"text-[#838481]"}
                      textSize={"text-[1vw]"}
                      fontWeight={"font-medium"}
                      name={`text-field-${id}`}

                      placeholder={`Enter QR code for Product ${id + 1}`}
                      onChange={handleChange}
                      onKeyDown={(e) => handleKeyDown(e, id)}
                    />

                    <ErrorMessage
                      name={`text-field-${id}`}
                      component="div"
                      className="text-red-500 text-xs"
                    />
                    </div>
                    
                  </div>
                ))}

{isFulfillButtonVisible && (
                  <PrimaryButton
                    title={"Submit Products"}
                    type="submit"
                    disabled={loading} 
                    size={"medium"}// Disable button if loading
                  />
              )}

             
            </Form>
         
          )}
        </Formik>
      )}
           </div>

           <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
            <div className="flex gap-x-2">
              <div className="flex-1">
                <SecondaryButton
                  title="Cancel"
                  onClick={onCancel}
                  size='full'
                />
              </div>
            
            </div>
          </div>

    {loading && (
      <div
        className="fixed top-0 left-0 w-full h-full bg-gray-400 opacity-50 z-50"
        style={{ zIndex: 1000 }}
      />
    )}

  </>
  );
};

export default OutwardProductsFromInventory;
