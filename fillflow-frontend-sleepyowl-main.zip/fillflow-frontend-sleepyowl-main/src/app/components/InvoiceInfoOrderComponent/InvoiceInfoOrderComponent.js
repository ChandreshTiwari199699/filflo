"use client";
import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { PrimaryButton, SecondaryButton } from "@/app/components/ButtonComponent/ButtonComponent";
import { b2bOrderService } from "@/app/services/b2bOrderService";

const InvoiceInfoOrderComponent = ({ selectedOrder, handleCancel }) => {
  const [processOrderData, setProcessOrderData] = useState({
    status: selectedOrder?.status || "",
    orderInternalId: selectedOrder?._id || "",
    invoiceId: selectedOrder?.invoiceId || "",
  });

  const [errors, setErrors] = useState({});
  const [isReadyToPushChecked, setIsReadyToPushChecked] = useState(false);
   const [loading, setLoading] = useState(false); 

  const handleProcessChange = (e) => {
    const { name, value } = e.target;
    setProcessOrderData((prev) => ({ ...prev, [name]: value }));
  };

  const handleReadyToShipSave = async (e) => {
    e.preventDefault();

    const { invoiceId } = processOrderData;
    const newErrors = {};
    if (!isReadyToPushChecked) newErrors.status = "Invoice must be marked as ready to push.";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setLoading(true);

    try {
      const updatedData = {
        ...processOrderData,
        status: "invoiced", 
      };


      const result = await b2bOrderService.editB2BOrderByOrderInternalId(updatedData);

      if (result.success) {
        toast.success("Order marked as invoiced successfully!", {
          autoClose: 1500,
          onClose: () => {
            window.location.reload();
          },
        });
      } else {
        toast.error(`Failed to update order: ${result.error}`);
      }
    } catch (error) {
      toast.error("An unexpected error occurred. Please try again.");
      console.error("Error saving 'Ready to Ship' order:", error);
    }
  };

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <ToastContainer position="bottom-center" />
        <h2 className="text-base font-semibold text-[#111928] mb-1">Invoice Information</h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          Please provide the invoice details / delivery note to process the order further.
        </p>

        {processOrderData.status === "picked" && (
          <>
            {/* Invoice ID Field */}
            <div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Invoice / DN ID 
    <span className="text-[#9CA3AF] ml-[2px]"> (Optional – auto-generated if left blank)</span>
  </label>
  <input
    type="text"
    name="invoiceId"
    value={processOrderData.invoiceId}
    onChange={handleProcessChange}
    className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
      errors.invoiceId ? "border-red-500" : "border-gray-300"
    }`}
  />
  {errors.invoiceId && <div className="text-red-500 text-xs mt-1">{errors.invoiceId}</div>}
</div>


            {/* Ready to Push Invoice Checkbox */}
            <div className="mb-4 flex flex-col">
  <div className="flex items-center">
    <input
      type="checkbox"
      name="status"
      checked={isReadyToPushChecked}
      onChange={(e) => setIsReadyToPushChecked(e.target.checked)}
      className={`w-4 h-4 text-blue-600 border-gray-300 rounded ${
        errors.status ? "border-red-500" : "border-gray-300"
      }`}
    />
    <label className="ml-2 text-sm font-medium">
      {selectedOrder?.documentType === "invoice"
        ? "Mark as Ready To Push Invoice to GST Portal"
        : "Mark as Ready To Create Delivery Note"}
      <span className="text-[#9CA3AF] ml-[2px]">*</span>
    </label>
  </div>
  {errors.status && (
    <div className="text-red-500 text-xs mt-1">{errors.status}</div>
  )}
</div>

          </>
        )}
      </div>

      {/* Buttons */}
      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
          </div>
          <div className="flex-1">
            <PrimaryButton title="Save Changes" onClick={handleReadyToShipSave} size="full"  disabled={loading}   />
          </div>
        </div>
      </div>
    </>
  );
};

export default InvoiceInfoOrderComponent;