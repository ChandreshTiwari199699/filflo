import React from "react";
import { SecondaryButton } from "../ButtonComponent/ButtonComponent";

const ViewCustomerDetails = ({ customer, handleCancel }) => {
  if (!customer || !customer.products || customer.products.length === 0) {
    return (
      <div className="p-4 text-center text-gray-500">
        <p>No Products Attached To This Customer </p>
        <div className="mt-4">
          <SecondaryButton title="Close" width="w-full" onClick={handleCancel} />
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <h2 className="text-base font-semibold text-[#111928] mb-4">
          View Customer Products Details
        </h2>
        <div className="space-y-4">
          {customer.products.map((productItem, index) => {
            const { productId, productName, price } = productItem;
            const ppu = productId?.ppu || 0;
            const marginDifference = price - ppu;
            const marginPercentage =
              ppu > 0 ? ((marginDifference / ppu) * 100).toFixed(2) : "N/A";
            return (
              <div
                key={index}
                className="flex-grow min-w-0 py-2 px-4 rounded-lg bg-gray-100 shadow-md border border-gray-200 hover:shadow-lg transition-shadow"
              >
                <div className="flex justify-between items-center mb-2">
                  <span className="text-dark font-medium text-sm">
                    {productName || "N/A"}
                  </span>
                </div>

                <div className="flex gap-x-2 mb-2">
                  <span className="font-normal text-sm text-dark-4">SKU:</span>
                  <span className="font-normal text-sm text-dark-4">
                    {productId?.sku_code || "N/A"}
                  </span>
                </div>

                <div className="flex gap-x-2 mb-2">
                  <span className="font-normal text-sm text-dark-4">Price:</span>
                  <span className="font-normal text-sm text-dark-4">
                    ₹{price?.toFixed(2) || "N/A"}
                  </span>
                </div>

                <div className="flex gap-x-2">
                  <span className="font-normal text-sm text-dark-4">Margin:</span>
                  <span className="font-normal text-sm text-dark-4">
                    ₹{marginDifference.toFixed(2)} {ppu > 0 && `(${marginPercentage}%)`}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Close" width="w-full" onClick={handleCancel} />
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewCustomerDetails;
