import React from "react";
import { SecondaryButton } from "../ButtonComponent/ButtonComponent";

const ViewRateCardProducts = ({ strategy, handleCancel }) => {
  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <h2 className="text-base font-semibold text-[#111928] mb-4">
          View Rate Card Products Details
        </h2>
        <div className="space-y-4">
          {strategy?.listOfProducts && strategy.listOfProducts.length > 0 ? (
            strategy.listOfProducts.map((productItem, index) => {
              // Destructure product details
              const { productId, productName, price } = productItem;
              // Calculate margin: price - ppu
              const ppu = productId?.ppu || 0;
              const marginDifference = price - ppu;
              // Calculate margin percentage if ppu exists and is not zero
              const marginPercentage =
                ppu > 0 ? ((marginDifference / ppu) * 100).toFixed(2) : "N/A";
              return (
                <div
                  key={index}
                  className="flex-grow min-w-0 py-2 px-4 rounded-lg bg-gray-100 shadow-md border border-gray-200 hover:shadow-lg transition-shadow"
                >
                  {/* Product Name */}
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-dark font-medium text-sm">
                      {productName || "N/A"}
                    </span>
                  </div>

                  {/* SKU Code */}
                  <div className="flex gap-x-2 mb-2">
                    <span className="font-normal text-sm text-dark-4">
                      SKU:
                    </span>
                    <span className="font-normal text-sm text-dark-4">
                      {productId?.sku_code || "N/A"}
                    </span>
                  </div>

                  {/* Price */}
                  <div className="flex gap-x-2 mb-2">
                    <span className="font-normal text-sm text-dark-4">
                      Price:
                    </span>
                    <span className="font-normal text-sm text-dark-4">
                      ₹{price?.toFixed(2) || "N/A"}
                    </span>
                  </div>

                  {/* Margin Difference and Percentage */}
                  <div className="flex gap-x-2">
                    <span className="font-normal text-sm text-dark-4">
                      Margin:
                    </span>
                    <span className="font-normal text-sm text-dark-4">
                      ₹{marginDifference.toFixed(2)}{" "}
                      {ppu > 0 && `(${marginPercentage}%)`}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <p className="text-sm text-dark-4">No products available</p>
          )}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Close" width="w-full" onClick={handleCancel} />
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewRateCardProducts;
