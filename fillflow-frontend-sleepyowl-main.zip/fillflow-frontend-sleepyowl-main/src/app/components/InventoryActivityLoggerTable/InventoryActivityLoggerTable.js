import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import moment from "moment";
import RightSidebar from "../RightSidebar/RightSidebar";
import TableFilterBar from "../TableFilterBar/TableFilterBar";
import {
  stickyActionColumnClassname,
  stickyActionRowClassname,
} from "@/app/utils/stickyActionClassname";
import DynamicTableWithoutAction from "@/app/components/DynamicTableWithoutAction/DynamicTableWithoutAction";
import ActionDropdown from "../ActionDropdown/ActionDropdown";
import ViewOutwardedProductsList from "../ViewOutwardedProductsList/ViewOutwardedProductsList";
import { filterByDate } from "@/app/components/DateFilter/DateFilter";
import searchNested from "@/app/utils/searchUtils";
import StatusComponent from "../StatusComponent/StatusComponent";

const InventoryActivityLoggerTable = () => {
  const [searchText, setSearchText] = useState("");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarType, setSidebarType] = useState(null);
  const [selectedPo, setSelectedPo] = useState(null);
  const [dayFilter, setDayFilter] = useState("all");
  const [filteredData, setFilteredData] = useState([]);

  // Fetch outwarded products
  const { productLogs } = useSelector((state) => state.productActivityLogger);

  // Sort products by creation date
  const sortedLogs = productLogs.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  // Function to apply filters and flatten data for table display
  const applyFilters = () => {
    let data = productLogs;
    data = filterByDate(data, dayFilter, null, null, "created_at");

    data = data.filter((item) =>
      searchKeys.some((key) => searchNested(item[key], searchText.toLowerCase(), key))
    );

    // Flattening logs to ensure each product is a separate row
    const flattenedData = data.flatMap((log) =>
      log.products.map((product, index) => ({
        ...log,
        product,
        productIndex: index, // Store product index for sidebar details
      }))
    );

    setFilteredData(flattenedData);
  };

  useEffect(() => {
    applyFilters();
  }, [productLogs, searchText, dayFilter]);

  const searchKeys = ["created_at", "products"];

  const convertToCSV = (data) => {
    const headers = ["Created At", "Activity Type", "Created By", "Product Name", "Quantity", "SKU Codes"];
    const rows = [];

    data.forEach((item) => {
      const commonValues = [
        `"${moment(item.created_at).format("DD MMM YYYY HH:mm:ss")}"`,
        `"${item.activity_type || "N/A"}"`,
        `"${item.created_by?.firstName || "N/A"}"`,
      ];

      item.products.forEach((product) => {
        const productValues = [
          `"${product.product_name.replace(/"/g, '""')}"`, 
          `"${product.quantity}"`,
          `"${product.sku_codes.join("; ").replace(/"/g, '""')}"`,
        ];
        rows.push([...commonValues, ...productValues].join(","));
      });
    });

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    const fileName = `Outwarded_Products_${moment().format("DD-MMM-YYYY")}.csv`;
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const headings = {
    createdAt: {
      label: "Created On",
      renderCell: (row) => moment(row?.created_at).format("DD MMM YYYY HH:mm:ss") || "N/A",
      isSticky: false,
    },
    log_type: {
      label: "Activity Type",
      renderCell: (row) => <StatusComponent status={row?.activity_type} /> || "N/A",
      isSticky: false,
    },
    created_by: {
      label: "Created By",
      renderCell: (row) => row?.created_by?.firstName || "N/A",
      isSticky: false,
    },
    product_name: {
      label: "Product Name",
      renderCell: (row) => row.product?.product_name || "N/A",
      isSticky: false,
    },
    quantity: {
      label: "Quantity",
      renderCell: (row) => row.product?.quantity || "N/A",
      isSticky: false,
    },
    action: {
      label: "Action",
      renderCell: (row) => <ActionDropdown po={row} actions={generatePOActions(row)} />,
      isSticky: true,
      stickyClassHeader: stickyActionColumnClassname,
      stickyClassRow: stickyActionRowClassname,
    },
  };

  const generatePOActions = (po) => {
    return [
      {
        label: "View Product Details",
        condition: null,
        action: () => openSidebar("ViewProductDetail", po, po.productIndex),
      },
    ];
  };

  const openSidebar = (type, po, productIndex = null) => {
    setSidebarType(type);
    setSelectedPo({ ...po, productIndex });
    setIsSidebarOpen(true);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
    setSidebarType(null);
    setSelectedPo(null);
  };

  const handleDayFilterChange = (event) => {
    setDayFilter(event.target.value);
  };

  return (
    <>
      <TableFilterBar
        searchText={searchText}
        setSearchText={setSearchText}
        convertToCSV={convertToCSV}
        allPO={sortedLogs}
        dayFilter={dayFilter}
        handleDayFilterChange={handleDayFilterChange}
      />
      <DynamicTableWithoutAction headings={headings} rows={filteredData} />

      <RightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
        {sidebarType === "ViewProductDetail" && (
          <ViewOutwardedProductsList
            po={selectedPo}
            product={selectedPo.product}
            productIndex={selectedPo.productIndex}
            handleCancel={closeSidebar}
          />
        )}
      </RightSidebar>
    </>
  );
};

export default InventoryActivityLoggerTable;
