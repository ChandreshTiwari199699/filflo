'use client';
import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Button from "../Button/Button";
import B2BCustomerDropdown from "../B2BCustomerDropdown/B2BCustomerDropdown";
import { getAllB2BCustomerRequest, getAllB2BCustomerSuccess, getAllB2BCustomerFailure } from "../../Actions/b2bCustomerActions";
import { b2bCustomerService } from "@/app/services/b2bCustomerService";
import { ToastContainer, toast } from "react-toastify";
import { pricingStrategyService } from "@/app/services/pricingStratergyService";
import "react-toastify/dist/ReactToastify.css";
import PricingStrategyDropdown from "../PricingStrategyDropdown/PricingStrategyDropdown";

const AddPricingStrategy = () => {
  const dispatch = useDispatch();
  const { b2bCustomers } = useSelector((state) => state.b2bCustomer);
  const { dropDownPricingStrategyValue, dropDownB2BCustomerName, dropDownB2BCustomerValue } = useSelector((state) => state.dropdown);
  const [getAllPricingStratergy, setGetAllPricingStratergy] = useState([]);
  const [selectedPricingStrategy, setSelectedPricingStrategy] = useState("");
  const [selectedCustomers, setSelectedCustomers] = useState([]);
  const [errors, setErrors] = useState({});

  // Fetch B2B Customers on mount
  useEffect(() => {
    const fetchB2BCustomers = async () => {
      try {
        dispatch(getAllB2BCustomerRequest());
        const response = await b2bCustomerService.getAllB2BCustomers();
        if (response.success) {
          dispatch(getAllB2BCustomerSuccess(response.data));
        } else {
          toast.error("Failed to fetch customers");
        }
      } catch (err) {
        console.error(err);
        toast.error("An error occurred while fetching customers");
      }
    };

    fetchB2BCustomers();
  }, [dispatch]);

  // Fetch Pricing Strategies on mount
  useEffect(() => {
    const getAllPricingStratergy = async () => {
      try {
        const response = await pricingStrategyService.getAllPricingStrategies();
        if (response.success) {
          setGetAllPricingStratergy(response.data);
        } else {
          toast.error("Failed to fetch pricing strategies");
        }
      } catch (err) {
        console.error(err);
        toast.error("An error occurred while fetching pricing strategies");
      }
    };

    getAllPricingStratergy();
  }, []);

  // Auto-update selected strategy and customers from dropdown
  useEffect(() => {
    if (dropDownPricingStrategyValue) {
      setSelectedPricingStrategy(dropDownPricingStrategyValue);
    }
  }, [dropDownPricingStrategyValue]);

  useEffect(() => {
    if (dropDownB2BCustomerName && dropDownB2BCustomerValue) {
      const customer = {
        name: dropDownB2BCustomerName,
        _id: dropDownB2BCustomerValue,
      };
      if (!selectedCustomers.find((c) => c._id === customer._id)) {
        setSelectedCustomers((prev) => [...prev, customer]);
      }
    }
  }, [dropDownB2BCustomerName, dropDownB2BCustomerValue]);

  const handleRemoveCustomer = (customerId) => {
    setSelectedCustomers(selectedCustomers.filter((customer) => customer._id !== customerId));
  };

  const handleSubmit = async () => {
    if (!selectedPricingStrategy) {
      setErrors((prev) => ({ ...prev, pricingStrategy: "Please select a pricing strategy" }));
      return;
    }
  
    if (selectedCustomers.length === 0) {
      setErrors((prev) => ({ ...prev, customers: "Please select at least one customer" }));
      return;
    }
  
    const pricingData = {
      pricingStrategy: selectedPricingStrategy,
      selectedCustomers,
    };
  
    console.log("🚀 Pricing Strategy Data:", pricingData);
  
    try {
      const response = await pricingStrategyService.assignPricingStrategyToCustomers(pricingData);
  
      if (response && response.success) {
        toast.success("Rate Card Assigned Successfully", {
          autoClose: 1500,
          onClose: () => window.location.reload(),
        });
      } else {
        toast.error("Failed to assign rate card: " + (response?.message || "Unknown error"), {
          autoClose: 5000,
          onClose: () => window.location.reload(),
        });
      }
    } catch (err) {
      toast.error("Failed to assign rate card: " + err, { autoClose: 3000 });
      window.location.reload();
    }
  };
  

  return (
    <div className="h-[78vh] min-h-[78vh] max-h-[78vh] overflow-y-scroll">
      <ToastContainer />

      <h2 className="text-base font-semibold text-[#111928] mb-1">
        Add Rate Card To B2B Customers
      </h2>
      <p className="text-sm font-normal text-[#4B5563] mb-6">
        Select a Rate Card and Associate B2B customers with it
      </p>

      {/* Pricing Strategy Dropdown */}
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">
          Select Rate Card <span className="text-[#9CA3AF] ml-[2px]">*</span>
        </label>
        <PricingStrategyDropdown
          id="pricingStratergyDropdown"
          bgColor={"#F8F6F2"}
          options={getAllPricingStratergy}
        />
         {errors.pricingStrategy && (
          <p className="text-red-500 text-xs">{errors.pricingStrategy}</p>
        )}
      </div>

      {/* Select B2B Customers */}
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">
          Select B2B Customers <span className="text-[#9CA3AF] ml-[2px]">*</span>
        </label>
        <B2BCustomerDropdown
          id="customerDropdown"
          bgColor={"#F8F6F2"}
          options={b2bCustomers}
        />
        {errors.customers && (
          <p className="text-red-500 text-xs">{errors.customers}</p>
        )}
      </div>

      {/* Selected Customers List */}
      <div className="mt-3">
        {selectedCustomers.length > 0 && <label>Selected Customers:</label>}
        <ul className="flex flex-col gap-4">
          {selectedCustomers.map((customer, index) => (
            <li key={index} className="border bg-[#F8F6F2] text-black rounded-lg p-2 text-sm">
              <div className="flex justify-between">
                <div className="text-left">
                  <span className="font-semibold">Name:</span> {customer.name}
                </div>
                <button
                  onClick={() => handleRemoveCustomer(customer._id)}
                  className="bg-red-500 text-white px-2 py-1 rounded-lg"
                >
                  Remove
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>

      {/* Submit Button */}
      <div className="flex flex-row gap-5 mt-5">
        <div onClick={handleSubmit}>
          <Button
            title="Apply Rate Card"
            bgColor="bg-[rgb(79,201,218)]"
            radius="rounded-lg"
            height="h-[3vw] min-h-[3vh]"
            padding="p-[1vw]"
            color="text-[#ffff]"
            textSize="text-[1vw]"
            fontWeight="font-medium"
            width="w-[14vw]"
          />
        </div>
      </div>
    </div>
  );
};

export default AddPricingStrategy;
