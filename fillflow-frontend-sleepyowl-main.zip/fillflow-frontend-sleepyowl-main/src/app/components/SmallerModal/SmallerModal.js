import React from "react";

const SmallerModal = ({ isOpen, onClose, children, message }) => {
  console.log("Modal isOpen:", isOpen); // Debugging log
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50">
      {/* Background Overlay */}
      <div className="fixed inset-0 bg-black opacity-50" onClick={onClose}></div>

      {/* Modal Content */}
      <div className="bg-white h-3/5 w-2/5 p-6 rounded-lg shadow-lg z-10 overflow-y-auto">
        {children ? children : <p className="text-lg">{message}</p>}
        <button
          onClick={onClose}
          className="mt-4 bg-blue-500 text-white py-2 px-4 rounded-lg">
          Close
        </button>
      </div>
    </div>
  );
};

export default SmallerModal;
