import React, { useState } from "react";
import moment from "moment";
import { PrimaryButton, SecondaryButton } from "../ButtonComponent/ButtonComponent";
import Modal from "../Modal/Modal";
import GRNNote from "../GRN/GRN"

const formattedGRNData = (selectedPO, inward) => {
    console.log("🚀 ~ formattedGRNData ~ selectedPO:", selectedPO)
    const supplier = selectedPO?.supplier_id || {};
    const createdAt = selectedPO?.createdAt;
    const itemsMap = {};
    selectedPO?.items?.forEach((item) => {
      itemsMap[item.sku_id?._id] = item;
    });
  
    return {
      company: {
        name: "Sleepy Owl Coffee Private Limited",
        address:
          "Khasra no 170/3/2, 3/8/3, 10/1/2, 11/2B, Haily Mandi Road, Farukhnagar, Khera Khurrampur, Gurugram , 122506",
        gstin: "09AAYCS6785E1ZX",
        pan: "AAYCS6785E",
        msme: "UDYAM-DL-08-0011846",
        fssai: "13321999000683",
      },
      supplier: {
        name: supplier.name || "N/A",
        address: supplier.address || "N/A",
        gstin: supplier.gstNumber || "N/A",
      },
      grnNumber: inward?.grn_number || "N/A",
      inwardDate: inward?.received_date || null,
      createdAt: createdAt,
      items:
        inward?.items?.map((item) => {
          const matchedItem = itemsMap[item.sku_id?._id] || {};
          const price = matchedItem.price || 0;
          return {
            sku: item.sku_id?.sku_code || "-",
            name: item.sku_id?.sku_name || "-",
            orderedQty: matchedItem.quantity_ordered || 0,
            inwardedQty: item.quantity_received || 0,
            price,
          };
        }) || [],
    };
  };
  

const ViewPOParticular = ({ selectedPO, handleCancel }) => {
  const [isGRNOpen, setIsGRNOpen] = useState(false);
  const [grnData, setGRNData] = useState(null);

  const handleGenerateGRNNote = (po, inward) => {
    const data = formattedGRNData(po, inward);
    setGRNData(data);
    setIsGRNOpen(true);
  };

  const formatDate = (dateString) => {
    return moment(dateString).isValid()
      ? moment(dateString).format("DD MMM YYYY")
      : "N/A";
  };

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-20 text-black">
        <h2 className="text-base font-semibold text-[#111928] mb-1">
          View PO Particular
        </h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          See Purchase Order details
        </p>

        {/* Order Info */}
        <div className="mb-4">
          <p className="text-sm text-[#4B5563]">
            <span className="font-semibold text-[#111928]">Order Date: </span>
            {formatDate(selectedPO?.order_date)}
          </p>
          <p className="text-sm text-[#4B5563]">
            <span className="font-semibold text-[#111928]">Supplier Name: </span>
            {selectedPO?.supplier_id?.name || "N/A"}
          </p>
        </div>

        {/* Ordered Items */}
        <h2 className="text-sm font-semibold text-[#111928] mt-6 mb-3">
          Ordered Items
        </h2>
        <table className="min-w-full text-sm text-left bg-[#F8F6F2] rounded-lg">
          <thead className="text-xs text-[#4B5563] font-medium bg-[#F3F4F6]">
            <tr>
              <th className="px-4 py-2">SKU</th>
              <th className="px-4 py-2">Name</th>
              <th className="px-4 py-2">Ordered Qty</th>
              <th className="px-4 py-2">Fulfilled Qty</th>
              <th className="px-4 py-2">Price (₹)</th>
            </tr>
          </thead>
          <tbody>
            {selectedPO?.items?.map((item, index) => (
              <tr
                key={index}
                className={`${
                  index % 2 === 0 ? "bg-white" : "bg-[#F8F6F2]"
                } text-[#111928]`}
              >
                <td className="px-4 py-2">{item.sku_id?.sku_code || "SKU"}</td>
                <td className="px-4 py-2">{item.sku_id?.sku_name || "-"}</td>
                <td className="px-4 py-2 text-center">
                  {item.quantity_ordered}
                </td>
                <td className="px-4 py-2 text-center">
                  {item.quantity_fulfilled}
                </td>
                <td className="px-4 py-2 text-center">
                  ₹{item.price.toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Inward Section */}
        <h2 className="text-sm font-semibold text-[#111928] mt-6 mb-3">
          Inward Entries
        </h2>
        {selectedPO?.inwards?.length === 0 ? (
          <p className="text-[#4B5563] text-sm italic">
            No inward has been made associated to this PO.
          </p>
        ) : (
          selectedPO?.inwards?.map((inward, index) => (
            <div key={index} className="mb-4 p-4 bg-white rounded shadow">
              <p className="text-sm mb-1">
                <span className="font-medium text-[#111928]">GRN Number:</span>{" "}
                {inward.grn_number || "N/A"}
              </p>
              <p className="text-sm mb-1">
                <span className="font-medium text-[#111928]">
                  Received Date:
                </span>{" "}
                {formatDate(inward.received_date)}
              </p>

              <table className="min-w-full text-sm text-left border mt-2">
                <thead className="text-xs text-[#4B5563] font-medium bg-[#F3F4F6]">
                  <tr>
                    <th className="px-4 py-2">SKU</th>
                    <th className="px-4 py-2">Name</th>
                    <th className="px-4 py-2">Quantity Received</th>
                  </tr>
                </thead>
                <tbody>
                  {inward.items.map((item, i) => (
                    <tr
                      key={i}
                      className={`${
                        i % 2 === 0 ? "bg-white" : "bg-[#F8F6F2]"
                      } text-[#111928]`}
                    >
                      <td className="px-4 py-2">{item.sku_id?.sku_code || "-"}</td>
                      <td className="px-4 py-2">{item.sku_id?.sku_name || "-"}</td>
                      <td className="px-4 py-2">{item.quantity_received}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="mt-2">
                <PrimaryButton
                  title="Generate GRN Note"
                  onClick={() => handleGenerateGRNNote(selectedPO, inward)}
                />
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer Buttons */}
      <div className="absolute bottom-0 left-0 w-full border-t bg-white p-2">
        <div className="flex">
          <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
        </div>
      </div>

      {/* GRN Modal */}
      <Modal isOpen={isGRNOpen} onClose={() => setIsGRNOpen(false)}>
  <GRNNote grnData={grnData} />
</Modal>

    </>
  );
};

export default ViewPOParticular;
