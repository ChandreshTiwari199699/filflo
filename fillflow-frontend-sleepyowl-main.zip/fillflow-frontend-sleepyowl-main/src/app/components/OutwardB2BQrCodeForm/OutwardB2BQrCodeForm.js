import React from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import {
  PrimaryButton,
  SecondaryButton,
} from "../ButtonComponent/ButtonComponent";

const OutwardB2BQrCodeForm = ({
  selectedPO,
  filteredData,
  allQrCodeRecords,
  validationSchema,
  handleSubmit,
  handleCheckboxChange,
  setIsSidebarOpen,
  isSubmitting,
}) => {
  const fieldsArray = [];
  const initialValues = Object.fromEntries(
    selectedPO.flatMap((poID) => {
      const po = filteredData.find((po) => po._id === poID);
      if (po) {
        return Array.from({ length: po.quantity }, (_, idx) => {
          const fieldName = `qr_${po._id}_${po.product_id.skuCode}_${idx + 1}`;
          fieldsArray.push(fieldName);
          return [fieldName, ""];
        });
      }
      return [];
    })
  );

  const handleKeyDown = (e, name) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const currentIndex = fieldsArray.indexOf(name);

      if (currentIndex >= 0 && currentIndex < fieldsArray.length - 1) {
        const nextField = document.querySelector(
          `[name="${fieldsArray[currentIndex + 1]}"]`
        );
        nextField?.focus();
      }
    }
  };

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({ handleChange, values, errors }) => (
        <Form>
          <h2 className="text-base font-semibold text-[#111928] mb-2">
            Outward to B2B
          </h2>
          <p className="text-sm font-normal text-[#4B5563] mb-6">
            Scan in products to outward against B2B Orders
          </p>

          <div className="space-y-4 pb-20 overflow-y-auto scrollbar-none pr-2">
            {selectedPO.map((poID) => {
              const po = filteredData.find((po) => po._id === poID);
              if (po) {
                return (
                  <div key={poID} className="mb-6 bg-gray-2 p-4 rounded-lg">
                    {/* PO ID */}
                    <label className="block text-dark text-sm font-medium mb-1">
                      {`Order ID: ${po?.b2b_order_id?.orderId}`}
                    </label>
                    {/* Quantity and SKU Code */}
                    <div className="text-dark-4 flex gap-x-4 text-sm mb-2">
                      <div>Quantity: {po.quantity}</div>
                      <div>SKU Code: {po.product_id.sku_code}</div>
                    </div>
                    {/* Input fields for each quantity */}
                    {Array.from({ length: po.quantity }, (_, idx) => {
                      const fieldName = `qr_${po._id}_${po.product_id.skuCode}_${
                        idx + 1
                      }`;
                      return (
                        <div key={fieldName} className="mb-2">
                          <Field
                            type="text"
                            placeholder={`Enter Inventory QR Code for item ${
                              idx + 1
                            }`}
                            name={fieldName}
                            className="w-full border rounded-xl h-10 text-sm p-4"
                            onChange={handleChange}
                            onKeyDown={(e) => handleKeyDown(e, fieldName)}
                          />
                          <ErrorMessage
                            name={fieldName}
                            component="div"
                            className="text-red-500 text-xs mt-1"
                          />
                        </div>
                      );
                    })}
                  </div>
                );
              }
              return null;
            })}
          </div>

          <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
            <div className="flex gap-x-2">
              <div className="flex-1">
                <SecondaryButton
                  title="Cancel"
                  onClick={() => setIsSidebarOpen(false)}
                  size="full"
                />
              </div>
              <div className="flex-1">
                <PrimaryButton
                  title="Submit"
                  type="submit"
                  size="full"
                  disabled={isSubmitting} 
                />
              </div>
            </div>
          </div>
        </Form>
      )}
    </Formik>
  );
};

export default OutwardB2BQrCodeForm;
