"use client";
import React, { useState, useEffect } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { PrimaryButton, SecondaryButton } from "@/app/components/ButtonComponent/ButtonComponent";
import { b2bOrderService } from "@/app/services/b2bOrderService";

const GRNInfoOrderComponent = ({ selectedOrderOriginal, closeProcessModal }) => {
  const [processOrderData, setProcessOrderData] = useState({
    orderInternalId: selectedOrderOriginal?._id || "",
    ...selectedOrderOriginal,
    listOfProducts: selectedOrderOriginal?.listOfProducts.map(product => ({
      ...product,
      fulfilledQuantityInUnitItems: product.fulfilledQuantity * (product._id.case_size || 1),
      grnQuantity: product.fulfilledQuantity * (product._id.case_size || 1), // Default GRN quantity
    })) || [],
  });
  
  const [errors, setErrors] = useState({});
  const [grnReasons, setGrnReasons] = useState({});

  const handleGRNQuantityChange = (e, productIndex) => {
    const newGrnQuantity = Number(e.target.value);
    setProcessOrderData((prevState) => {
      const updatedListOfProducts = prevState.listOfProducts.map((product, index) => 
        index === productIndex ? { ...product, grnQuantity: newGrnQuantity } : product
      );
      return { ...prevState, listOfProducts: updatedListOfProducts };
    });
  
    if (newGrnQuantity !== processOrderData.listOfProducts[productIndex].fulfilledQuantityInUnitItems) {
      setGrnReasons((prev) => ({ ...prev, [productIndex]: "" }));
    } else {
      setGrnReasons((prev) => {
        const newReasons = { ...prev };
        delete newReasons[productIndex];
        return newReasons;
      });
    }
  };

  const handleReasonChange = (e, productIndex) => {
    setGrnReasons((prev) => ({ ...prev, [productIndex]: e.target.value }));
  };

  const handleDeliveredSaveChange = async (e) => {
    e.preventDefault();
    const errors = {};
    let hasError = false;

    processOrderData.listOfProducts.forEach((product, index) => {
      if (product.grnQuantity === null || product.grnQuantity === undefined || isNaN(product.grnQuantity)) {
        errors[`grn_${index}`] = "Please enter GRN quantity";
        hasError = true;
      }
      if (product.grnQuantity !== product.fulfilledQuantityInUnitItems && !grnReasons[index]) {
        errors[`reason_${index}`] = "Please select a reason for GRN quantity change";
        hasError = true;
      }
    });
    
    if (hasError) {
      setErrors(errors);
      return;
    }

    const grnData = processOrderData.listOfProducts.map((product, index) => ({
      skuCode: product.skuCode,
      grnQuantity: product.grnQuantity,
      grnReason: grnReasons[index] || "", 
    }));

    const updatedData = {
      ...processOrderData,
      grnData,
      status: "grn_entered",
    };

    try {
      const result = await b2bOrderService.editB2BOrderByOrderInternalId(updatedData);
      if (result.success) {
        toast.success("GRN Info entered successfully!", {
          autoClose: 1500,
          onClose: () => {
            window.location.reload();
          },
        });
      } else {
        toast.error(`Failed to update GRN Info: ${result.error}`);
      }
    } catch (error) {
      toast.error("An unexpected error occurred. Please try again.");
      console.error("Error while saving GRN Info:", error);
    }
  };

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <ToastContainer position="bottom-center" />
        <h2 className="text-base font-semibold text-[#111928] mb-1">GRN Information</h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          Please enter the GRN quantities for the products below.
        </p>

        {processOrderData.status === "delivered" && (
          <table className="min-w-full text-sm text-left text-gray-500">
            <thead className="text-xs text-gray-700 uppercase bg-gray-200">
              <tr>
                <th className="px-1 py-2">SKU Code</th>
                <th className="px-1 py-2">Fulfilled Units in Unit Items</th>
                <th className="px-1 py-2">Enter GRN Quantity</th>
                <th className="px-1 py-2">Enter Reason for GRN Quantity Change</th>
              </tr>
            </thead>
            <tbody>
              {processOrderData?.listOfProducts.map((product, index) => (
                <tr key={index}>
                  <td className="px-1 py-2 text-center">{product.skuCode}</td>
                  <td className="px-1 py-2 text-center">{product.fulfilledQuantityInUnitItems}</td>
                  <td className="px-1 py-2 text-center">
                    <input
                      type="number"
                      value={product.grnQuantity}
                      onChange={(e) => handleGRNQuantityChange(e, index)}
                      className={`w-20 border rounded p-1 ${errors[`grn_${index}`] ? "border-red-500" : "border-gray-300"}`}
                    />
                    {errors[`grn_${index}`] && <p className="text-red-500 text-xs">{errors[`grn_${index}`]}</p>}
                  </td>
                  <td className="px-1 py-2 text-center">
                    <select className={`border rounded p-1 ${errors[`reason_${index}`] ? "border-red-500" : "border-gray-300"}`} onChange={(e) => handleReasonChange(e, index)}>
                      <option value="">Select Reason</option>
                      <option>Short Received</option>
                      <option>Damage Received</option>
                      <option>Excess Received</option>
                      <option>Wrong Product Delivered</option>
                    </select>
                    {errors[`reason_${index}`] && <p className="text-red-500 text-xs">{errors[`reason_${index}`]}</p>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" onClick={closeProcessModal} size="full" />
          </div>
          <div className="flex-1">
            <PrimaryButton title="Save Changes" onClick={handleDeliveredSaveChange} size="full" />
          </div>
        </div>
      </div>
    </>
  );
};

export default GRNInfoOrderComponent;
