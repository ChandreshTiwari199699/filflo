'use client';
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import moment from 'moment';
import TableFilterBar from '../TableFilterBar/TableFilterBar';
import DynamicTableWithoutAction from '@/app/components/DynamicTableWithoutAction/DynamicTableWithoutAction';
import { filterByDate } from '@/app/components/DateFilter/DateFilter';
import searchNested from '@/app/utils/searchUtils';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { b2bCustomerService } from '@/app/services/b2bCustomerService';
import RightSidebar from '../RightSidebar/RightSidebar';
import ViewCustomerDetails from '../ViewCustomerDetails/ViewCustomerDetails';
import ActionDropdown from '../ActionDropdown/ActionDropdown';
import {
  stickyActionColumnClassname,
  stickyActionRowClassname,
} from '@/app/utils/stickyActionClassname';

const B2BCustomerMaster = () => {
    const [customers, setCustomers] = useState([]);
    const [filteredData, setFilteredData] = useState([]);
    const [searchText, setSearchText] = useState("");
    const [dayFilter, setDayFilter] = useState("all");
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [selectedCustomer, setSelectedCustomer] = useState(null);

    useEffect(() => {
        const fetchCustomers = async () => {
            try {
                const response = await b2bCustomerService.getAllB2BCustomers();
                if (response.success) {
                    setCustomers(response.data);
                } else {
                    toast.error("Failed to fetch customers");
                }  
                    console.log("🚀 ~ fetchCustomers ~ response.data:", response.data)
            } catch (err) {
                console.error(err);
                toast.error("An error occurred while fetching customers");
            }
        };
        fetchCustomers();
    }, []);

    useEffect(() => {
        let data = customers;
        data = filterByDate(data, dayFilter);
        data = data.filter((item) =>
            searchKeys.some((key) => searchNested(item[key], searchText.toLowerCase(), key))
        );
        setFilteredData(data);
    }, [customers, searchText, dayFilter]);

    const searchKeys = ["customerId","name", "phone", "gstNumber", "billing_address", "shipping_address"];

    const convertToCSV = () => {
        const headers = ["Customer ID", "Customer Name", "GST Number", "Billing Address", "Shipping Address", "Created On", "Phone", "Remarks"];

        const rows = filteredData.map((customer) => [
            customer.customerId ?? "N/A",
            `"${customer.name ?? "N/A"}"`,
            `"${customer.gstNumber ?? "N/A"}"`,
            `"${customer.billing_address ?? "N/A"}"`,
            `"${customer.shipping_address ?? "N/A"}"`,
            moment(customer.createdAt).isValid() ? moment(customer.createdAt).format("DD-MMM-YYYY") : "N/A",
            `"${customer.phone ?? "N/A"}"`,
            `"${customer.remarks ?? "N/A"}"`
        ]);
        
    const csvContent = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `B2B_Customers_${moment().format('DD-MMM-YYYY')}.csv`);
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    };
    

    const headings = {
        customerID: {
            label: "Customer ID",
            renderCell: (row) => row.customerId || "N/A",
        },
        name: {
            label: "Customer Name",
            renderCell: (row) => row.name || "N/A",
        },
        gstNumber: {
            label: "GST Number",
            renderCell: (row) => row.gstNumber || "N/A",
        },
        billing_address: {
            label: "Billing Address",
            renderCell: (row) => row.billing_address || "N/A",
        },
        shipping_address: {
            label: "Shipping Address",
            renderCell: (row) => row.shipping_address || "N/A",
        },
        createdAt: {
            label: "Created On",
            renderCell: (row) => moment(row.createdAt).format("DD-MMM-YYYY") || "N/A",
        },
        phone: {
            label: "Phone",
            renderCell: (row) => row.phone || "N/A",
        },
        remarks: {
            label: "Remarks",
            renderCell: (row) => row.remarks || "N/A",
        },
        action: {
            label: "Action",
            renderCell: (row) => <ActionDropdown customer={row} actions={generateActions(row)} />,
            isSticky: true,
            stickyClassHeader: stickyActionColumnClassname,
            stickyClassRow: stickyActionRowClassname,
        },
    };
    
    const generateActions = (customer) => {
        return [
            {
                label: "View Product Details",
                condition: null,
                action: () => openSidebar(customer),
            },
        ];
    };

    const openSidebar = (customer) => {
        setSelectedCustomer(customer);
        setIsSidebarOpen(true);
    };

    const closeSidebar = () => {
        setIsSidebarOpen(false);
        setSelectedCustomer(null);
    };

    return (
        <>
            <TableFilterBar
                searchText={searchText}
                setSearchText={setSearchText}
                convertToCSV={convertToCSV}
                allPO={filteredData}
                handleDayFilterChange={(e) => setDayFilter(e.target.value)}
            />
            <DynamicTableWithoutAction headings={headings} rows={filteredData} />
            <RightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
                {selectedCustomer && <ViewCustomerDetails customer={selectedCustomer} handleCancel={closeSidebar} />}
            </RightSidebar>
        </>
    );
};

export default B2BCustomerMaster;
