'use client';
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import moment from 'moment';
import TableFilterBar from '../TableFilterBar/TableFilterBar';
import DynamicTableWithoutAction from '@/app/components/DynamicTableWithoutAction/DynamicTableWithoutAction';
import { filterByDate } from '@/app/components/DateFilter/DateFilter';
import searchNested from '@/app/utils/searchUtils';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { pricingStrategyService } from '@/app/services/pricingStratergyService';
import RightSidebar from '../RightSidebar/RightSidebar';
import ViewRateCardProducts from '../ViewRateCardProducts/ViewRateCardProducts';
import ActionDropdown from '../ActionDropdown/ActionDropdown';
import {
  stickyActionColumnClassname,
  stickyActionRowClassname,
} from '@/app/utils/stickyActionClassname';
import { number } from 'yup';

const RateCardMaster = () => {
    const [pricingStrategies, setPricingStrategies] = useState([]);
    const [filteredData, setFilteredData] = useState([]);
    const [searchText, setSearchText] = useState("");
    const [dayFilter, setDayFilter] = useState("all");
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [selectedStrategy, setSelectedStrategy] = useState(null);

    useEffect(() => {
        const fetchPricingStrategies = async () => {
            try {
                const response = await pricingStrategyService.getAllPricingStrategies();
                if (response.success) {
                    setPricingStrategies(response.data);
                } else {
                    toast.error("Failed to fetch pricing strategies");
                }  
            } catch (err) {
                console.error(err);
                toast.error("An error occurred while fetching pricing strategies");
            }
        };
        fetchPricingStrategies();
    }, []);

    useEffect(() => {
        let data = pricingStrategies;
        data = filterByDate(data, dayFilter);
        data = data.filter((item) =>
            searchKeys.some((key) => searchNested(item[key], searchText.toLowerCase(), key))
        );
        setFilteredData(data);
    }, [pricingStrategies, searchText, dayFilter]);

    const searchKeys = ["pricingStrategyName", "createdAt"];

    const convertToCSV = () => {
        const headers = ["Rate Card Name", "Created On", "Products"];
        
        const rows = filteredData.map((strategy) => [
            `"${strategy.pricingStrategyName}"`,
            `"${moment(strategy.createdAt).format("DD-MMM-YYYY")}"`,
            `"${strategy.listOfProducts.map(p => `${p.productName} (₹${p.price})`).join("; ")}"`
        ]);
    
        const csvContent = 'data:text/csv;charset=utf-8,' 
            + [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
        
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute('download', `Rate_Card_${moment().format('DD-MMM-YYYY')}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    

    const headings = {
        pricingStrategyName: {
            label: "Rate Card Name",
            renderCell: (row) => row.pricingStrategyName || "N/A",
        },
        createdAt: {
            label: "Created On",
            renderCell: (row) => moment(row.createdAt).format("DD-MMM-YYYY") || "N/A",
        },
        numberOfProducts: {
            label: "Distinct Products",
            renderCell: (row) => row.listOfProducts?.length || 0,
        },
        action: {
            label: "Action",
            renderCell: (row) => <ActionDropdown po={row} actions={generateActions(row)} />,
            isSticky: true,
            stickyClassHeader: stickyActionColumnClassname,
            stickyClassRow: stickyActionRowClassname,
        },
    };
    
    const generateActions = (rateCard) => {
        return [
            {
                label: "View Products",
                condition: null,
                action: () => openSidebar(rateCard),
            },
        ];
    };

    const openSidebar = (strategy) => {
        setSelectedStrategy(strategy);
        setIsSidebarOpen(true);
    };

    const closeSidebar = () => {
        setIsSidebarOpen(false);
        setSelectedStrategy(null);
    };

    return (
        <>
            <TableFilterBar
                searchText={searchText}
                setSearchText={setSearchText}
                convertToCSV={convertToCSV}
                allPO={filteredData}
                handleDayFilterChange={(e) => setDayFilter(e.target.value)}
            />
            <DynamicTableWithoutAction headings={headings} rows={filteredData} />
            <RightSidebar isOpen={isSidebarOpen} onClose={closeSidebar}>
                {selectedStrategy && <ViewRateCardProducts strategy={selectedStrategy} handleCancel={closeSidebar} />}
            </RightSidebar>
        </>
    );
};

export default RateCardMaster;
