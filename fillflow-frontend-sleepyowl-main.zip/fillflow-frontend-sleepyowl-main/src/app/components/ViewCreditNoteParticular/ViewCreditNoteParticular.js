import React, { useState } from "react";
import moment from "moment";
import { PrimaryButton, SecondaryButton } from "../ButtonComponent/ButtonComponent";
import Modal from "../Modal/Modal";
import CreditNote from "../CreditNote/CreditNote";

const ViewCreditNoteParticular = ({ selectedCreditNote, handleCancel }) => {
  const [isCreditNoteOpen, setIsCreditNoteOpen] = useState(false);

  const formatDateTime = (dateString) => {
    if (!dateString) return '';
    const parsedDate = moment(dateString, [
      "DD/MM/YY",
      "DD/MM/YYYY",
      "YYYY-MM-DD",
      "MM/DD/YYYY",
      "YYYY/MM/DD",
      "M/D/YYYY H:mm",
      "M/D/YYYY h:mm A",
      "DD/MM/YYYY HH:mm:ss",
      "x",
      "X",
      moment.ISO_8601
    ], true);
    return parsedDate.isValid() ? parsedDate.format("DD MMM YYYY") : 'Invalid Date';
  };

  const formattedCreditNoteData = {
    seller: {
      companyName: selectedCreditNote?.irnDetails?.requestBody?.SellerDtls?.LglNm || '',
      address: "Khasra no 70/1/2/2, 3,8,9,10/1,11/2,12,13/1, Haily Mandi Road, Farrukhnagar, Khera Khurrampur",
      city: selectedCreditNote?.irnDetails?.requestBody?.SellerDtls?.Loc || '',
      pincode: selectedCreditNote?.irnDetails?.requestBody?.SellerDtls?.Pin || '',
      gstNumber: selectedCreditNote?.irnDetails?.requestBody?.SellerDtls?.Gstin || '',
      panNumber: "AAYCS8675E",
      msmeNumber: "UDYAM-DL-08-0011848",
      fssaiNumber: "13321999000263",
      logo: "HI",
    },
    billing: {
      companyName: selectedCreditNote?.irnDetails?.requestBody?.BuyerDtls.LglNm || '',
      address: selectedCreditNote?.irnDetails?.customerBillingAddress|| '',
      gstNumber: selectedCreditNote?.irnDetails?.requestBody?.BuyerDtls.Gstin || '',
      contactPerson: "N/A", // Add if available
    },
    shipping: {
      companyName: selectedCreditNote?.irnDetails?.requestBody?.BuyerDtls.LglNm || '',
      address: selectedCreditNote?.irnDetails?.customerShippingAddress || '', // Use from order
      gstNumber: selectedCreditNote?.irnDetails?.requestBody?.BuyerDtls.Gstin || '',
      contactPerson: "N/A", // Add if available
    },
    creditNoteDetails: {
      number: selectedCreditNote?.creditNoteId || '',
      date: formatDateTime(selectedCreditNote?.creditNoteDate),
      originalInvoiceId: selectedCreditNote?.originalInvoiceId || '',
      reason: selectedCreditNote?.reason || '',
    },
    items: selectedCreditNote?.irnDetails?.requestBody?.ItemList?.map((item) => ({
      serialNo: item.SlNo || '',
      sku_code: item.PrdDesc || '',
      name : item.PrdName || '',
      case_quantity: (parseFloat(item.PrdCaseSize) || 0) * (parseFloat(item.Qty) || 0),
      gstPercentage : item.GstRt,
      hsn:item.HsnCd || '',
      quantity: item.Qty || 0,
      ratePerUnit: parseFloat(item.UnitPrice) || 0,
      mrpPerUnit: parseFloat(item.PrdMrp) || 0,
      igst: item.IgstAmt || 0,
      cgst: item.CgstAmt || 0,
      sgst: item.SgstAmt || 0,
      totalAmount: (parseFloat(item.Qty) || 0) * ( parseFloat(item.UnitPrice) || 0),
    })) || [],
    irn: {
      number: selectedCreditNote?.irnDetails?.irn || '',
      acknowledgementNo: selectedCreditNote?.irnDetails?.ackNo || '',
      acknowledgementDate: selectedCreditNote?.irnDetails?.ackDate || '',
      qrCode: selectedCreditNote?.irnDetails?.signedQRCode || '',
    },
    totals: {
      subtotal: selectedCreditNote?.irnDetails?.requestBody?.ValDtls?.AssVal || 0,
      totalIgst: selectedCreditNote?.irnDetails?.requestBody?.ValDtls?.IgstVal || 0,
      totalCgst: selectedCreditNote?.irnDetails?.requestBody?.ValDtls?.CgstVal || 0,
      totalSgst: selectedCreditNote?.irnDetails?.requestBody?.ValDtls?.SgstVal || 0,
      grandTotal: selectedCreditNote?.irnDetails?.requestBody?.ValDtls?.TotInvVal || 0,
    },
    gstDetails: selectedCreditNote?.irnDetails?.gstDetails || {},
  };

  // Calculate Bill Details
  const calculateBillDetails = (products) => {
    let totalAmount = 0;
    let totalTaxableAmount = 0;

    const billDetails = products.map((product) => {
      const {
        skuCode,
        quantity,
        ppu: sellingPrice,
        taxSlab,
        productName,
        hsnCode
      } = product;

      // Extract tax percentage from tax_slab
      const taxPercentage = parseFloat(taxSlab?.replace(/[^\d.]/g, '') || 0);

      // Compute Pre-Tax Rate
      const preTaxRate = sellingPrice / (1 + taxPercentage / 100);

      // Compute taxable amount
      const taxableAmount = quantity * preTaxRate;
      totalTaxableAmount += taxableAmount;
      totalAmount += quantity * sellingPrice;

      return {
        skuCode,
        productName,
        hsnCode,
        quantity,
        sellingPrice,
        taxSlab,
        taxPercentage,
        preTaxRate,
        taxableAmount,
        amount: quantity * sellingPrice
      };
    });

    return { billDetails, totalAmount, totalTaxableAmount };
  };

  const { billDetails, totalAmount, totalTaxableAmount } = calculateBillDetails(selectedCreditNote?.listOfProducts || []);

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-20 text-black">
        <h2 className="text-base font-semibold text-[#111928] mb-1">
          View Credit Note Particular
        </h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          See Credit Note details
        </p>

        {/* Credit Note Info */}
        <div className="mb-4">
          <p className="text-sm text-[#4B5563]">
            <span className="font-semibold text-[#111928]">Credit Note ID: </span>
            {selectedCreditNote?.creditNoteId || "N/A"}
          </p>
          <p className="text-sm text-[#4B5563]">
            <span className="font-semibold text-[#111928]">Original Invoice ID: </span>
            {selectedCreditNote?.originalInvoiceId || "N/A"}
          </p>
          <p className="text-sm text-[#4B5563]">
            <span className="font-semibold text-[#111928]">Credit Note Date: </span>
            {formatDateTime(selectedCreditNote?.creditNoteDate)}
          </p>
          <p className="text-sm text-[#4B5563]">
            <span className="font-semibold text-[#111928]">Customer: </span>
            {selectedCreditNote?.customerID?.name || "N/A"}
          </p>
          <p className="text-sm text-[#4B5563]">
            <span className="font-semibold text-[#111928]">Reason: </span>
            {selectedCreditNote?.reason || "N/A"}
          </p>
        </div>

        {/* IRN Details */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-[#111928] mb-2">IRN Details</h3>
          <p className="text-sm text-[#4B5563]">
            <span className="font-semibold text-[#111928]">IRN Number: </span>
            {selectedCreditNote?.irnDetails?.irn || "N/A"}
          </p>
          <p className="text-sm text-[#4B5563]">
            <span className="font-semibold text-[#111928]">Acknowledgement No: </span>
            {selectedCreditNote?.irnDetails?.ackNo || "N/A"}
          </p>
          <p className="text-sm text-[#4B5563]">
            <span className="font-semibold text-[#111928]">Status: </span>
            {selectedCreditNote?.irnDetails?.status || "N/A"}
          </p>
        </div>

        {/* Products Table */}
        <h3 className="text-sm font-semibold text-[#111928] mb-3">Products</h3>
        <table className="min-w-full text-sm text-left bg-[#F8F6F2] rounded-lg">
          <thead className="text-xs text-[#4B5563] font-medium bg-[#F3F4F6]">
            <tr>
              <th className="px-4 py-2">SKU Code</th>
              <th className="px-4 py-2">Product Name</th>
              <th className="px-4 py-2">HSN Code</th>
              <th className="px-4 py-2">Quantity</th>
              <th className="px-4 py-2">Price (₹)</th>
              <th className="px-4 py-2">Tax %</th>
              <th className="px-4 py-2">Pre-Tax Rate (₹)</th>
              <th className="px-4 py-2">Taxable Amount (₹)</th>
              <th className="px-4 py-2">Total Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            {billDetails.map((item, index) => (
              <tr key={index} className={`${index % 2 === 0 ? "bg-white" : "bg-[#F8F6F2]"} text-[#111928]`}>
                <td className="px-4 py-2">{item.skuCode}</td>
                <td className="px-4 py-2">{item.productName}</td>
                <td className="px-4 py-2">{item.hsnCode}</td>
                <td className="px-4 py-2 text-center">{item.quantity}</td>
                <td className="px-4 py-2 text-center">₹{item.sellingPrice.toFixed(2)}</td>
                <td className="px-4 py-2 text-center">{item.taxPercentage}%</td>
                <td className="px-4 py-2 text-center">₹{item.preTaxRate.toFixed(2)}</td>
                <td className="px-4 py-2 text-center">₹{item.taxableAmount.toFixed(2)}</td>
                <td className="px-4 py-2 text-center">₹{item.amount.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Totals */}
        <div className="text-right font-bold text-lg mt-4">
          <p>Total Taxable Amount: <span className="text-blue-600">₹{totalTaxableAmount.toFixed(2)}</span></p>
          <p>Total Tax Amount: <span className="text-blue-600">₹{selectedCreditNote?.totalTaxAmount?.toFixed(2) || "0.00"}</span></p>
          <p>Grand Total: <span className="text-green-600">₹{totalAmount.toFixed(2)}</span></p>
        </div>
      </div>

      {/* Footer Buttons */}
      <div className="absolute bottom-0 left-0 w-full border-t bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
          </div>
          <div className="flex-1">
            {selectedCreditNote?.irnDetails &&
              Object.values(selectedCreditNote.irnDetails).some((value) => value !== null && value !== "") && (
                <PrimaryButton
                  title="View Credit Note"
                  size="full"
                  onClick={() => setIsCreditNoteOpen(true)}
                />
              )}
          </div>
        </div>
      </div>

      {/* Credit Note Modal */}
      <Modal isOpen={isCreditNoteOpen} onClose={() => setIsCreditNoteOpen(false)}>
        <CreditNote data={formattedCreditNoteData} />
      </Modal>
    </>
  );
};

export default ViewCreditNoteParticular; 