import React, { useState, useRef, useEffect } from "react";
import { useDispatch } from "react-redux";
import { getB2BCustomerName, getB2BCustomerValue } from "../../Actions/dropdownValuesActions"; 

const B2BCustomerDropdown = ({ bgColor, height, width, options }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const dispatch = useDispatch();
  const dropdownRef = useRef(null);

  // Handle customer selection
  const handleCustomerChange = (customer) => {
    dispatch(getB2BCustomerValue(customer._id)); 
    dispatch(getB2BCustomerName(customer.name));
    setDropdownVisible(false);
    setSearchTerm(`${customer.customerId} - ${customer.name}`);

  };

  // Handle search input changes
  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
    setDropdownVisible(true);
  };

  // Sort customers by name
  const sortedOptions = [...options].sort((a, b) => a.name.localeCompare(b.name));

  // Filter customers based on search term
  const filteredOptions = sortedOptions.filter((customer) =>
    `${customer.customerId} - ${customer.name}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle clicking outside the dropdown to close it
  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setDropdownVisible(false);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div style={{ width: width || "auto", position: "relative" }} ref={dropdownRef}>
      <input
  type="text"
  value={searchTerm}
  onChange={handleSearchChange}
  onFocus={() => setDropdownVisible(true)}
  placeholder="Search customers..."
  className="w-full p-2 border font-normal text-sm h-10 px-4 bg-white border-gray-300 text-[#4B5563] rounded-xl"
/>

      {dropdownVisible && (
      <div
      className={`absolute z-50 bg-white border border-gray-300 rounded-[6px] max-h-[20vw] overflow-y-auto 
        w-full shadow-md scrollbar-none`}
    >
    
          <ul style={{ listStyleType: "none", padding: "0", margin: "0" }}>
            {filteredOptions.length > 0 ? (
              filteredOptions.map((customer) => (
                <li
                key={customer._id}
                value={customer._id}
                onClick={() => handleCustomerChange(customer)}
                className="px-5 py-3 text-sm font-medium cursor-pointer text-[#111928] hover:bg-[#F5F3FF] hover:text-[#3758F9]"
                onMouseEnter={(e) => e.target.style.backgroundColor = "#f3f4f6"} // Hover effect
                onMouseLeave={(e) => e.target.style.backgroundColor = "white"}   // Reset background
                style={{
                  borderBottom: "1px solid #e5e7eb",
                }}
              >
                {customer.customerId} - {customer.name}
              </li>
              
              ))
            ) : (
              <li
              style={{
                padding: "0.75rem 1rem",
                color: "#9ca3af",               // Subtle gray text
                backgroundColor: "#f9fafb",     // Light background
                textAlign: "center",            // Center text
              }}
            >
              No customers found
            </li>
            
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default B2BCustomerDropdown;
