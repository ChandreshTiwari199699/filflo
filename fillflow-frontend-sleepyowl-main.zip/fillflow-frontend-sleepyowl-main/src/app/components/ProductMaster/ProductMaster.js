'use client';
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import moment from 'moment';
import TableFilterBar from '../TableFilterBar/TableFilterBar';
import DynamicTableWithoutAction from "@/app/components/DynamicTableWithoutAction/DynamicTableWithoutAction";
import { filterByDate } from '@/app/components/DateFilter/DateFilter';
import searchNested from '@/app/utils/searchUtils';
import StatusComponent from "../StatusComponent/StatusComponent";

const ProductMaster = () => {
  const { allProducts } = useSelector((state) => state.product);

    
  const sortedMaterials = [...allProducts].sort((a, b) => {
    return new Date(b.updatedAt) - new Date(a.updatedAt);
  });
  
  const [filteredData, setFilteredData] = useState(sortedMaterials);
  const [searchText, setSearchText] = useState("");
  const [dayFilter, setDayFilter] = useState("all");
   const [filter, setFilter] = useState("allOrders");

  const applyFilters = () => {
    let data = sortedMaterials;
    data = data.filter((item) =>
      searchKeys.some((key) =>
        searchNested(item[key], searchText.toLowerCase(), key)
      )
    );
    data = filterByDate(data, dayFilter);
      // Marketplace filter (if any selected)
  if (filter === "blinkit") {
    data = data.filter((item) => item.blinkit_sku_code);
  } else if (filter === "zepto") {
    data = data.filter((item) => item.zepto_sku_code);
  } else if (filter === "swiggy") {
    data = data.filter((item) => item.swiggy_sku_code);
  }

// Tax slab filter (if any selected)
if (["TAX-05", "TAX-12", "TAX-18"].includes(filter)) {
  data = data.filter((item) => item.tax_slab === filter);
}


    setFilteredData(data);
  };

  useEffect(() => {
    applyFilters();
  }, [ allProducts, searchText, dayFilter,filter]);

  const currentDateAndFileName = `Product_Master_Sheet_${moment().format('DD-MMM-YYYY')}`;

  const convertToCSV = (data = allProducts) => {
    const headers = ['PRODUCT NAME', 'PRODUCT SKU CODE', 'CATEGORY', 'ZEPTO SKU', 'BLINKIT SKU', 'SWIGGY SKU', 'HSN CODE', 'TAX SLAB', 'Price Per Unit', 'CASE SIZE', 'WEIGHT', 'DIMENSION', 'LOWER THRESHOLD', 'UPPER THRESHOLD'];
    const rows = data.map((product) => [
      product?.product_name|| "N/A",
      product?.sku_code|| "N/A",
      product?.product_category_id?.category_name|| "N/A",
      product?.zepto_sku_code|| "N/A",
      product?.blinkit_sku_code|| "N/A",
      product?.swiggy_sku_code|| "N/A",
      product?.hsn_code|| "N/A",
      product?.tax_slab|| "N/A",
      product?.ppu|| "N/A",
      product?.case_size|| "N/A",
      product?.weight|| "N/A",
      product?.dimension|| "N/A",
      product?.lower_threshold|| "N/A",
      product?.upper_threshold|| "N/A",
    ]);
    

    const csvContent = 'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map(row => row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', currentDateAndFileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const searchKeys = [
    "product_name",
    "product_category_id",
    "current_stock",
    "lower_threshold",
    "upper_threshold",
    "sku_code",
    "shopify_sku_code",
    "zepto_sku_code",
    "blinkit_sku_code",
    "swiggy_sku_code",
    "hsn_code",
    "tax_slab",
    "ppu",
    "case_size",
    "weight",
    "dimension"
  ];
  

  const headings = {
    sku_code: { label: "SKU Code", renderCell: (row) => row?.sku_code || "N/A" },
    category_name: { label: "Category", renderCell: (row) => row?.product_category_id?.category_name || "N/A" },
    product_name: { label: "Product Name", renderCell: (row) => row?.product_name || "N/A" },
    zepto_sku_code: { label: "Zepto SKU", renderCell: (row) => row?.zepto_sku_code || "N/A" },
    blinkit_sku_code: { label: "Blinkit SKU", renderCell: (row) => row?.blinkit_sku_code || "N/A" },
    swiggy_sku_code: { label: "Swiggy SKU", renderCell: (row) => row?.swiggy_sku_code || "N/A" },
    hsn_code: { label: "HSN Code", renderCell: (row) => row?.hsn_code || "N/A" },
    tax_slab: { label: "Tax Slab", renderCell: (row) =>  <StatusComponent status={row?.tax_slab}/> || "N/A" },
    ppu: { label: "Price Per Unit", renderCell: (row) => row?.ppu || "N/A" },
    case_size: { label: "Case Size", renderCell: (row) => row?.case_size || "N/A" },
    weight: { label: "Weight", renderCell: (row) => row?.weight || "N/A" },
    dimension: { label: "Dimension", renderCell: (row) => row?.dimension || "N/A" },
    lower_threshold: { label: "Lower Threshold", renderCell: (row) => row?.lower_threshold || "N/A" },
    upper_threshold: { label: "Upper Threshold", renderCell: (row) => row?.upper_threshold || "N/A" },
  };

  const handleDayFilterChange = (event) => {
    setDayFilter(event.target.value);
  };

  const filterOptions = [
    { value: "allProducts", label: "All Products" },
    { value: "blinkit", label: "Blinkit Products" },
  { value: "zepto", label: "Zepto Products" },
  { value: "swiggy", label: "Swiggy Products" },
  { value: "TAX-05", label: "Tax 5%" },
  { value: "TAX-12", label: "Tax 12%" },
   { value: "TAX-18", label: "Tax 18%" }
  ];


  return (
    <>
      <TableFilterBar
           filter={filter}
           setFilter={setFilter}
        searchText={searchText}
        setSearchText={setSearchText}
        convertToCSV={convertToCSV}
        allPO={filteredData}
        filterOptions={filterOptions}
        handleDayFilterChange={handleDayFilterChange}
      />
      <DynamicTableWithoutAction headings={headings} rows={filteredData} />
    </>
  );
};

export default ProductMaster;
