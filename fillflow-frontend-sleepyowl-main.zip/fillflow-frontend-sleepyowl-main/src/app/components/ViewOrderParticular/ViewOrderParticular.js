import React, { useState } from "react";
import moment from "moment";
import { PrimaryButton, SecondaryButton } from "../ButtonComponent/ButtonComponent";
import Invoice from "../Invoice/Invoice";
import DeliveryNote from "../DeliveryNote/DeliveryNote";
import Modal from "../Modal/Modal";


// Ensure formattedInvoiceData is defined properly with data extracted from selectedOrder
const ViewOrderParticular = ({ selectedOrder, handleCancel }) => {
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);
  const [isDeliveryNoteOpen, setIsDeliveryNoteOpen] = useState(false);



  const formatDateTime = (dateString) => {
    if (!dateString) return '';

      // If it's an Excel serial date (numeric string or number)
      const excelSerial = parseFloat(dateString);
      if (!isNaN(excelSerial) && excelSerial > 25569) {
        const utcDays = Math.floor(excelSerial - 25569);
        const utcValue = utcDays * 86400; // seconds since Unix epoch
        const dateInfo = new Date(utcValue * 1000);

        const fractionalDay = excelSerial % 1;
        const totalSeconds = Math.round(fractionalDay * 86400);
        dateInfo.setSeconds(dateInfo.getSeconds() + totalSeconds);

        return moment(dateInfo).format("DD/MM/YYYY");
      }

    const parsedDate = moment(dateString, [
      "M/D/YY H:mm",
      "DD/MM/YY",
      "DD/MM/YYYY",
      "DD/MM/YYYY HH:mm:ss", 
      "DD-MM-YYYY",          
      "D-M-YYYY",
      "YYYY-MM-DD", 
      "YYYY/MM/DD", 
      "MM/DD/YYYY", 
      "M/D/YYYY H:mm", 
      "M/D/YYYY h:mm A", "x", "X", moment.ISO_8601
    ]);
    return parsedDate.isValid() ? parsedDate.format("DD/MM/YYYY") : 'Invalid Date';
  };
  
  

  const formattedInvoiceData = {
    seller: {
      companyName: selectedOrder?.irnDetails?.irnRequestBody?.SellerDtls.LglNm || '',
      address: "Khasra no 70/1/2/2, 3,8,9,10/1,11/2,12,13/1, Haily Mandi Road, Farrukhnagar, Khera Khurrampur" || '',
      city: selectedOrder?.irnDetails?.irnRequestBody?.SellerDtls.Loc || '',
      pincode : selectedOrder?.irnDetails?.irnRequestBody?.SellerDtls.Pin || '',
      gstNumber: selectedOrder?.irnDetails?.irnRequestBody?.SellerDtls.Gstin || '',
      panNumber:"AAYCS8675E",
      msmeNumber:"UDYAM-DL-08-0011848",
      fssaiNumber:"13321999000263",
      logo: "HI", 
    },
    billing: {
      companyName: selectedOrder?.irnDetails?.irnRequestBody?.BuyerDtls.LglNm || '',
      address: selectedOrder?.irnDetails?.customerBillingAddress|| '',
      gstNumber: selectedOrder?.irnDetails?.irnRequestBody?.BuyerDtls.Gstin || '',
      contactPerson: "N/A", // Add if available
    },
    shipping: {
      companyName: selectedOrder?.irnDetails?.irnRequestBody?.BuyerDtls.LglNm || '',
      address: selectedOrder?.irnDetails?.customerShippingAddress || '', // Use from order
      gstNumber: selectedOrder?.irnDetails?.irnRequestBody?.BuyerDtls.Gstin || '',
      contactPerson: "N/A", // Add if available
    },
    invoiceDetails: {
      number: selectedOrder?.irnDetails?.irnRequestBody?.DocDtls?.No || '',
      date: selectedOrder?.irnDetails?.irnRequestBody?.DocDtls?.Dt || '',
      orderNo: selectedOrder?.orderId || 'N/A',
      orderDate: selectedOrder?.orderReceivedDate
      ? formatDateTime(selectedOrder.orderReceivedDate)
      : 'N/A',
    },
    items: selectedOrder?.irnDetails?.irnRequestBody?.ItemList?.map((item) => ({
      serialNo: item.SlNo || '',
      sku_code: item.PrdDesc || '',
      name : item.PrdName || '',
      case_quantity: (parseFloat(item.PrdCaseSize) || 0) * (parseFloat(item.Qty) || 0),
      gstPercentage : item.GstRt,
      hsn:item.HsnCd || '',
      quantity: item.Qty || 0,
      ratePerUnit: parseFloat(item.UnitPrice) || 0,
      mrpPerUnit: parseFloat(item.PrdMrp) || 0,
      igst: item.IgstAmt || 0,
      cgst: item.CgstAmt || 0,
      sgst: item.SgstAmt || 0,
      totalAmount: (parseFloat(item.Qty) || 0) * ( parseFloat(item.UnitPrice) || 0),
    })) || [],
    irn: {
      number: selectedOrder?.irnDetails?.irn || '',
      acknowledgementNo: selectedOrder?.irnDetails?.ackNo || '',
      acknowledgementDate: selectedOrder?.irnDetails?.irnRequestBody?.DocDtls?.Dt || '',
      qrCode: selectedOrder?.irnDetails?.signedQRCode || '', 
    },
    totals: {
      subtotal: selectedOrder?.irnDetails?.irnRequestBody?.ValDtls?.AssVal || 0,
      totalIgst: selectedOrder?.irnDetails?.irnRequestBody?.ValDtls?.IgstVal || 0,
      totalCgst: selectedOrder?.irnDetails?.irnRequestBody?.ValDtls?.CgstVal || 0,
      totalSgst: selectedOrder?.irnDetails?.irnRequestBody?.ValDtls?.SgstVal || 0,
      grandTotal: selectedOrder?.irnDetails?.irnRequestBody?.ValDtls?.TotInvVal || 0,
    },
    gstDetails: selectedOrder?.irnDetails?.gstDetails || [],
    paymentInfo :  selectedOrder?.invoiceWithPaymentInfo
  };
  console.log("🚀 ~ ViewOrderParticular ~ formattedInvoiceData.invoiceDetails.selectedOrder?.orderReceivedDate:",selectedOrder?.orderReceivedDate)

  // Function to get tax percentage from tax slab
  const getTaxPercentage = (tax_slab) => {
    const match = tax_slab.match(/\d+/); // Extract numbers from TAX-XX
    return match ? parseFloat(match[0]) : 0;
  };

  // Calculate Bill Details
  const calculateBillDetails = (products) => {
    let totalAmount = 0;
    let totalTaxableAmount = 0;

    const billDetails = products.map((product) => {
      const {
        _id: { tax_slab, ppu: mrp },
        skuCode, quantity, approvedQuantity, fulfilledQuantity, ppu: sellingPrice
      } = product;

      // Determine the quantity to use
      const finalQuantity = fulfilledQuantity ?? approvedQuantity ?? quantity;

      // Extract tax percentage from tax_slab
      const taxPercentage = getTaxPercentage(tax_slab);

      // Compute Pre-Tax Rate
      const preTaxRate = sellingPrice / (1 + taxPercentage / 100);

      // Compute taxable amount
      const taxableAmount = finalQuantity * preTaxRate;
      totalTaxableAmount += taxableAmount;
      totalAmount += finalQuantity * sellingPrice;

      return {
        skuCode, finalQuantity, sellingPrice, preTaxRate, taxableAmount,
        tax_slab, taxPercentage, mrp, amount: finalQuantity * sellingPrice
      };
    });

    return { billDetails, totalAmount, totalTaxableAmount };
  };

  const { billDetails, totalAmount, totalTaxableAmount } = calculateBillDetails(selectedOrder?.listOfProducts || []);
  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <h2 className="text-base font-semibold text-[#111928] mb-1">
          View Order Particular
        </h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          See order-related data
        </p>

        {/* Product Details Table */}
        <h2 className="text-sm font-semibold text-[#111928] mb-3">
          Products Details
        </h2>
        <table className="min-w-full text-sm text-left bg-[#F8F6F2] rounded-lg">
  <thead className="text-xs text-[#4B5563] font-medium bg-[#F3F4F6]">
    <tr>
      <th className="px-4 py-2">SKU Code</th>
      <th className="px-4 py-2">Desired Units</th>
      <th className="px-4 py-2">Approved Units</th>
      <th className="px-4 py-2">Approval Adjustment Reason</th>
      <th className="px-4 py-2">Fulfilled Units</th>
      <th className="px-4 py-2">Fulfillment Adjustment Reason</th>
    </tr>
  </thead>
  <tbody>
    {selectedOrder?.listOfProducts?.map((product, index) => (
      <tr
        key={index}
        className={`${
          index % 2 === 0 ? "bg-white" : "bg-[#F8F6F2]"
        } text-[#111928]`}
      >
        <td className="px-4 py-2 text-center">{product.skuCode}</td>
        <td className="px-4 py-2 text-center">{product.quantity}</td>
        <td className="px-4 py-2 text-center">
          {product?.approvedQuantity ?? "N/A"}
        </td>
        <td className="px-4 py-2 text-center">
          {product.quantity !== product.approvedQuantity
            ? product.approvedQuantityChangeReason ?? "No reason provided"
            : "-"}
        </td> 
        <td className="px-4 py-2 text-center">
          {product?.fulfilledQuantity ?? "N/A"}
        </td>
        <td className="px-4 py-2 text-center">
  {product.fulfilledQuantity != null
    ? product.fulfilledQuantityChangeReason === "Approved Quantity was 0"
      ? product.fulfilledQuantityChangeReason
      : product.fulfilledQuantity !== product.approvedQuantity
      ? product.fulfilledQuantityChangeReason ?? "No reason provided"
      : "-"
    : "-"}
</td>


      </tr>
    ))}
  </tbody>
</table>



        {/* Product Lifecycle Table */}
        <h2 className="text-sm font-semibold text-[#111928] mt-6 mb-3">
          Product Lifecycle
        </h2>
        <table className="min-w-full text-sm text-left bg-[#F8F6F2] rounded-lg">
          <thead className="text-xs text-[#4B5563] font-medium bg-[#F3F4F6]">
            <tr>
              <th className="px-4 py-2">Milestone</th>
              <th className="px-4 py-2">Date</th>
            </tr>
          </thead>
          <tbody>
            {[
              { label: "Order Received Date", date: selectedOrder?.orderReceivedDate },
              { label: "Punched Date", date: selectedOrder?.createdAt },
              { label: "Scheduled Dispatch Date", date: selectedOrder?.scheduledDispatchDate },
              { label: "Expected Delivery Date", date: selectedOrder?.expectedDeliveryDate },
              { label: "Appointment Date", date: selectedOrder?.appointmentDate },
              { label: "PO Expiry Date", date: selectedOrder?.poExpiryDate },
              { label: "Approved Date", date: selectedOrder?.approvedDate },
              { label: "Invoice Date", date: selectedOrder?.irnDetails?.irnRequestBody?.DocDtls?.Dt },
              { label: "Actual Dispatch Date", date: selectedOrder?.actualDispatchDate },
              { label: "Actual Delivery Date", date: selectedOrder?.deliveryDate },
            ].map((milestone, index) => (
              <tr
                key={index}
                className={`${
                  index % 2 === 0 ? "bg-white" : "bg-[#F8F6F2]"
                } text-[#111928]`}
              >
                <td className="px-4 py-2">{milestone.label}</td>
                <td className="px-4 py-2 text-center">
  {milestone.date ? formatDateTime(milestone.date) : 'N/A'}
</td>

              </tr>
            ))}
          </tbody>
        </table>
        <h2 className="text-sm font-semibold text-[#111928] mt-6 mb-3">Bill Details</h2>
        <table className="min-w-full text-sm text-left bg-[#F8F6F2] rounded-lg">
          <thead className="text-xs text-[#4B5563] font-medium bg-[#F3F4F6]">
            <tr>
              <th className="px-4 py-2">SKU Code</th>
              <th className="px-4 py-2">Quantity</th>
              <th className="px-4 py-2">Selling Price (₹)</th>
              <th className="px-4 py-2">MRP (₹)</th>
              <th className="px-4 py-2">Tax %</th>
              <th className="px-4 py-2">Pre-Tax Rate (₹)</th>
              <th className="px-4 py-2">Taxable Amount (₹)</th>
              <th className="px-4 py-2">Total Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            {billDetails.map((item, index) => (
              <tr key={index} className={`${index % 2 === 0 ? "bg-white" : "bg-[#F8F6F2]"} text-[#111928]`}>
                <td className="px-4 py-2">{item.skuCode}</td>
                <td className="px-4 py-2 text-center">{item.finalQuantity}</td>
                <td className="px-4 py-2 text-center">₹{item.sellingPrice.toFixed(2)}</td>
                <td className="px-4 py-2 text-center">₹{item.mrp.toFixed(2)}</td>
                <td className="px-4 py-2 text-center">{item.taxPercentage}%</td>
                <td className="px-4 py-2 text-center">₹{item.preTaxRate.toFixed(2)}</td>
                <td className="px-4 py-2 text-center">₹{item.taxableAmount.toFixed(2)}</td>
                <td className="px-4 py-2 text-center">₹{item.amount.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* 💵 Grand Total */}
        <div className="text-right font-bold text-lg mt-4">
          Total Taxable Amount: <span className="text-blue-600">₹{totalTaxableAmount.toFixed(2)}</span>
        </div>
        <div className="text-right font-bold text-lg mt-1">
          Grand Total (Including Tax): <span className="text-green-600">₹{totalAmount.toFixed(2)}</span>
        </div>
      </div>

    

      {/* Footer Buttons */}
      <div className="absolute bottom-0 left-0 w-full border-t bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
          </div>
          <div className="flex-1">
            {selectedOrder?.irnDetails &&
              Object.values(selectedOrder.irnDetails).some((value) => value !== null && value !== "") && (
<PrimaryButton
  title={selectedOrder.documentType === 'invoice' ? 'View Invoice' : 'View Delivery Note'}
  size="full"
  onClick={() => {
    if (selectedOrder.documentType === 'invoice') {
      setIsInvoiceOpen(true);
    } else {
      setIsDeliveryNoteOpen(true); // Your custom function for delivery note
    }
  }}
/>
              )}
          </div>
        </div>
      </div>

      {/* Invoice Modal using the Reusable Modal Component */}
      <Modal isOpen={isInvoiceOpen} onClose={() => setIsInvoiceOpen(false)}>
        <Invoice data={formattedInvoiceData} />
      </Modal>
      <Modal isOpen={isDeliveryNoteOpen} onClose={() => setIsDeliveryNoteOpen(false)}>
        <DeliveryNote data={formattedInvoiceData} />
      </Modal>
    </>
  );
};

export default ViewOrderParticular;
