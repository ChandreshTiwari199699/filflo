'use client';
import React, { useEffect, useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useDispatch, useSelector } from "react-redux";
import {
  getAllB2BCustomerRequest,
  getAllB2BCustomerSuccess,
  getAllB2BCustomerFailure,
} from "../../Actions/b2bCustomerActions";
import {
  getAllProductByB2BCustomerIdRequest,
  getAllProductByB2BCustomerIdSuccess,
  getAllProductByB2BCustomerIdFailure,
} from "../../Actions/productActions";
import { b2bCustomerService } from "@/app/services/b2bCustomerService";
import { productServices } from "@/app/services/productService";
import B2BCustomerDropdown from "../B2BCustomerDropdown/B2BCustomerDropdown";
import ProductDropdown from "../ProductDropdown/ProductDropdown";
import CustomDatePicker from "../DatePicker/DatePicker";
import Input from "../Input/Input";
import {
  SecondaryButton,
  PrimaryButton,
} from "../ButtonComponent/ButtonComponent";
import { creditNoteService } from "@/app/services/creditNoteService";

const RaiseCreditNoteForm = ({ onCancel }) => {
  const dispatch = useDispatch();
  const { b2bCustomers } = useSelector((state) => state.b2bCustomer);
  const { allProductsByB2BCustomerId } = useSelector((state) => state.product);
  const { dropDownProductValue, dropdownProductName, dropDownB2BCustomerValue } = useSelector(
    (state) => state.dropdown
  );

  const [formData, setFormData] = useState({
    originalInvoiceId: "",
    invoiceDate: "",
    customerID: "",
    reason: "",
    listOfProducts: [],
  });

  const [productQuantity, setProductQuantity] = useState(null);
  const [errors, setErrors] = useState({});
  const [formDisabled, setFormDisabled] = useState(false);

  const handleDateChange = (newDate) => {
    const adjustedDate = newDate.clone().startOf("day");
    const formattedDate = adjustedDate.format("YYYY-MM-DD HH:mm:ss");
    setFormData((prevFormData) => ({
      ...prevFormData,
      invoiceDate: formattedDate,
    }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handleAddProduct = () => {
    if (!dropDownProductValue || !productQuantity) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        listOfProducts: "Please select a product and enter quantity.",
      }));
      return;
    }
  
    const isProductAlreadyAdded = formData.listOfProducts.some(
      (product) => product.skuCode === dropDownProductValue
    );
  
    if (isProductAlreadyAdded) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        listOfProducts: "This product is already added.",
      }));
      return;
    }
  
    const newProduct = {
      skuCode: dropDownProductValue,
      quantity: productQuantity,
      productName: dropdownProductName,
    };
  
    setFormData((prevFormData) => ({
      ...prevFormData,
      listOfProducts: [...prevFormData.listOfProducts, newProduct],
    }));
  
    setProductQuantity("");
    setErrors((prevErrors) => ({
      ...prevErrors,
      listOfProducts: "",
    }));
  };

  const handleRemoveProductsFromList = (index) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      listOfProducts: prevFormData.listOfProducts.filter((_, i) => i !== index),
    }));
  };

  useEffect(() => {
    if (dropDownB2BCustomerValue) {
      setFormData((prevFormData) => ({
        ...prevFormData,
        customerID: dropDownB2BCustomerValue,
      }));
    }
  }, [dropDownB2BCustomerValue]);

  const getAllB2BCustomers = async () => {
    try {
      dispatch(getAllB2BCustomerRequest());
      const response = await b2bCustomerService.getAllB2BCustomers();
      if (response.success === true) {
        dispatch(getAllB2BCustomerSuccess(response.data));
      }
    } catch (err) {
      console.log(err);
      dispatch(getAllB2BCustomerFailure());
    }
  };

  const getProductByB2BCustomerID = async () => {
    dispatch(getAllProductByB2BCustomerIdSuccess([]));
    dispatch(getAllProductByB2BCustomerIdRequest());
    try {
      const response = await productServices.getAllProductsByB2BCustomerId(
        dropDownB2BCustomerValue
      );
      if (response.success === true) {
        dispatch(getAllProductByB2BCustomerIdSuccess(response.data));
      }
    } catch (err) {
      console.log(err);
      dispatch(getAllProductByB2BCustomerIdFailure());
    }
  };

  useEffect(() => {
    getAllB2BCustomers();
  }, []);

  useEffect(() => {
    if (dropDownB2BCustomerValue) {
      getProductByB2BCustomerID();
    }
  }, [dropDownB2BCustomerValue]);

  const validateForm = () => {
    const newErrors = {};
    if (!formData.originalInvoiceId) newErrors.originalInvoiceId = "Invoice ID is required.";
    if (!formData.invoiceDate) newErrors.invoiceDate = "Invoice date is required.";
    if (!formData.customerID) newErrors.customerID = "Customer ID is required.";
    if (!formData.reason) newErrors.reason = "Reason is required.";
    if (formData.listOfProducts.length === 0)
      newErrors.listOfProducts = "At least one product must be added.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setFormDisabled(true);
      
      const creditNoteData = {
        originalInvoiceId: formData.originalInvoiceId,
        originalInvoiceDate: formData.invoiceDate,
        customerID: formData.customerID,
        reason: formData.reason,
        listOfProducts: formData.listOfProducts.map(product => ({
          skuCode: product.skuCode,
          quantity: parseInt(product.quantity),
        }))
      };

      const response = await creditNoteService.createCreditNote(creditNoteData);
      
      if (response.success) {
        toast.success('Credit note raised successfully', {
          autoClose: 1500,
          onClose: () => window.location.reload(),
        });
      } else {
        toast.error(response.message || 'Failed to raise credit note');
        setFormDisabled(false);
      }
    } catch (error) {
      console.error('Error raising credit note:', error);
      toast.error('Failed to raise credit note: ' + error.message);
      setFormDisabled(false);
    }
  };

  return (
    <>
    <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
      <ToastContainer position="bottom-center"/>
      <h2 className="text-base font-semibold text-[#111928] mb-1">
        Raise Credit Note
      </h2>
      <p className="text-sm font-normal text-[#4B5563] mb-1">
  Create a credit note for B2B customer.
</p>
<p className="text-xs text-red-500 mb-6 ml-[2px]">
  (Please ensure you enter the correct invoice ID to raise it against) 
</p>


      <div className="flex flex-col mb-6">
        <label className="block text-[#111928] text-sm font-medium mb-1">
          Invoice ID
          <span className="text-[#9CA3AF] ml-[2px]">*</span>
        </label>
        <Input
          bgColor={"bg-[#F8F6F2]"}
          radius={"rounded-lg"}
          height={"h-[3.5vw] min-h-[3.5vh]"}
          padding={"p-[1vw]"}
          type={"text"}
          color={"text-[#838481]"}
          textSize={"text-[1vw]"}
          fontWeight={"font-medium"}
          name="originalInvoiceId"
          value={formData.originalInvoiceId}
          onChange={handleChange}
        />
        {errors.originalInvoiceId && (
          <p className="text-red-500 text-xs">{errors.originalInvoiceId}</p>
        )}
      </div>

      <div className="flex flex-col mb-6">
        <CustomDatePicker
          onDateChange={handleDateChange}
          label="Invoice Date"
          className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-[1vw] font-medium"
        />
        {errors.invoiceDate && (
          <p className="text-red-500 text-xs">{errors.invoiceDate}</p>
        )}
      </div>

      <div className="flex flex-col mb-6">
        <label className="block text-[#111928] text-sm font-medium mb-1">
          Select Customer
          <span className="text-[#9CA3AF] ml-[2px]">*</span>
        </label>
        <B2BCustomerDropdown
          bgColor={"#F8F6F2"}
          options={b2bCustomers}
        />
        {errors.customerID && (
          <p className="text-red-500 text-xs">{errors.customerID}</p>
        )}
      </div>

      <div className="flex flex-col mb-6">
        <label className="block text-[#111928] text-sm font-medium mb-1">
          Reason
          <span className="text-[#9CA3AF] ml-[2px]">*</span>
        </label>
        <Input
          bgColor={"bg-[#F8F6F2]"}
          radius={"rounded-lg"}
          height={"h-[3.5vw] min-h-[3.5vh]"}
          padding={"p-[1vw]"}
          type={"text"}
          color={"text-[#838481]"}
          textSize={"text-[1vw]"}
          fontWeight={"font-medium"}
          name="reason"
          value={formData.reason}
          onChange={handleChange}
          placeholder="Enter reason for credit note"
        />
        {errors.reason && (
          <p className="text-red-500 text-xs">{errors.reason}</p>
        )}
      </div>

      <label className="block text-[#111928] text-sm font-medium mb-1">List Of Products</label>
      <div className="flex flex-col p-4 border-2 border-[#F8F6F2] rounded-lg bg-white">
        <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">
            Select Product
            <span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <ProductDropdown
            name="product_id"
            bgColor={"#F8F6F2"}
            options={allProductsByB2BCustomerId}
          />
        </div>

        <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">
            Quantity
            <span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <Input
            bgColor={"bg-[#F8F6F2]"}
            radius={"rounded-lg"}
            height={"h-[3.5vw] min-h-[3.5vh]"}
            padding={"p-[1vw]"}
            type={"number"}
            color={"text-[#838481]"}
            textSize={"text-[1vw]"}
            fontWeight={"font-medium"}
            name="quantity"
            placeholder={"Enter Quantity here"}
            value={productQuantity}
            onChange={(e) => setProductQuantity(e.target.value)}
          />
        </div>

        <div className="flex-1">
          <PrimaryButton
            title="Add Product"
            onClick={handleAddProduct}
            size='full'
            bgColor="bg-primary"
          />
        </div>

        {errors.listOfProducts && (
          <p className="text-red-500 text-xs">{errors.listOfProducts}</p>
        )}

        <div className="mt-2">
          {formData.listOfProducts.length > 0 && <label>Products:</label>}
          <ul className="flex flex-wrap gap-4">
            {formData.listOfProducts.map((product, index) => (
              <li
                key={index}
                className="awb-number border bg-[#F8F6F2] text-black rounded-lg p-2 text-sm text-start flex-[0_0_calc(45%-0.5rem)]"
                onClick={() => handleRemoveProductsFromList(index)}
              >
                <span className="remove-text text-xs font-semibold">
                  Remove
                </span>
                <div className="flex flex-col">
                  <span className="number px-3 text-black">
                    Product Name: {product?.productName}
                  </span>
                  <span className="number px-3 text-black">
                    Product Quantity: {product?.quantity}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
      </div>

      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" size='full' onClick={onCancel} />
          </div>
          <div className="flex-1">
            <PrimaryButton
              title="Raise Credit Note"
              onClick={handleSubmit}
              size='full'
              bgColor="bg-primary"
            />
          </div>
        </div>
      </div>

      {formDisabled && (
        <div
          className="fixed top-0 left-0 w-full h-full bg-gray-400 opacity-50 z-50"
          style={{ zIndex: 1000 }}
        />
      )}
 
    </>
  );
};

export default RaiseCreditNoteForm; 