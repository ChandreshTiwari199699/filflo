import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import CategoryDropdown from "@/app/components/CategoryDropdown/CategoryDropdown";
import SKUDropdown from "../SKUDropdown/SKUDropdown";
import Input from "../Input/Input";
import { categoryServices } from "@/app/services/categoryService";
import {
  getAllCategorySuccess,
  getAllCategoryRequest,
} from "../../Actions/categoryActions";
import {
    getAllSuppliersFailure,
    getAllSuppliersRequest,
    getAllSuppliersSuccess
  } from "../../Actions/supplierActions";
import {
  getSKUByCategoryFailure,
  getSKUByCategoryRequest,
  getSKUByCategorySuccess,
} from "../../Actions/skuActions";
import { sfgCategories } from "@/app/constants/categoryConstants";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  SecondaryButton,
  PrimaryButton,
} from "../ButtonComponent/ButtonComponent";
import { skuServices } from "@/app/services/skuServices";
import { procurementPOServices } from "@/app/services/procurementPOService";
import SupplierDropdown from "../SupplierDropdown/SupplierDropdown";
import { supplierService } from "@/app/services/supplierService";

const CreateProcurementPO = ({ onCancel }) => {
  const { allCategories, selectedCatId } = useSelector(
    (state) => state.category
  );
  const { suppliers } = useSelector(
    (state) => state.supplier
  );
  const { skusByCategory } = useSelector((state) => state.sku);
  const { dropDownSKUName, dropDownSKUValue } = useSelector((state) => state.dropdown);
  const { dropDownSupplierName, dropDownSupplierValue } = useSelector((state) => state.dropdown);
  const [selectedSKU, setSelectedSKU] = useState(null);
  const [quantity, setQuantity] = useState(null);
  const [price, setPrice] = useState(null);
  const [listData, setListData] = useState([]);
  const [errors, setErrors] = useState({});
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);

  const addItemsToList = () => {
    if (!selectedSKU || !quantity || !price || !dropDownSupplierValue) {
        setErrors({
          selectedSKU: !selectedSKU ? "Please select an SKU." : undefined,
          quantity: !quantity ? "Please enter a quantity." : undefined,
          price: !price ? "Please enter a price." : undefined,
          supplier: !dropDownSupplierValue ? "Please select a supplier." : undefined
        });
        return;
      }

      const isDuplicate = listData.some((item) => item.sku === selectedSKU);
      if (isDuplicate) {
        toast.error("This SKU is already added to the list.");
        return;
      }
      
      setListData([
        ...listData,
        {
          sku: selectedSKU,
          quantity,
          price,
          skuName: dropDownSKUName
        }
      ]);
      
      setSelectedSKU(null);
      setQuantity(null);
      setPrice(null);
      setErrors({});
      
  };

  const getAllCategories = async () => {
    try {
      dispatch(getAllCategoryRequest());
      const response = await categoryServices.getAllCategories();
      const fgCategories = response.data.filter((category) =>
        sfgCategories.includes(category.category_name)
      );
      if (response.success) {
        dispatch(getAllCategorySuccess(fgCategories));
      }
    } catch (err) {
      console.error(err);
    }
  };

    useEffect(() => {
     setSelectedSKU (dropDownSKUValue);
    }, [dropDownSKUName]);


    const getAllSuppliers = async () => {
        try {
          dispatch(getAllSuppliersRequest());
          const response = await supplierService.getAllSuppliers();
          if (response.success) {
            dispatch(getAllSuppliersSuccess(response.data));
          }
        } catch (err) {
          console.error("Failed to fetch suppliers:", err);
        }
      };
      

      useEffect(() => {
        getAllSuppliers();
      }, []);
      

  const getSKUByCatId = async () => {
    try {
      dispatch(getSKUByCategoryRequest());
      const response = await skuServices.getSKUsByCategoryId(selectedCatId);
      if (response.success) {
        dispatch(getSKUByCategorySuccess(response.data));
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    getSKUByCatId();
  }, [selectedCatId]);

  useEffect(() => {
    getAllCategories();
  }, []);


  const removeItem = (index) => {
    const updatedList = [...listData];
    updatedList.splice(index, 1);
    setListData(updatedList);
  };
  

  const createPO = async () => {
    if (!dropDownSupplierValue) {
      toast.error("Please select a supplier.");
      return;
    }
    if (listData.length === 0) {
      toast.error("Please add at least one item to the list.");
      return;
    }
    setLoading(true);
  
    try {
      const payload = {
        supplier_id: dropDownSupplierValue,
        items: listData.map(item => ({
          sku_id: item.sku,
          quantity_ordered: item.quantity,
          price: item.price,
        })),
      };
      
  
      const response = await procurementPOServices.createProcurementPO(payload);
  
      if (response.success) {
        toast.success("Procurement PO raised successfully!", {
          autoClose: 1500,
          onClose: () => {
            window.location.reload();
          },
        });
        setListData([]);
      } else {
        toast.error(response.message || "Error creating Procurement PO." , {
          autoClose: 1500,
          onClose: () => {
            window.location.reload();
          },
        });
      }
    } catch (error) {
      toast.error(error.message || "Error creating Procurement PO." , {
        autoClose: 1500,
        onClose: () => {
          window.location.reload();
        },
      });
    } finally {
      setLoading(false);
    }
  };
  
  

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <ToastContainer position="bottom-center" />
        <h2 className="text-base font-semibold text-[#111928] mb-1">
          Raise Procurement PO
        </h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
           Choose a supplier, add SKU items with quantities and prices, and create a Procurement PO.
        </p>

        <div className="flex flex-col my-6">
        <label className="text-[#111928] text-sm font-medium mb-1">
            Supplier Name<span className="text-[#9CA3AF] ml-[2px]">*</span>
        </label>
        <SupplierDropdown options={suppliers}/>
        </div>


        <div className="flex flex-col my-6">
          <label className="text-[#111928] text-sm font-medium mb-1">
            Category Name<span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <CategoryDropdown options={allCategories} />
        </div>

        <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">
            Select SKU<span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <SKUDropdown
            name="selectedSKU"
            options={skusByCategory}
            value={selectedSKU}
            onChange={(e) => {
              setSelectedSKU(e.target.value);
              setErrors((prev) => ({ ...prev, selectedSKU: undefined }));
            }}
          />
          {errors.selectedSKU && (
            <p className="text-xs mt-1 ml-1 text-red-500">{errors.selectedSKU}</p>
          )}
        </div>

        <div className="flex flex-col mb-6">
          <label className="block text-[#111928] text-sm font-medium mb-1">
            Quantity<span className="text-[#9CA3AF] ml-[2px]">*</span>
          </label>
          <Input
            type="number"
            name="quantity"
            value={quantity || ""}
            onChange={(e) => {
              setQuantity(e.target.value);
              setErrors((prev) => ({ ...prev, quantity: undefined }));
            }}
            placeholder="Enter Quantity"
          />
          {errors.quantity && (
            <p className="text-xs mt-1 ml-1 text-red-500">{errors.quantity}</p>
          )}
        </div>

        <div className="flex flex-col mb-6">
  <label className="block text-[#111928] text-sm font-medium mb-1">
    Price<span className="text-[#9CA3AF] ml-[2px]">*</span>
  </label>
  <Input
    type="number"
    name="price"
    value={price || ""}
    onChange={(e) => {
      setPrice(e.target.value);
      setErrors((prev) => ({ ...prev, price: undefined }));
    }}
    placeholder="Enter Price"
  />
  {errors.price && (
    <p className="text-xs mt-1 ml-1 text-red-500">{errors.price}</p>
  )}
</div>


        <div className="mt-3">
          <SecondaryButton title="+ Add Item" onClick={addItemsToList} />
        </div>

        {listData.length > 0 && (
          <div className="mt-4">
            <h2 className="text-base font-semibold text-dark mb-2">
              Selected Items: {listData.length}
            </h2>
            <ul className="flex flex-col gap-2">
  {listData.map((item, idx) => (
    <li
      key={idx}
      className="shadow-sm rounded-lg py-3 bg-white flex items-center justify-between px-4"
    >
      <div className="flex flex-col">
        <div className="text-sm text-dark-4 font-medium">SKU: {item.skuName}</div>
        <div className="text-sm text-dark-4">Quantity: {item.quantity}</div>
        <div className="text-sm text-dark-4">Price: ₹{item.price}</div>
      </div>
      <button
        onClick={() => removeItem(idx)}
        className="text-red-500 text-sm underline hover:text-red-700"
      >
        Remove
      </button>
    </li>
  ))}
</ul>

          </div>
        )}
      </div>

      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" width="w-full" onClick={onCancel} />
          </div>
          <div className="flex-1">
            <PrimaryButton
              title="Raise Production PO"
              onClick={createPO}
              disabled={listData.length === 0}
              width="w-full"
            />
          </div>
        </div>
      </div>

      {loading && (
      <div
        className="fixed top-0 left-0 w-full h-full bg-gray-400 opacity-50 z-50"
        style={{ zIndex: 1000 }}
      />
    )}
    </>
  );
};

export default CreateProcurementPO;
