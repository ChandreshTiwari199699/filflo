"use client";
import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Input from "@/app/components/Input/Input";
import { PrimaryButton, SecondaryButton } from "@/app/components/ButtonComponent/ButtonComponent";
import { b2bOrderService } from "@/app/services/b2bOrderService";

const ReadyToShipOrderComponent = ({ selectedOrder, handleCancel }) => {
  const [processOrderData, setProcessOrderData] = useState({
    orderInternalId: selectedOrder?._id || "",
    awbNumber: selectedOrder?.awbNumber || "",
    status: selectedOrder?.status || "",
    shippingPartner: selectedOrder?.shippingPartner || "",
    invoiceDate: selectedOrder?.invoiceDate || "",
    invoiceId: selectedOrder?.invoiceId || "",
    actualDispatchDate: selectedOrder?.actualDispatchDate || "",
    deliveryDate: selectedOrder?.deliveryDate || "",
    proofOfDelivery: selectedOrder?.proofOfDelivery || "",
  });

  const [errors, setErrors] = useState({});
  const [isReadyToShipChecked, setIsReadyToShipChecked] = useState(false);

  const handleProcessChange = (e) => {
    const { name, value } = e.target;
    setProcessOrderData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSaveChanges = async (e) => {
    e.preventDefault();

    const { awbNumber, shippingPartner } = processOrderData;
    const newErrors = {};
    if (!awbNumber) newErrors.awbNumber = "AWB Number is required.";
    if (!shippingPartner) newErrors.shippingPartner = "Shipping Partner is required.";
    if (!isReadyToShipChecked) newErrors.status = "Shipping status must be marked as ready to ship.";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      const updatedData = {
        ...processOrderData,
        status: isReadyToShipChecked ? "ready_to_ship" : processOrderData.status,
      };

      const result = await b2bOrderService.editB2BOrderByOrderInternalId(updatedData);

      if (result.success) {
        toast.success("B2B Order processed successfully!", {
          autoClose: 1500,
          onClose: () => {
            window.location.reload();
          },
        });
      } else {
        toast.error(`Failed to process order: ${result.error}`);
      }
    } catch (error) {
      toast.error("An error occurred while processing the order.");
    }
  };

  return (
    <>
      <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
        <ToastContainer position="bottom-center" />
        <h2 className="text-base font-semibold text-[#111928] mb-1">Enter Shipping Details</h2>
        <p className="text-sm font-normal text-[#4B5563] mb-6">
          Update the shipping details to process the order.
        </p>

        {processOrderData.status === "picked" && (
          <>
            {/* AWB Number */}
            <div className="mb-4">
              <label className="block text-[#111928] text-sm font-medium mb-1">AWB NUMBER <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
              <input
                type="text"
                name="awbNumber"
                value={processOrderData.awbNumber}
                onChange={handleProcessChange}
                className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
                  errors.awbNumber ? "border-red-500" : "border-gray-300"
                }`}
              />
              {errors.awbNumber && (
                <div className="text-red-500 text-xs mt-1">{errors.awbNumber}</div>
              )}
            </div>

            {/* Shipping Partner */}
            <div className="mb-4">
              <label className="block text-[#111928] text-sm font-medium mb-1">Shipping Partner <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
              <select
                name="shippingPartner"
                value={processOrderData.shippingPartner}
                onChange={handleProcessChange}
                className={`border rounded-lg w-full px-4 py-2 text-sm text-[#111928] font-medium bg-white focus:outline-none ${
                  errors.shippingPartner ? "border-red-500" : "border-gray-300"
                }`}
              >
                <option value="" className="text-[#9CA3AF] text-xs font-normal"
                >Select a Shipping Partner</option>
                <option value="Movin" className="text-[#9CA3AF] text-sm font-medium">Movin</option>
                <option value="DPWorld" className="text-[#9CA3AF] text-sm font-medium">DPWorld</option>
                <option value="UTS"className="text-[#9CA3AF] text-sm font-medium" >UTS</option>
                <option value="Delhivery"className="text-[#9CA3AF] text-sm font-medium" >Delhivery</option>
                <option value="Vishwakarma-Transports"className="text-[#9CA3AF] text-sm font-medium" >Vishwakarma-Transports</option>
                <option value="Others"className="text-[#9CA3AF] text-sm font-medium" >Others</option>
              </select>
              {errors.shippingPartner && (
                <div className="text-red-500 text-xs mt-1">{errors.shippingPartner}</div>
              )}
            </div>

            {/* Ready to Ship Checkbox */}
            <div className="mb-4 flex flex-col">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  name="status"
                  checked={isReadyToShipChecked}
                  onChange={(e) => setIsReadyToShipChecked(e.target.checked)}
                  className={`w-4 h-4 text-blue-600 border-gray-300 rounded ${
                    errors.status ? "border-red-500" : "border-gray-300"
                  }`}
                />
                <label className="ml-2 text-sm font-medium">Mark as Ready to Ship <span className="text-[#9CA3AF] ml-[2px]">*</span></label>
              </div>
              {errors.status && (
                <div className="text-red-500 text-xs mt-1">{errors.status}</div>
              )}
            </div>
          </>
        )}
      </div>

      {/* Buttons */}
      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
          <div className="flex-1">
            <SecondaryButton title="Cancel" onClick={handleCancel} size="full" />
          </div>
          <div className="flex-1">
            <PrimaryButton title="Save Changes" onClick={handleSaveChanges} size="full" />
          </div>
        </div>
      </div>
    </>
  );
};

export default ReadyToShipOrderComponent;
