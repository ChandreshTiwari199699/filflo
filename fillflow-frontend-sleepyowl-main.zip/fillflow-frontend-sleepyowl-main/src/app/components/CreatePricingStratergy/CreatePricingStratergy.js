'use client';
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import B2BCustomerDropdown from "../B2BCustomerDropdown/B2BCustomerDropdown";
import {
    getAllProductByCatIdRequest,
    getAllProductByCatIdSuccess,
    getAllProductByCatIdFailure,
  } from "../../Actions/productActions";
  import {
    getAllCategorySuccess,
    getAllCategoryRequest,
    getAllCategoryFailure,
  } from "../../Actions/categoryActions";
import CategoryDropdown from "../CategoryDropdown/CategoryDropdown";
import ProductDropdown from "../ProductDropdown/ProductDropdown";
import Button from "../Button/Button";
import Input from "../Input/Input";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { productServices } from "@/app/services/productService";
import { categoryServices } from "@/app/services/categoryService";
import { sfgCategories } from "@/app/constants/categoryConstants";
import { pricingStrategyService } from "@/app/services/pricingStratergyService";

const CreatePricingStrategy = () => {
  const dispatch = useDispatch();
  const { allCategories, selectedCatId } = useSelector((state) => state.category);
  const { allProductsByCatId } = useSelector((state) => state.product);
  const { dropDownProductValue, dropdownProductName } = useSelector((state) => state.dropdown);

  const [pricingStrategyName, setPricingStrategyName] = useState("");
  const [productPrice, setProductPrice] = useState("");
  const [listOfProducts, setListOfProducts] = useState([]);
  const [errors, setErrors] = useState({});
  const [pricingMode, setPricingMode] = useState("ppu"); 
  const [discountPercentage, setDiscountPercentage] = useState("");


  const handleAddProduct = () => {
    if (!pricingStrategyName) {
      setErrors((prev) => ({ ...prev, pricingStrategyName: "Rate Card Name is required." }));
      return;
    }
    if (!dropDownProductValue) {
      setErrors((prev) => ({ ...prev, product: "Please select a product." }));
      return;
    }
    if (pricingMode === "ppu" && !productPrice) {
      setErrors((prev) => ({ ...prev, product: "Enter a valid price per unit." }));
      return;
    }
    if (listOfProducts.some((product) => product.productId === dropDownProductValue)) {
      setErrors((prev) => ({ ...prev, product: "This product is already added." }));
      return;
    }

    const newProduct = {
      productId: dropDownProductValue,
      productName: dropdownProductName,
      price: pricingMode === "ppu" ? productPrice : null,
    };

    setListOfProducts((prev) => [...prev, newProduct]);
    setProductPrice("");
    setErrors((prev) => ({ ...prev, product: "" }));
  };

  const handleRemoveProduct = (index) => {
    setListOfProducts((prev) => prev.filter((_, i) => i !== index));
  };

    useEffect(() => {
      const getAllCategories = async () => {
        try {
          dispatch(getAllCategoryRequest());
          const response = await categoryServices.getAllCategories();
          const fgCategories = response.data.filter(
            (category) => !sfgCategories.includes(category.category_name)
          );
          if (response.success) {
            dispatch(getAllCategorySuccess(fgCategories));
          }
        } catch (err) {
          console.error(err);
          dispatch(getAllCategoryFailure());
        }
      };
  
      getAllCategories();
    }, [dispatch]);


      useEffect(() => {
        const getProductByCatId = async () => {
          try {
            dispatch(getAllProductByCatIdRequest());
            const response = await productServices.getAllProductsByCatId(selectedCatId);
            if (response.success) {
              dispatch(getAllProductByCatIdSuccess(response.data));
            }
          } catch (err) {
            console.error(err);
            dispatch(getAllProductByCatIdFailure());
          }
        };
    
        if (selectedCatId) {
          getProductByCatId();
        }
      }, [selectedCatId, dispatch]);

      const handleFormSubmit = async () => {
        setErrors({}); // Clear previous errors
      
        if (!pricingStrategyName) {
          setErrors((prev) => ({
            ...prev,
            pricingStrategyName: "Rate Card Name is required.",
          }));
          return;
        }

        if (pricingMode === "discount" && (!discountPercentage || discountPercentage <= 0)) {
          setErrors((prev) => ({
            ...prev,
            discount: "Enter a valid discount percentage.",
          }));
          return;
        }

        if (listOfProducts.length === 0) {
          setErrors((prev) => ({
            ...prev,
            product: "At least one product must be added.",
          }));
          return;
        }

       
      
        const formData = {
          pricingStrategyName,
          pricingMode,
          listOfProducts: pricingMode === "ppu" ? listOfProducts : listOfProducts.map(({ productId, productName }) => ({ productId, productName })),
          discountPercentage: pricingMode === "discount" ? discountPercentage : null, 
        };
      
      
        try {
          const response = await pricingStrategyService.createPricingStrategy(formData);
          
          if (response?.success) {
            toast.success("Rate Card Created Successfully!", { autoClose: 1500 });
      
            // Optionally reset form
            setPricingStrategyName("");
            setListOfProducts([]);
          } else {
            throw new Error(response?.message || "Unexpected error occurred.");
          }
        } catch (error) {
          console.error("❌ Error:", error);
          toast.error(error?.response?.data?.message || error.message || "Failed to Create Rate Card.");
        }
      };
      

  return (
    <div className="h-[78vh] min-h-[78vh] max-h-[78vh] overflow-y-scroll">
      <ToastContainer />

      <h2 className="text-base font-semibold text-[#111928] mb-1">Create Rate Card</h2>
      <p className="text-sm font-normal text-[#4B5563] mb-6">Define your Rate Card by adding products and ppu or discount percentage and products.</p>

      {/* Pricing Strategy Name */}
      <div className="flex flex-col mb-3">
        <label className="block text-[#111928] text-sm font-medium mb-1">
          Rate Card Name <span className="text-red-500">*</span>
        </label>
        <Input
          bgColor="bg-[#F8F6F2]"
          radius="rounded-lg"
          height="h-[3.5vw] min-h-[3.5vh]"
          padding="p-[1vw]"
          type="text"
          color="text-[#838481]"
          textSize="text-[1vw]"
          fontWeight="font-medium"
          name="pricingStrategyName"
          value={pricingStrategyName}
          onChange={(e) => setPricingStrategyName(e.target.value)}
        />
        {errors.pricingStrategyName && <p className="text-red-500 text-xs">{errors.pricingStrategyName}</p>}
      </div>

      <div className="flex gap-4 mb-4">
  <label className="flex items-center">
    <input
      type="radio"
      name="pricingMode"
      value="ppu"
      checked={pricingMode === "ppu"}
      onChange={() => setPricingMode("ppu")}
    />
    <span className="ml-2">Enter Price Per Unit</span>
  </label>
  <label className="flex items-center">
    <input
      type="radio"
      name="pricingMode"
      value="discount"
      checked={pricingMode === "discount"}
      onChange={() => setPricingMode("discount")}
    />
    <span className="ml-2">Apply Percentage-Based Discount to All</span>
  </label>
</div>

{pricingMode === "discount" && (
  <div className="flex flex-col">
    <label className="block text-[#111928] text-sm font-medium mb-1">Discount Percentage</label>
    <Input
      bgColor="bg-[#F8F6F2]"
      radius="rounded-lg"
      height="h-[3.5vw] min-h-[3.5vh]"
      padding="p-[1vw]"
      type="number"
      color="text-[#838481]"
      textSize="text-[1vw]"
      fontWeight="font-medium"
      name="discountPercentage"
      placeholder="Enter discount percentage"
      value={discountPercentage}
      onChange={(e) => setDiscountPercentage(e.target.value)}
    />
    
  </div>
)}

{errors.discount && <p className="text-red-500 text-xs">{errors.discount}</p>}


      {/* Product Selection */}
      <label className="block text-[#111928] text-sm font-medium mb-1">Select Products</label>
      <div className="flex flex-col p-4 border-2 border-[#F8F6F2] rounded-lg bg-white">
        <div className="flex flex-col mb-3">
          <label className="block text-[#111928] text-sm font-medium mb-1">Select Category</label>
          <CategoryDropdown bgColor="#F8F6F2" options={allCategories} />
        </div>
        <div className="flex flex-col mb-3">
          <label className="block text-[#111928] text-sm font-medium mb-1">Select Product</label>
          <ProductDropdown name="product_id" bgColor="#F8F6F2" options={allProductsByCatId} />
        </div>
        {pricingMode === "ppu" && (
    <div className="flex flex-col mb-3">
      <label>Price Per Unit</label>
      <Input
        bgColor="bg-[#F8F6F2]"
        radius="rounded-lg"
        height="h-[3.5vw] min-h-[3.5vh]"
        padding="p-[1vw]"
        type="number"
        color="text-[#838481]"
        textSize="text-[1vw]"
        fontWeight="font-medium"
        name="price"
        placeholder="Enter Price per unit here"
        value={productPrice}
        onChange={(e) => setProductPrice(e.target.value)}
      />
     
    </div>
  )}

{errors.product && <p className="text-red-500 text-xs mt-1">{errors.product}</p>}

        <div onClick={handleAddProduct} className="mt-2">
          <Button
            title="Add Product"
            bgColor="bg-[rgb(79,201,218)]"
            radius="rounded-lg"
            height="h-[3vw] min-h-[3vh]"
            padding="p-[1vw]"
            color="text-[#ffff]"
            textSize="text-[1vw]"
            fontWeight="font-medium"
            width="w-[10vw]"
          />
        </div>
      </div>

      {/* Product List */}
      <div className="mt-4">
        {listOfProducts.length > 0 && <label>Products:</label>}
        <ul className="flex flex-col gap-4">
          {listOfProducts.map((product, index) => (
            <li key={index} className="awb-number border bg-[#F8F6F2] text-black rounded-lg p-2 text-sm text-start">
              <div className="flex justify-between items-center">
                <div>
                  <span className="font-semibold">Product Name:</span> {product.productName || "Unknown"}
                  <br />
                  {pricingMode === "ppu" && (
                  <span className="font-semibold">Price Per Unit: ₹</span>)} {product.price}
                  
                </div>
                <button onClick={() => handleRemoveProduct(index)} className="bg-red-500 text-white px-2 py-1 rounded-lg">
                  Remove
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>

      {/* Submit Button */}
      <div className="flex flex-row gap-5 mt-4">
        <div className="mt-2" onClick={handleFormSubmit}>
          <Button
            title="Create Rate Card"
            bgColor="bg-[rgb(79,201,218)]"
            radius="rounded-lg"
            height="h-[3vw] min-h-[3vh]"
            padding="p-[1vw]"
            color="text-[#ffff]"
            textSize="text-[1vw]"
            fontWeight="font-medium"
            width="w-[14vw]"
          />
        </div>
      </div>
    </div>
  );
};

export default CreatePricingStrategy;
