'use client';
import React, { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useDispatch, useSelector } from "react-redux";
import PricingStrategyDropdown from "../PricingStrategyDropdown/PricingStrategyDropdown";
import { pricingStrategyService } from "@/app/services/pricingStratergyService";
import Button from "../Button/Button";
import {
    PrimaryButton,
    SecondaryButton,
} from "@/app/components/ButtonComponent/ButtonComponent";

const ApplyRateCardToB2BCustomerCSV = ({ onCancel }) => {
  const dispatch = useDispatch();
  const { dropDownPricingStrategyValue } = useSelector((state) => state.dropdown);
  const [getAllPricingStrategies, setGetAllPricingStrategies] = useState([]);
  const [selectedPricingStrategy, setSelectedPricingStrategy] = useState("");
  const [uploadedFile, setUploadedFile] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchPricingStrategies = async () => {
      try {
        const response = await pricingStrategyService.getAllPricingStrategies();
        if (response.success) {
          setGetAllPricingStrategies(response.data);
        } else {
          toast.error("Failed to fetch pricing strategies");
        }
      } catch (err) {
        console.error(err);
        toast.error("An error occurred while fetching pricing strategies");
      }
    };

    fetchPricingStrategies();
  }, []);

  useEffect(() => {
    if (dropDownPricingStrategyValue) {
      setSelectedPricingStrategy(dropDownPricingStrategyValue);
    }
      console.log("🚀 ~ useEffect ~ dropDownPricingStrategyValue:", dropDownPricingStrategyValue)
  }, [dropDownPricingStrategyValue]);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];

    if (file) {
      if (file.type === "text/csv") {
        setUploadedFile(file);
        setErrorMessage("");
      } else {
        setErrorMessage("Please upload a valid CSV file.");
        setUploadedFile(null);
      }
    }
  };

  const handleDownloadTemplate = () => {
    const link = document.createElement("a");
    link.href = "/static/Rate_Card_To_B2B_Customer_Template.csv";
    link.download = "Rate_Card_To_B2B_Customer_Template.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSubmit = async () => {
    if (!selectedPricingStrategy) {
      setErrorMessage("Please select a rate card before uploading.");
      return;
    }

    if (!uploadedFile) {
      setErrorMessage("Please upload a CSV file.");
      return;
    }

    setLoading(true);

    try {
      const formData = new FormData();
      formData.append("pricingStrategyId", selectedPricingStrategy);
      formData.append("file", uploadedFile);

      const response = await pricingStrategyService.assignRateCardToB2BCustomerByCSV(formData);

      if (response && response.success) {
        toast.success(`Rate Card applied successfully!`, {
          autoClose: 2000,
          onClose: () => {
            setSelectedPricingStrategy("");
            setUploadedFile(null);
            window.location.reload();
          },
        });
      } else {
        setSelectedPricingStrategy("");
        setUploadedFile(null);
        toast.error("Failed to apply Rate Card: " + (response?.message || "Unknown error"));
      }
    } catch (err) {
        setSelectedPricingStrategy("");
        setUploadedFile(null);
      console.error("Error occurred:", err);
      toast.error("An error occurred: " + (err.message || "Unknown error"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
      <ToastContainer position="bottom-center" />
      <h2 className="text-base font-semibold text-[#111928] mb-1">Apply Rate Card to B2B Customers</h2>
      <p className="text-sm font-normal text-[#4B5563] mb-6">
        Select a Rate Card and upload a CSV file to apply pricing to B2B customers.
      </p>

      {/* Rate Card Dropdown */}
      <div className="flex flex-col mb-6">
        <label className="block text-[#111928] text-sm font-medium mb-1">
          Select Rate Card<span className="text-[#9CA3AF] ml-[2px]">*</span>
        </label>
        <PricingStrategyDropdown
          id="pricingStrategyDropdown"
          bgColor={"#F8F6F2"}
          options={getAllPricingStrategies}
        />
      </div>

      {/* CSV Upload */}
      <div className="flex flex-col mb-6">
        <label className="block text-[#111928] text-sm font-medium mb-1">
          Upload CSV File<span className="text-[#9CA3AF] ml-[2px]">*</span>
        </label>
        <input
          type="file"
          accept=".csv"
          onChange={handleFileUpload}
          className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-sm font-medium"
        />
        <b className="text-[#9CA3AF] text-xs mt-1">
          Make sure you are uploading the correct CSV file.
        </b>
        {errorMessage && <p className="text-xs mt-1 ml-1 text-red-500">{errorMessage}</p>}
      </div>

      {/* Download Template Button */}
      <button
        onClick={handleDownloadTemplate}
        className="text-blue-600 text-sm underline cursor-pointer mb-6"
      >
        Download Rate Card to B2B Template
      </button>

      {/* Submit Button */}
      <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
        <div className="flex gap-x-2">
             <SecondaryButton title="Cancel" size='full' onClick={onCancel} />
          <PrimaryButton
            title="Apply Rate Card"
            onClick={handleSubmit}
            disabled={loading}
            size='full' bgColor="bg-primary" 
          />
        </div>
      </div>
    </div>
  );
};

export default ApplyRateCardToB2BCustomerCSV;
