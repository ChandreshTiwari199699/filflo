import React, { useState, useRef, useEffect } from "react";
import { useDispatch } from "react-redux";
import { getPricingStrategyName, getPricingStrategyValue } from "../../Actions/dropdownValuesActions";

const PricingStrategyDropdown = ({ bgColor, height, width, options }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const dispatch = useDispatch();
  const dropdownRef = useRef(null);

  // Handle pricing strategy selection
  const handleStrategyChange = (strategy) => {
    dispatch(getPricingStrategyValue(strategy._id));
    dispatch(getPricingStrategyName(strategy.pricingStrategyName));
    setDropdownVisible(false);
    setSearchTerm(`${strategy.pricingStrategyName}`);
  };

  // Handle search input changes
  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
    setDropdownVisible(true);
  };

  // Sort pricing strategies by name
  const sortedOptions = [...options].sort((a, b) => a.pricingStrategyName.localeCompare(b.pricingStrategyName));

  // Filter strategies based on search term
  const filteredOptions = sortedOptions.filter((strategy) =>
    `${strategy.pricingStrategyName}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle clicking outside the dropdown to close it
  const handleClickOutside = (event) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setDropdownVisible(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div style={{ width: width || "auto", position: "relative" }} ref={dropdownRef}>
      <input
        type="text"
        value={searchTerm}
        onChange={handleSearchChange}
        onFocus={() => setDropdownVisible(true)}
        placeholder="Search Rate Cards..."
        className="w-full p-2 border font-normal text-sm h-10 px-4 bg-white border-gray-300 text-[#4B5563] rounded-xl"
      />

      {dropdownVisible && (
        <div className="absolute z-50 bg-white border border-gray-300 rounded-[6px] max-h-[20vw] overflow-y-auto w-full shadow-md scrollbar-none">
          <ul style={{ listStyleType: "none", padding: "0", margin: "0" }}>
            {filteredOptions.length > 0 ? (
              filteredOptions.map((strategy) => (
                <li
                  key={strategy._id}
                  value={strategy._id}
                  onClick={() => handleStrategyChange(strategy)}
                  className="px-5 py-3 text-sm font-medium cursor-pointer text-[#111928] hover:bg-[#F5F3FF] hover:text-[#3758F9]"
                  onMouseEnter={(e) => (e.target.style.backgroundColor = "#f3f4f6")} // Hover effect
                  onMouseLeave={(e) => (e.target.style.backgroundColor = "white")} // Reset background
                  style={{ borderBottom: "1px solid #e5e7eb" }}
                >
                 {strategy.pricingStrategyName}
                </li>
              ))
            ) : (
              <li
                style={{
                  padding: "0.75rem 1rem",
                  color: "#9ca3af",
                  backgroundColor: "#f9fafb",
                  textAlign: "center",
                }}
              >
                No pricing strategies found
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default PricingStrategyDropdown;
