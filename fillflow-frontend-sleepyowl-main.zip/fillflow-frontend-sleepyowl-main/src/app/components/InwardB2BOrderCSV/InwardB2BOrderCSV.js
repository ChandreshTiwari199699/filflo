'use client';
import React, { useState } from "react";
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; 
import { b2bOrderService } from "@/app/services/b2bOrderService";
import {
    PrimaryButton,
    SecondaryButton,
} from "@/app/components/ButtonComponent/ButtonComponent";
import SmallerModal from "../SmallerModal/SmallerModal";

const InwardB2BOrderCSV = ({ onCancel }) => {
    const [selectedOption, setSelectedOption] = useState("");
    const [uploadedFile, setUploadedFile] = useState(null);
    const [errorMessage, setErrorMessage] = useState("");
    const [loading, setLoading] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [validationLogs, setValidationLogs] = useState(null);

    const handleOptionChange = (event) => {
        setSelectedOption(event.target.value);
        setErrorMessage("");
    };

    const handleFileUpload = (event) => {
        const file = event.target.files[0];

        if (file) {
            const validTypes = [
                "text/csv",
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            ];

            if (validTypes.includes(file.type)) {
                setUploadedFile(file);
                setErrorMessage("");
            } else {
                setErrorMessage("Please upload a valid CSV or Excel file.");
                setUploadedFile(null);
            }
        }
    };

    const handleSubmit = async () => {
        if (!selectedOption) {
            setErrorMessage("Please select a CSV/EXCEL type before uploading.");
            return;
        }

        if (!uploadedFile) {
            setErrorMessage("Please upload a CSV/EXCEL file.");
            return;
        }

        setErrorMessage("");
        setLoading(true);

        try {
            let response;
            const formData = new FormData();
            formData.append('file', uploadedFile);
            
            switch (selectedOption) {
                case "Zepto":
                    response = await b2bOrderService.createB2BOrderByZeptoCSV(formData);
                    break;
                case "Blinkit":
                    response = await b2bOrderService.createB2BOrderByBlinkitCSV(formData);
                    break;
                case "Swiggy":
                    response = await b2bOrderService.createB2BOrderBySwiggyCSV(formData);
                    break;
                case "Custom":
                    response = await b2bOrderService.createB2BOrderByCustomCSV(formData);
                    break;
                default:
                    toast.error("Unexpected option selected.");
                    return;
            }

            if (response && response.success) {
                toast.success(`${selectedOption} CSV/EXCEL uploaded successfully!`, {
                    autoClose: 2000,
                    onClose: () => { window.location.reload(); }
                });
            } else if (!response.success && response.errors) {
                setIsModalOpen(true);
                setValidationLogs(response.errors);
            } else {
                toast.error(`Failed to upload ${selectedOption} CSV/EXCEL: ` + (response?.message || 'Unknown error'));
            }
        } catch (err) {
            console.error('Error occurred:', err);
            toast.error('An error occurred: ' + (err.message || 'Unknown error'));
        } finally {
            setLoading(false);
        }
    };


    const handleDownloadTemplate = () => {
        const link = document.createElement("a");
        link.href = "/static/B2B_Order_Custom_Tempelate.csv";
        link.download = "B2B_Order_Custom_Tempelate.csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="relative overflow-y-scroll scrollbar-none pb-10 text-black">
            <ToastContainer position="bottom-center" />
            <h2 className="text-base font-semibold text-[#111928] mb-1">Inward B2B Orders</h2>
            <p className="text-sm font-normal text-[#4B5563] mb-6">
                Inward B2B Orders By Inwarding A CSV/EXCEL From Blinkit / Zepto / Swiggy / Custom
            </p>
            <div className="flex flex-col mb-6">
                <label className="block text-[#111928] text-sm font-medium mb-1">
                    Select CSV/EXCEL Type<span className="text-[#9CA3AF] ml-[2px]">*</span>
                </label>
                <select
                    className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-sm font-medium"
                    id="csv-type"
                    value={selectedOption}
                    onChange={handleOptionChange}
                >
                    <option value="">--Select--</option>
                    <option value="Blinkit">Blinkit</option>
                    <option value="Zepto">Zepto</option>
                    <option value="Swiggy">Swiggy</option>
                    <option value="Custom">Custom</option>
                </select>
            </div>
            <div className="flex flex-col mb-6">
                <label className="block text-[#111928] text-sm font-medium mb-1">
                    Upload CSV/EXCEL<span className="text-[#9CA3AF] ml-[2px]">*</span>
                </label>
                <input
                    className="bg-[#F8F6F2] rounded-lg h-[3.5vw] min-h-[3.5vh] p-[1vw] text-[#838481] text-sm font-medium"
                    type="file"
                    id="csv-upload"
                    accept=".csv, .xls, .xlsx"
                    onChange={handleFileUpload}
                />
                <b className="text-[#9CA3AF] text-xs mt-1">
                    Make sure you are uploading the correct CSV/EXCEL file.
                </b>
                {errorMessage && <p className="text-xs mt-1 ml-1 text-red-500">{errorMessage}</p>}
            </div>

            <button
                onClick={handleDownloadTemplate}
                className="text-blue-600 text-sm underline cursor-pointer mb-6"
            >
                Download B2B Order Custom Tempelate
            </button>
            <div className="absolute bottom-0 left-0 w-full border border-t-stroke bg-white p-2">
                <div className="flex gap-x-2">
                    <SecondaryButton title="Cancel" size='full' onClick={onCancel} />
                    <PrimaryButton title="Submit File" onClick={handleSubmit} disabled={loading} size='full' bgColor="bg-primary" />
                </div>
            </div>
            <SmallerModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
<h2 className="text-xl font-bold">Validation Errors</h2>

{validationLogs && validationLogs.length > 0 ? (
    <div className="mt-2 space-y-4">

           {/* Invalid or Missing Order Type */}
           {validationLogs.some(log => log.error === "Invalid or missing order type") && (
                <div>
                    <h3 className="font-semibold text-pink-600">Invalid or Missing Order Type:</h3>
                    <ul className="list-disc pl-5 text-pink-500">
                        {validationLogs
                            .filter(log => log.error === "Invalid or missing order type")
                            .map((log, index) => (
                                <li key={index}>Order {log.orderId} - Order Type: {log.orderType || "Not Provided"}</li>
                            ))}
                    </ul>
                </div>
            )}
            
        {/* Duplicate Orders Section */}
        {validationLogs.some(log => log.error === "Order already processed") && (
            <div>
                <h3 className="font-semibold text-red-600">Duplicate Orders:</h3>
                <ul className="list-disc pl-5 text-red-500">
                    {validationLogs
                        .filter(log => log.error === "Order already processed")
                        .map((log, index) => (
                            <li key={index}>{log.orderId}</li>
                        ))}
                </ul>
            </div>
        )}

        {/* Product Not Found Section */}
        {validationLogs.some(log => log.error === "Product not found") && (
            <div>
                <h3 className="font-semibold text-orange-600">Products Not Found For These Item Ids:</h3>
                <ul className="list-disc pl-5 text-orange-500">
                    {validationLogs
                        .filter(log => log.error === "Product not found")
                        .map((log, index) => (
                            <li key={index}>Order {log.orderId} - SKU: {log.product}</li>
                        ))}
                </ul>
            </div>
        )}

        {/* B2B Customer Not Found Section */}
        {validationLogs.some(log => log.error === "B2B customer not found for this order") && (
            <div>
                <h3 className="font-semibold text-blue-600">B2B Customer Not Found:</h3>
                <ul className="list-disc pl-5 text-blue-500">
                    {validationLogs
                        .filter(log => log.error === "B2B customer not found for this order")
                        .map((log, index) => (
                            <li key={index}>Order {log.orderId}</li>
                        ))}
                </ul>
            </div>
        )}

        {/* Product Not in B2B Customer List Section */}
        {validationLogs.some(log => log.error === "Product not found in B2B customer product list") && (
            <div>
                <h3 className="font-semibold text-purple-600">Product Not Found in B2B Customer Rate Card:</h3>
                <ul className="list-disc pl-5 text-purple-500">
                    {validationLogs
                        .filter(log => log.error === "Product not found in B2B customer product list")
                        .map((log, index) => (
                            <li key={index}>Order {log.orderId} - B2B Customer: {log.b2bCustomer} - SKU: {log.product}</li>
                        ))}
                </ul>
            </div>
        )}
    </div>
) : (
    <p className="text-gray-500">No validation errors found.</p>
)}
</SmallerModal>
        </div>
    );
};

export default InwardB2BOrderCSV;






