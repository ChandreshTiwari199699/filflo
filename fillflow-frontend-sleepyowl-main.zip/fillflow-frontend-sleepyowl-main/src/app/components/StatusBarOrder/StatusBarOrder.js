import React from 'react';

const StatusBarOrder = ({
  total,
  pending,
  approved,
  picked,
  dispatched,
  delivered,
  rto
}) => {
  const statusData = [
    { value: pending || 0, heading: "Pending Orders" },
    { value: approved || 0, heading: "Approved Orders" },
    { value: picked || 0, heading: "Picked Orders" },
    { value: dispatched || 0, heading: "Dispatched Orders" },
    { value: delivered || 0, heading: "Delivered Orders" },
    { value: rto || 0, heading: "RTO Orders" }
  ];

  return (
    <div className="grid grid-cols-6 gap-4 mb-6">
      {statusData.map((item, index) => (
        <div
          key={index}
          className="bg-white rounded-lg p-4 shadow-sm border border-gray-200"
        >
          <h3 className="text-lg font-semibold text-gray-800">{item.value}</h3>
          <p className="text-sm text-gray-600">{item.heading}</p>
        </div>
      ))}
    </div>
  );
};

export default StatusBarOrder;
