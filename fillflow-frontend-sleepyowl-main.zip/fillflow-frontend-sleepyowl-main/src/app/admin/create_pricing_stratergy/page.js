"use client";
import React, { useEffect, useState } from 'react';
import { items } from '@/app/utils/sidebarItems';
import { useDispatch, useSelector } from 'react-redux';
import TitleBar from "@/app/components/TitleBar/TitleBar";
import NavigationBar from '@/app/components/NavigationBar/NavigationBar';
import CreatePricingStratergy from '@/app/components/CreatePricingStratergy/CreatePricingStratergy';


const page = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarContent, setSidebarContent] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState("Raise B2B Order PO");
  const dispatch = useDispatch();




  const generateNavItems = () => {
    const navItems = [];
  
    navItems.push(
      {
        name: "Create B2B Customer",
        path: "/admin/admin_team",
        icon: "customer",
      },
      {
        name: "Edit B2B Customer",
        path: "/admin/edit_b2b_customer",
        icon: "custom",
      },
      {
        name: "Create Product",
        path: "/admin/create_product",
        icon: "inventory",
      },
      {
        name: "Create Rate Card",
        path: "/admin/create_pricing_stratergy",
        icon: "report",
      },
      {
        name: "Apply Rate Card",
        path: "/admin/add_pricing_stratergy",
        icon: "inventoryLevel",
      }
    );
  
    return navItems;
  };
  
  const navItems = generateNavItems();



  

  return (
    <div className="relative w-full h-full overflow-scroll scrollbar-none bg-[#f9fafc]">
    <div className="relative z-10 flex flex-col items-center overflow-scroll scrollbar-none px-4 py-2">
      <div className="w-full max-w-full mb-4">
        <TitleBar title="Admin Dashboard"  />
      </div>



      {<div className="w-full max-w-full mb-5">
        <NavigationBar navItems={navItems} />
      </div> }

      <div className="flex w-full max-w-full mb-6 scrollbar-none">
        <div className="flex-1 rounded-lg  bg-gray-1 overflow-y-auto scrollbar-none">
          <CreatePricingStratergy/>
        </div>
      </div>
    </div>
  </div>
 
  );
};

export default page;