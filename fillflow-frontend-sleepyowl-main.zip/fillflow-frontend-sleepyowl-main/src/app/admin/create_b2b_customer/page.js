'use client';
import React from 'react';
import Sidebar from '@/app/components/Sidebar/Sidebar';
import PageTitle from '@/app/components/PageTitle/PageTitle';
import CreateB2BCustomerForm from "@/app/components/CreateB2BCustomerForm/CreateB2BCustomerForm";
import { items } from '@/app/utils/sidebarItems';

const Page = () => {

  return (
    <div >

          <CreateB2BCustomerForm />
      </div>
  );
};

export default Page;
