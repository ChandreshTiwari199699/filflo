import React from "react";
import Input from "./components/Input/Input";
import Button from "./components/Button/Button";
import Sidebar from "./components/Sidebar/Sidebar";

const page = () => {
 

  return (
    <div className="flex w-full h-screen bg-blue-400 flex-row gap-4">
      <div className="w-[23vw]">
      </div>
    </div>
  );
};

export default page;
