export const stickyActionColumnClassname =
  "sticky z-10 text-center h-full bg-gray-2 box-shadow-[8px_4px_24px_0px_#0D0A2C0F]  px-4 right-0";

export const stickyActionRowClassname =
  "sticky z-10 text-center h-full bg-white box-shadow-[8px_4px_24px_0px_#0D0A2C0F]  px-4 right-0";
