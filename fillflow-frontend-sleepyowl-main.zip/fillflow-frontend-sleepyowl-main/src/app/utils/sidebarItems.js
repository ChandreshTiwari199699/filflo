// export const items = [
//   // procuremennt team
//   {
//     id: 1,
//     label: "Procurement Team",
//     subItems: [
//       {
//         id: 11,
//         label: "Create vendor PO",
//         path: "/procurement/raise_vendor_po",
//       },
//     ],
//   },


//   // storage team
//   {
//     id: 2,
//     label: "Storage Team",
//     subItems: [
//       {
//         id: 21,
//         label: "Inward procurement PO",
//         path: "/storage/inward_procurement_po",
//       },
//       {
//         id: 26,
//         label: "Staging Inventory Level",
//         path: "/storage/staging_inventory_level",
//       },
//       {
//         id: 22,
//         label: "Storage inventory level",
//         path: "/storage/inventory_level",
//       },
//       {
//         id: 24,
//         label: "Storage QC-Fail Inventory",
//         path: "/storage/storage_qc_fail_inventory",
//       },
//       {
//         id: 23,
//         label: "Outward Assembly Po",
//         path: "/storage/outward_assembly_po",
//       },
//       {
//         id: 25,
//         label: "Outward Bulk Raw Material Po",
//         path: "/storage/outward_bulk_raw_material_po",
//       },
//       {
//         id: 27,
//         label: "Outward Raw Materials To Engraving",
//         path: "/storage/outward_engraving_order"
//       }
//     ],
//   },

//   // assembly team
//   {
//     id: 3,
//     label: "Assembly Team",
//     subItems: [
//       {
//         id: 31,
//         label: "Create PO",
//         subItems: [
//           // Nested subItems
//           {
//             id: 311,
//             label: "Raise SFG PO",
//             path: "/assembly/create_po/raise_sfg_po",
//           },
//           {
//             id: 312,
//             label: "Raise FG PO",
//             path: "/assembly/create_po/raise_fg_po",
//           },
//         ],
//       },

//       {
//         id: 32,
//         label: "View Assembly PO",
//         path: "/assembly/view_assembly_po",
//       },

//       {
//         id: 33,
//         label: "Generate QR Code",
//         path: "/assembly/generate_qr",
//       },
//       {
//         id: 34,
//         label: "PO Raised By Inventory Team",
//         path: "/assembly/po_raised_by_inventory_team",
//       },
//     ],
//   },

//   // inventory Team
//   {
//     id: 4,
//     label: "Inventory Team",
//     subItems: [
//       {
//         id: 11,
//         label: "Raise inventory PO",
//         path: "/inventory/raise_inventory_po",
//       },
//       {
//         id: 12,
//         label: "Inward inventory PO",
//         path: "/inventory/inward_inventory_po",
//       },
//       {
//         id: 13,
//         label: "Product inventory level",
//         path: "/inventory/prouct_inventory_level",
//       },
//       // {
//       //   id: 14,
//       //   label: "Outward Picklist",
//       //   path: "/inventory/outward_picklist",
//       // },
//       {
//         id: 15,
//         label: "Outward Products To Dispatch",
//         path: "/inventory/outward_products_to_dispatch",
//       },
//       {
//         id: 16,
//         label: "Outward Products To Engraving",
//         path : "/inventory/outward_products_to_engraving"
//       },
//       {
//         id: 17,
//         label: "Outwarded Products List",
//         path: "/inventory/outwarded_products_list",
//       }
//     ],
//   },

//     // Engraving Team
//     {
//       id: 10,
//       label: "Engraving Team",
//       subItems: [
//         {
//           id: 101,
//           label: "View and Process Engraving Orders",
//           path: "/engraving/view_engraving_order",
//         },
//         {
//           id: 102,
//           label: "Engraving Inventory Level",
//           path: "/engraving/engraving_inventory_list",
//         }

//       ]
//     },

//   // dispatch team
//   {
//     id: 5,
//     label: "Dispatch Team",
//     subItems: [
//       // {
//       //   id: 11,
//       //   label: "Inward Order List",
//       //   path: "/dispatch/inward_order_list",
//       // },
//       // // {
//       // //   id: 12,
//       // //   label: "Create Pick List",
//       // //   path: "/dispatch/create_pick_list",
//       // // },
//       // {
//       //   id: 13,
//       //   label: "Process Orders",
//       //   path: "/dispatch/process_order",
//       // },
//       {
//         id: 14,
//         label: "Process Order",
//         path: "/dispatch/process_order_details",
//       },
//       {
//         id: 15,
//         label: "Fulfilled Order Details",
//         path: "/dispatch/processed_order_list",
//       },
//       {
//         id: 16,
//         label: "Inward Amazon Order CSV",
//         path : "/dispatch/inward_amazon_order",
//       },
//       {
//         id: 17,
//         label: "Process Amazon Orders",
//         path : "/dispatch/process_amazon_orders",
//       },
//       {
//         id : 18,
//         label: "Create Engraving Order PO",
//         path : "/dispatch/create_engraving_order_po"
//       }
//       // {
//       //   id : 16,
//       //   label : "View Custom Orders",
//       //   path : "/dispatch/view_custom_orders"
//       // },
//       // {
//       //   id : 17,
//       //   label : "Process Custom Orders",
//       //   path : "/dispatch/process_custom_orders"
//       // }
      
//     ],
//   },


//   // report team
//   {
//     id: 6,
//     label: "Report Team",
//     subItems: [
//       {
//         id: 61,
//         label: "Generate Report",
//         path: "/report/generate_report",
//       },
//     ],
//   },

//   // admin team
//   {
//     id: 7,
//     label: "Admin Team",
//     subItems: [
//       {
//         id: 72,
//         label: "Create Raw Material",
//         path: "/admin/create_raw_material",
//       },
//       {
//         id: 72,
//         label: "Create Vendor",
//         path: "/admin/create_vendor",
//       },
//       {
//         id: 73,
//         label: "Create Product",
//         path: "/admin/create_product",
//       },
//       {
//         id: 74,
//         label: "Raise Bulk Raw Material PO",
//         path: "/admin/raise_bulk_raw_material_po",
//       },
//       {
//         id: 75,
//         label: "View Bulk Raw Material PO",
//         path: "/admin/view_bulk_raw_material_po",
//       },
//     ],
//   },
//   // b2b team
//   {
//     id: 8,
//     label: "Custom Order Team",
//     subItems: [
//       {
//         id: 81,
//         label: "Create Custom Order",
//         path: "/b2b/create_custom_order",
//       },
//       {
//         id : 82,
//         label : "View Custom Orders",
//         path : "/b2b/view_custom_orders"
//       },
//       {
//         id : 83,
//         label : "Process Custom Orders",
//         path : "/b2b/process_custom_orders"
//       },
//     ],
//   },
//   {
//     id: 9,
//     label: "RTO Team",
//     subItems: [
//       {
//         id: 91,
//         label: "Inward RTO Order",
//         path: "/rto/inward_rto_order",
//       },
//       {
//         id : 92,
//         label: "Inwarded RTO Order Details",
//         path: "/rto/inwarded_rto_order_details",
//       }
//     ]

//   },
// ];


export const items = [
  // procuremennt team
  // {
  //   id: 1,
  //   label: "Testing Team",
  //   subItems: [
  //     {
  //       id: 11,
  //       label: "Generate QR Code",
  //       path: "/assembly/generate_qr",
  //     },
  //     {
  //       id: 12,
  //       label: "Inward Products To Inventory",
  //       path: "/new/inward_order",
  //     },
  //     {
  //       id: 13,
  //       label: "Inventory Level",
  //       path: "/inventory/prouct_inventory_level",
  //     },
  //     {
  //       id: 14,
  //       label: "Outward Products To Dispatch",
  //       path:"/inventory/outward_products_to_dispatch",

  //     },
  //     {
  //       id: 15,
  //       label: "Outward Products List",
  //       path:"/inventory/outwarded_products_list",
  //     },
  //   ],
  // },

  {
    id: 1,
    label: "Storage",
    iconKey: "storage",
    path: "/storage/inventory_level",
    subItems: [
      {
        id: 11,
        label: "Inventory Level",
        iconKey: "inventoryLevel",
        path: "/storage/inventory_level",
      },
      {
        id: 12,
        label: "Procurement PO",
        iconKey: "inwardPo",
        path: "/storage/procurement_po",
      },
      {
        id: 13,
        label: "Outward Products To Production",
        path: "/storage/outward_sku_to_production",
        iconKey : "outwardPo"
      },
    ],
  },

  {
    id: 2,
    label: "Production",
    iconKey: "assembly",
    path: "/production/inventory_level",
    subItems: [
    ],
  },
  

  {
     id:3,
     label:"Inventory",
     iconKey:"inventory",
     path: "/inventory/product_inventory_level",
     subItems:[
      {
        id: 31,
        label: "Product inventory level",
        path: "/inventory/product_inventory_level",
        iconKey : "inventory"
      },
      {
        id: 32,
        label: "Outward Products To B2B",
        path: "/inventory/outward_product_to_b2b",
        iconKey : "outwardPo"
      },
      {
        id: 33,
        label: "Create Picklist",
        path: "/inventory/create_picklist",
        iconKey : "update"
      },
      {
        id: 34,
        label: "Activity Logger",
        path: "/inventory/inventory_logger",
        iconKey : "report"
      }
    

     ],
  },

  
  {
    id: 4,
    label: "Replenishment Team",
    iconKey: "order",
    path: "/b2b/b2b_order_team",
    subItems: [
    ],
  },
  {
    id: 5,
    label: "Master Data",
    iconKey: "update",
    path: "/master/rate_card",
    subItems: [
      {
        id: 51,
        label: "Product",
        path: "/master/products",
        iconKey : "inventory"
      },
      {
        id: 52,
        label: "Rate Card",
        path: "/master/rate_card",
        iconKey : "report"
      },
      {
        id: 53,
        label: "B2B Customers",
        path: "/master/b2b_customers",
        iconKey : "customer"
      },

    ],
  },

  {
    id: 6,
    label: "Report",
    iconKey: "report",
    path: "/report/party_ledger",
    subItems: [
      {
        id: 61,
        label: "Party Ledger",
        path: "/report/party_ledger",
        iconKey : "executive"
      },
      {
        id: 62,
        label: "Invoices",
        path: "/report/invoice",
        iconKey : "dispatch"
      },
      {
        id: 62,
        label: "Credit Notes",
        path: "/report/credit_notes",
        iconKey : "outwardPo"
      },
    ],

  }

  // {
  //   id: 3,
  //   label: "Admin Team",
  //   path: "/admin/create_b2b_customer",
  //   iconKey: "settings",
  //   subItems: [
  //  
  //     {
  //       id: 32,
  //       label: "Create B2B Customer",
  //       path: "/admin/create_b2b_customer",
  //     },
  //     {
  //       id: 33,
  //       label: "Edit B2B Customer",
  //       path : "/admin/edit_b2b_customer"
  //     }
  //   ],
  // },

];
