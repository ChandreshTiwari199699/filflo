import * as Yup from "yup";

const productSchema = Yup.object().shape({
  productId: Yup.string()
    .required("Product is required")
    .matches(/^[a-f\d]{24}$/, "Invalid product ID"),
  price: Yup.number()
    .required("Price is required")
    .positive("Price must be a positive number"),
});

const b2bCustomerValidationSchema = Yup.object().shape({
  customerId: Yup.string()
    .required("Customer ID is required")
    .max(20, "Customer ID cannot exceed 20 characters"),
  name: Yup.string()
    .required("Customer name is required")
    .max(50, "Customer name cannot exceed 50 characters"),
  phone: Yup.string()
    .required("Phone number is required")
    .matches(
      /^[6-9]\d{9}$/,
      "Phone number must be a valid 10-digit number starting with 6, 7, 8, or 9"
    ),
  address: Yup.string()
    .required("Address is required")
    .max(200, "Address cannot exceed 200 characters"),
  gstNumber: Yup.string()
    .required("GST Number is required")
    .matches(
      /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{1}[Z]{1}[A-Z0-9]{1}$/,
      "Invalid GST Number format"
    ),
  pointOfContact: Yup.object().shape({
    name: Yup.string()
      .required("Point of Contact name is required")
      .max(50, "Name cannot exceed 50 characters"),
    phone: Yup.string()
      .required("Point of Contact phone is required")
      .matches(
        /^[6-9]\d{9}$/,
        "Phone number must be a valid 10-digit number starting with 6, 7, 8, or 9"
      ),
  }),
  products: Yup.array()
    .of(productSchema)
    .min(1, "At least one product must be added"),
  createdBy: Yup.string()
    .required("Creator information is required")
    .matches(/^[a-f\d]{24}$/, "Invalid user ID"),
  status: Yup.string()
    .required("Status is required")
    .oneOf(["active", "inactive"], "Status must be 'active' or 'inactive'"),
  remarks: Yup.string().max(500, "Remarks cannot exceed 500 characters"),
});

export default b2bCustomerValidationSchema;
