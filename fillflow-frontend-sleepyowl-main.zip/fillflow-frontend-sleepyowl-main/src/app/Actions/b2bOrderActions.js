import {
 GET_ALL_B2B_ORDERS_FAILURE,
 GET_ALL_B2B_ORDERS_REQUEST,
 GET_ALL_B2B_ORDERS_SUCCESS,
 GET_B2BORDERBY_ORDERID_FAILURE,
 GET_B2BORDERBY_ORDERID_REQUEST,
 GET_B2BORDERBY_ORDERID_SUCCESS,
} from '../constants/b2bOrderConstant';

export const getAllB2BOrdersRequest = () => {
    return {
    type: GET_ALL_B2B_ORDERS_REQUEST,
    };
};

export const getAllB2BOrdersSuccess = (ordersData) => {
    return {
    type: GET_ALL_B2B_ORDERS_SUCCESS,
    payload: ordersData,
    };
};

export const getAllB2BOrdersFailure = (error) => {
    return {
    type: GET_ALL_B2B_ORDERS_FAILURE,
    payload: error,
    };
};   

export const getB2BOrderByOrderIdRequest = () => {
    return {
    type: GET_B2BORDERBY_ORDERID_REQUEST,
    };
};

export const getB2BOrderByOrderIdSuccess = (orderData) => {
    return {
    type: GET_B2BORDERBY_ORDERID_SUCCESS,
    payload: orderData,
    };
};

export const getB2BOrderByOrderIdFailure = (error) => {
    return {
    type: GET_B2BORDERBY_ORDERID_FAILURE,
    payload: error,
    };
};