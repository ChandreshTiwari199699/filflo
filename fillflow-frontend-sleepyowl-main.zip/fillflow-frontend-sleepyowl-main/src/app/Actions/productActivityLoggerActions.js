import {
  GET_ALL_PRODUCT_LOGS_FAILURE,
    GET_ALL_PRODUCT_LOGS_REQUEST,
    GET_ALL_PRODUCT_LOGS_SUCCESS,
} from '../constants/productActivityLoggerConstants';

export const getAllProductLogsRequest = () => {
    return {
        type: GET_ALL_PRODUCT_LOGS_REQUEST,
    };
    }
export const getAllProductLogsSuccess = (productLogs) => {
    return {
        type: GET_ALL_PRODUCT_LOGS_SUCCESS,
        payload: productLogs,
    };
    }
export const getAllProductLogsFailure = (error) => {
    return {
        type: GET_ALL_PRODUCT_LOGS_FAILURE,
        payload: error,
    };
    }
    