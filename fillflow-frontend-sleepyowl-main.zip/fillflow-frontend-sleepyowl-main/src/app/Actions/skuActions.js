import {
    GET_ALL_SKU_REQUEST,
    GET_ALL_SKU_SUCCESS,
    GET_ALL_SKU_FAILURE,
    GET_SKU_BY_CATEGORY_REQUEST,
    GET_SKU_BY_CATEGORY_SUCCESS,
    GET_SKU_BY_CATEGORY_FAILURE,
    CREATE_SKU_REQUEST,
    CREATE_SKU_SUCCESS,
    CREATE_SKU_FAILURE,
  } from "../constants/skuConstants";
  
  // Get all SKUs
  export const getAllSKURequest = () => ({
    type: GET_ALL_SKU_REQUEST,
  });
  
  export const getAllSKUSuccess = (skuData) => ({
    type: GET_ALL_SKU_SUCCESS,
    payload: skuData,
  });
  
  export const getAllSKUFailure = (error) => ({
    type: GET_ALL_SKU_FAILURE,
    payload: error,
  });
  
  // Get SKUs by Category ID
  export const getSKUByCategoryRequest = () => ({
    type: GET_SKU_BY_CATEGORY_REQUEST,
  });
  
  export const getSKUByCategorySuccess = (skuData) => ({
    type: GET_SKU_BY_CATEGORY_SUCCESS,
    payload: skuData,
  });
  
  export const getSKUByCategoryFailure = (error) => ({
    type: GET_SKU_BY_CATEGORY_FAILURE,
    payload: error,
  });
  
  // Create a new SKU
  export const createSKURequest = () => ({
    type: CREATE_SKU_REQUEST,
  });
  
  export const createSKUSuccess = (skuData) => ({
    type: CREATE_SKU_SUCCESS,
    payload: skuData,
  });
  
  export const createSKUFailure = (error) => ({
    type: CREATE_SKU_FAILURE,
    payload: error,
  });
  
  