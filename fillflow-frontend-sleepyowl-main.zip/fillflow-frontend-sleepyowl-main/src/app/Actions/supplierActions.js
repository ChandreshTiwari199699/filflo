import {
    GET_ALL_SUPPLIERS_REQUEST,
    GET_ALL_SUPPLIERS_SUCCESS,
    GET_ALL_SUPPLIERS_FAILURE,
  } from '../constants/supplierConstants';
  
  export const getAllSuppliersRequest = () => {
    return {
      type: GET_ALL_SUPPLIERS_REQUEST,
    };
  };
  
  export const getAllSuppliersSuccess = (supplierData) => {
    return {
      type: GET_ALL_SUPPLIERS_SUCCESS,
      payload: supplierData,
    };
  };
  
  export const getAllSuppliersFailure = (error) => {
    return {
      type: GET_ALL_SUPPLIERS_FAILURE,
      payload: error,
    };
  };
  