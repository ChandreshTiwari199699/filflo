import {
  GET_CATEGORY_VALUE,
  GET_VENDOR_VALUE,
  GET_MATERIAL_VALUE,
  GET_MATERIAL_NAME,
  GET_PRODUCT_VALUE,
  GET_BATCH_NUMBER,
  GET_PRODUCT_NAME,
  GET_B2B_CUSTOMER_NAME,
  GET_B2B_CUSTOMER_VALUE,
  GET_SKU_NAME,
  GET_SKU_VALUE,
  GET_PRICING_STRATEGY_NAME,
  GET_PRICING_STRATEGY_VALUE,
  GET_SUPPLIER_NAME,
  GET_SUPPLIER_VALUE,
} from "../constants/dropDownValuesConstants";

export const getCatValue = (value) => {
  return {
    type: GET_CATEGORY_VALUE,
    payload: value,
  };
};

export const getVendorValue = (value) => {
  return {
    type: GET_VENDOR_VALUE,
    payload: value,
  };
};

export const getMatValue = (value) => {
  return {
    type: GET_MATERIAL_VALUE,
    payload: value,
  };
};
export const getMatName = (value) => {
  return {
    type: GET_MATERIAL_NAME,
    payload: value,
  };
};
export const getProductValue = (value) => {
  return {
    type: GET_PRODUCT_VALUE,
    payload: value,
  };
};

export const getProductName = (productName) => {
  return {
    type: GET_PRODUCT_NAME,
    payload: productName,
  };
};

export const getSkuValue = (value) => {
  return {
    type: GET_SKU_VALUE,
    payload: value,
  };
};

export const getSkuName = (skuName) => {
  return {
    type: GET_SKU_NAME,
    payload: skuName,
  };
};

export const getBatchNumber = (batchNumber) => {
  return {
    type: GET_BATCH_NUMBER,
    payload: batchNumber,
  };
};

export const getB2BCustomerValue = (value) => {
  return {
    type: GET_B2B_CUSTOMER_VALUE,
    payload: value,
  };
};

export const getB2BCustomerName = (b2bCustomerName) => {
  return {
    type: GET_B2B_CUSTOMER_NAME,
    payload: b2bCustomerName,
  };
};


export const getPricingStrategyValue = (value) => {
  return {
    type: GET_PRICING_STRATEGY_VALUE,
    payload: value,
  };
};

export const getPricingStrategyName = (strategyName) => {
  return {
    type: GET_PRICING_STRATEGY_NAME,
    payload: strategyName,
  };
};

export const getSupplierValue = (value) => {
  return {
    type: GET_SUPPLIER_VALUE,
    payload: value,
  };
};

export const getSupplierName = (supplierName) => {
  return {
    type: GET_SUPPLIER_NAME,
    payload: supplierName,
  };
};