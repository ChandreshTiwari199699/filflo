import {
    GET_ALL_B2B_CUSTOMER_FAILURE,
    GET_ALL_B2B_CUSTOMER_REQUEST,
    GET_ALL_B2B_CUSTOMER_SUCCESS,
} from "../constants/b2bCustomerConstants";

export const getAllB2BCustomerRequest = () => {
    return {
        type: GET_ALL_B2B_CUSTOMER_REQUEST,
    };
}

export const getAllB2BCustomerSuccess = (b2bCustomerData) => {
    return {
        type: GET_ALL_B2B_CUSTOMER_SUCCESS,
        payload: b2bCustomerData,
    };
}

export const getAllB2BCustomerFailure = (error) => {
    return {
        type: GET_ALL_B2B_CUSTOMER_FAILURE,
        payload: error,
    };
}