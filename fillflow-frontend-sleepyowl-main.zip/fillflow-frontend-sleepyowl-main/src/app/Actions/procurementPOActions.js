import {
    GET_ALL_PROCUREMENT_PO_REQUEST,
    GET_ALL_PROCUREMENT_PO_SUCCESS,
    GET_ALL_PROCUREMENT_PO_FAILURE,
  } from "../constants/procurementPOConstant";
  
  // Get all Procurement POs
  export const getAllProcurementPORequest = () => ({
    type: GET_ALL_PROCUREMENT_PO_REQUEST,
  });
  
  export const getAllProcurementPOSuccess = (data) => ({
    type: GET_ALL_PROCUREMENT_PO_SUCCESS,
    payload: data,
  });
  
  export const getAllProcurementPOFailure = (error) => ({
    type: GET_ALL_PROCUREMENT_PO_FAILURE,
    payload: error,
  });
  