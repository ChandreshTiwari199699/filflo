export const GET_ALL_CATEGORY_REQUEST = "GET_ALL_CATEGORY_REQUEST";
export const GET_ALL_CATEGORY_SUCCESS = "GET_ALL_CATEGORY_SUCCESS";
export const GET_ALL_CATEGORY_FAILURE = "GET_ALL_CATEGORY_FAILURE";

export const SET_SELECTED_CAT = "SET_SELECTED_CAT";

export const sfgCategories = ["Raw Material", "Finished Goods"];

